<?php

namespace Database\Seeders;

use App\Models\Adminiy;
use App\Models\Permissions;
use App\Models\Role;
use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class UserRolePermissionSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Permissions::create(['name' => 'Create Order', 'slug' => 'create_order', 'is_active' => '1', 'is_deleted' => '0']);
        Permissions::create(['name' => 'View Order', 'slug' => 'view_order', 'is_active' => '1', 'is_deleted' => '0']);
        Permissions::create(['name' => 'View Transaction', 'slug' => 'view_transaction', 'is_active' => '1', 'is_deleted' => '0']);
        Permissions::create(['name' => 'View Brand', 'slug' => 'view_brand', 'is_active' => '1', 'is_deleted' => '0']);
        Permissions::create(['name' => 'View User', 'slug' => 'view_user', 'is_active' => '1', 'is_deleted' => '0']);
        Permissions::create(['name' => 'View Payment', 'slug' => 'view_payment', 'is_active' => '1', 'is_deleted' => '0']);
        Permissions::create(['name' => 'View Packages', 'slug' => 'view_packages', 'is_active' => '1', 'is_deleted' => '0']);


        Role::create(['role' => 'User']);
        Role::create(['role' => 'Customer']);

        Adminiy::create([
            'name' => 'Admin',
            'email' => 'admin@terminalpays.com',
            'role_id' => '1',
            'password' => Hash::make ('admin@terminalpays.com'),
        ]);
    }
}
