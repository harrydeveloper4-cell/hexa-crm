<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
// use Auth;
use Illuminate\Support\Facades\Auth;

class LoginController extends Controller
{
    public function login()
    {
        try {
            return view('admin.login');
        } catch (\Throwable $th) {
            return redirect()->back()->with('error', "Request :" . $th->getMessage());
            throw $th;
        }
    }

    public function login_process(Request $request)
    {
        $request->validate([
            'email' => 'required|email',
            'password' => 'required'
        ]);
        try {
            if (Auth::guard('adminiy')->attempt([
                'email' => $request->input('email'),
                'password' => $request->input('password')
            ])) {
                $admin = Auth::guard('adminiy')->user();

                return redirect()->route('dashboard');
            } else {
                return redirect()->route('admin.login')
                    ->with('error', 'Ooops! Invalid Email or Password')
                    ->withInput();
            }
        } catch (\Throwable $th) {
            return redirect()->back()->with('error', "Request :" . $th->getMessage());
            throw $th;
        }
    }

    public function logout()
    {
        try {
            Auth::guard('adminiy')->logout();
            return redirect()->route('admin.login');
        } catch (\Throwable $th) {
            return redirect()->back()->with('error', "Request :" . $th->getMessage());
            throw $th;
        }
    }
}
