<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Package;
use App\Models\Brand;
use Illuminate\Support\Facades\Log;

class PackageController extends Controller
{
    public function index($brand_id = null)
    {
        try {
            $packages = Package::with('brand')->where('is_deleted','0')->get();
            $brands = Brand::where('status','active')->get();        
            return view('admin.packages.index',compact('packages','brands'));
        } catch (\Throwable $th) {
            return redirect()->back()->with('error', "Request :" . $th->getMessage());
            throw $th;
        }
    }

    public function create()
    {
        try {
            $brands = Brand::where('status','active')->get();
            return view('admin.packages.create',compact('brands'));
        } catch (\Throwable $th) {
            return redirect()->back()->with('error', "Request :" . $th->getMessage());
        }
    }

    public function store(Request $request)
    {
        $request->validate([
            'package_name' => 'required',
            'brand'=> 'required',
        ]);
        
        if(count($request->package_name) > 0){
            foreach($request->package_name as $key => $name){
                if(!is_null($name)){
                    $package = new Package();
                    $package->package_name = $name;
                    $package->brand_id = $request->brand;
                    $package->save();
                }    
            }
        }

        if(!empty($package)){
            session()->flash('success','package created successfully..!');
        }
        else{
            session()->flash('error','package creating failed..!');
        }

        return redirect()->route('packages');

    }

    public function edit($id){
        $package = Package::find($id);
        $brands = Brand::where('status','active')->get();
        return view('admin.packages.edit',compact('package','brands','id'));
    }

    public function update(Request $request,$id){
        $request->validate([
            'package_name' => 'required',
            'brand'=> 'required',
        ]);
        
        $package = Package::find($id);
        $package->package_name = $request->package_name;
        $package->brand_id = $request->brand;
        $package->status = $request->status == null?'inactive':'active';
        $package->save();

        if(!empty($package)){
            session()->flash('success','package updated successfully..!');
        }
        else{
            session()->flash('error','package updated failed..!');
        }
        return redirect()->route('packages');
    }

    public function destroy($id){
        $package = Package::find($id);
        if($package){
            $package->is_deleted = '1';
            $package->save();
            session()->flash('success','package deleted successfully..!');
        }else{
            session()->flash('error','package deleting failed..!');    
        }
        return redirect()->route('packages');
    }

    public function brand_packages_edit(Request $request){
        $request->validate([
            'brand' => 'required|exists:brands,id',
        ]);
        try {
            $packages = Package::where('brand_id',$request->brand)->where('is_deleted','0')->get();
            $brand = $request->brand;
            return view('admin.packages.all_edit',compact('packages','brand'));
        } catch (\Throwable $th) {
            //throw $th;
            return redirect()->back()->with('error', "Request :" . $th->getMessage());
        }
    }    

    public function delete_brand_package($id){
        $package = Package::find($id);
        if($package){
            $package->is_deleted = '1';
            $package->save();
            return response()->json(['success' => 'package deleted successfully'],200);
        }else{
            return response()->json(['error' => 'package deleted successfully'],404);
        }
    }

    public function package_status_change($id){
        $package = Package::where('id',$id)->update(['status' => request()->status]);
        if($package){
             return response()->json(['success' => 'Package status updated successfully'],200);           
        }
        else{
            return response()->json(['error' => 'Package status updated failed'],404);
        }
    }
    
    public function update_all(Request $request){
        // dd($request);
        $request->validate([
            'package_name.*' => 'required',
        ], [
            'package_name.0.required' => 'Each package name is required.',
            'package_name.*.required' => 'Each package name is required.', // This covers all the other package names.
        ]);
        try {
            if(isset($request->old_package_name) && count($request->old_package_name) > 0){
                foreach($request->old_package_name as $key => $old_name){
                    if(is_null($old_name)){
                        continue;
                    }
                    $package = Package::find($key);
                    $package->package_name = $old_name;
                    $package->brand_id = $request->brand;
                    $package->save();
                }
            }
            if(isset($request->package_name) && count($request->package_name) > 0){
                foreach($request->package_name as $key => $name){
                    if(is_null($name)){
                        continue;
                    }
                    $package = new Package();
                    $package->package_name = $name;
                    $package->brand_id = $request->brand;
                    $package->save();
                }
            }
            return redirect()->back()->with('success', 'Package Updated Successfuly');
        } catch (\Throwable $th) {
            //throw $th;
            Log::error('Package Updated Failed', ['error' => $th->getMessage()]);
            return redirect()->back()->with('error', "Request Failed:" . $th->getMessage());
        }
    }
}
