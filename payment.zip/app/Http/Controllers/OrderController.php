<?php

namespace App\Http\Controllers;

use App\Mail\PaymentSuccessEmail;
use App\Models\Country;
use Carbon\Carbon;
use File;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Brand;
use App\Models\Order;
use App\Models\CardDetail;
use App\Models\Package;
use App\Models\Merchant;
use App\Models\OrderPackage;
use App\Models\OrderPaymentTransaction;
use App\Mail\OrderInvoice;
use App\Mail\PaymentLink;
use App\Models\Adminiy;
use App\Models\Invoice;
use App\Models\UserBrand;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\DB;
use Barryvdh\DomPDF\Facade\PDF;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Validator;
// use Auth;
// use Crypt;
// use Mail;
use Stripe;

class OrderController extends Controller
{
    public function index()
    {
        try {
            if (Auth::guard('adminiy')->user()->role_id == 1) {
                $orders = Order::has('brand_details')->orderBy('id', 'DESC')->get();
            } else {
                $user_brand_ids = UserBrand::where('user_id', Auth::guard('adminiy')->user()->id)->pluck('brand_id')->toArray();
                $orders = Order::has('brand_details')->orderBy('id', 'DESC')->whereIn('brand_name', $user_brand_ids)->get();
            }

            // dd($orders);
            return view('admin.orders.index', compact('orders'));
        } catch (\Throwable $th) {
            return redirect()->back()->with('error', "Request :" . $th->getMessage());
            throw $th;
        }
    }

    public function customer_orders($email){
        try{
            if(Auth::guard('adminiy')->user()->role_id == 1){
                $orders = Order::has('brand_details')->where('customer_email', $email)->orderBy('id', 'DESC')->get();
            } else{
                $user_brand_ids = UserBrand::where('user_id', Auth::guard('adminiy')->user()->id)->pluck('brand_id')->toArray();
                $orders = Order::has('brand_details')->orderBy('id', 'DESC')->where('customer_email', $email)->whereIn('brand_name', $user_brand_ids)->find($email)->get();
            }
            return view('admin.orders.index', compact('orders'));
        } catch(\Throwable $th){
            return redirect()->back()->with('error', "Request :" . $th->getMessage());
            throw $th;
        }
    }

    public function show($id)
    {
        try {
            $order = Order::find($id);
            return view('admin.orders.show', compact('order'));
        } catch (\Throwable $th) {
            return redirect()->back()->with('error', "Request :" . $th->getMessage());
            throw $th;
        }
    }

    public function edit($id)
    {
        try {
            $order = Order::find($id);
            $brands = Brand::where('status', 'active')->get();
            $brand_packages = Package::where('status', 'active')->where('brand_id', $order->brand_name)->get();
            return view('admin.orders.edit', compact('order', 'brands', 'brand_packages'));
        } catch (\Throwable $th) {
            return redirect()->back()->with('error', "Request :" . $th->getMessage());
            throw $th;
        }
    }

    public function update(Request $request, $id)
    {
        $request->validate([
            'payment_type' => 'required',
            'sale_amount' => 'required',
            'sale_currency' => 'required',
            'description' => 'required',
            'brand_name' => 'required',
            'packages' => 'required',
            'sales_email' => 'required|email',
            'customer_email' => 'required|email',

        ]);
        try {
            $order = Order::find($id);
            $order->payment_type = $request->payment_type;
            $order->sale_amount = $request->sale_amount;
            $order->sale_currency = $request->sale_currency;
            $order->description = $request->description;
            $order->save();

            if ($request->packages != null) {
                OrderPackage::where('order_id', $order->id)->delete();
                foreach ($request->packages as $key => $package) {
                    OrderPackage::create(['order_id' => $order->id, 'package_id' => $package]);
                }
                // $link = Crypt::encryptString($order->id);
                // $order->expires_at = now()->addHours(24);
                // $order->payment_link = route('payment.terminal', ['link' => $link]);
                // $mail_data = [
                //     'order' => $order,
                // ];
                // Mail::to($order->customer_email)->send(new PaymentLink($mail_data));
                $order->save();
                if ($order) {
                    try {
                        $mail_data = [
                            'order' => $order,
                        ];
                        // Mail::to($order->customer_email)->send(new PaymentLink($mail_data));
                    } catch (\Throwable $th) {
                        //throw $th;
                        Log::error('Order update email failed', ['error' => $th->getMessage()]);
                    }
                    
                    return redirect()->back()->with('success', 'Order updated successfully');
                }
            } else {
                return redirect()->back()->with('error', 'Order updated failed');
            }
        } catch (\Throwable $th) {
            return redirect()->back()->with('error', "Request :" . $th->getMessage());
            throw $th;
        }
    }

    public function destroy($id)
    {
        try {
            $order = Order::findOrFail($id);
            $order->delete();
            $order->order_packages()->delete();
            $order->order_payment_transactions()->delete();
            return redirect()->route('admin.orders.index')->with('success', 'Order deleted successfully');
        } catch (\Throwable $th) {
            return redirect()->back()->with('error', "Request :" . $th->getMessage());
            throw $th;
        }
    }

    public function order_store(Request $request)
    {
        // dd($request);
        $validator = Validator::make($request->all(),[
            'payment_type' => 'required',
            'sale_amount' => 'required',
            'sale_currency' => 'required',
            'description' => 'required',
            'brand_name' => 'required',
            'payment_gateway' => 'required',
            'packages' => 'required',
            'sales_email' => 'required|email',
            'customer_email' => 'required|email',
            // 'expiry_date' => 'required',
        ]);

        if($validator->fails()){
            return back()->withErrors($validator)->withInput($request->all())->with('error', 'Validation Error!');
        }
        
        try {
            DB::beginTransaction();
            $data = $request->except('_token');
            $merchant = Merchant::find($request->payment_gateway);
            $data['payment_gateway'] = $merchant->merchant;
            $data['merchant_id'] = $merchant->id;

            $order = Order::create($data);
            
            if (!empty($order)) {

                $order->order_number = str_pad($order->id, 5, '0', STR_PAD_LEFT);
                $order->save();
                if ($request->packages != null) {
                    
                    foreach ($request->packages as $key => $package) {
                        OrderPackage::create(['order_id' => $order->id, 'package_id' => $package]);
                    }
                    $link = $this->encode_id($order->id);
                    $dlink = $this->decode_id($link);
                    
                    $order->expires_at = Carbon::parse(date('Y-m-d'))->addMonth(1);
                    
                    $brand_data = Brand::where('id', $request->brand_name)->first();
                    if(!$brand_data){
                        return redirect()->back()->with('error', 'Issue with the brand URL');
                    }
                    
                    $brand_name = $brand_data->slug;
                    $order->payment_link = route('payment.terminal', [
                        'brander' => $brand_name,
                        'link' => $link
                    ]);
                    
                    
                    //dd($link, $order->payment_link, $dlink);
                    $order->save();
                    $invoice = new Invoice();
                    $invoice->order_id = $order->id;
                    $invoice->amount = $order->sale_amount;
                    $invoice->payment_link = $order->payment_link;
                    $invoice->save();
                    
                    DB::commit();
                    
                    return redirect()->route('payment.terminal', [
                        'brander' => $brand_name,
                        'link' => $link
                    ]);
                }
            } else {
                return redirect()->back()->with('error', 'Order could not create');
            }
        } catch (\Throwable $th) {
            DB::rollBack();
            return redirect()->back()->with('error', "Request :" . $th->getMessage());
            throw $th;
        }
    }

    public function request_payment_link(Request $request, $id)
    {
        // dd($request);
        $validator = Validator::make($request->all(),[
            'expiry_date' => 'required',
        ]);

        if($validator->fails()){
            return back()->withErrors($validator)->withInput($request->all())->with('error', 'Validation Error!');
        }

        try {
            $order = Order::findOrFail($id);
            if($order->payment_status == 'paid'){
                return redirect()->back()->with('success', "Request Failed! #".$order->order_number." order is already paid.");
            }
            $link = Crypt::encryptString($order->id);
            $order->expires_at = $request->expiry_date;
            $order->payment_link = route('payment.terminal', ['link' => $link]);
            
            try {
                $mail_data = [
                    'order' => $order,
                ];
                // Mail::to($order->customer_email)->send(new PaymentLink($mail_data));
            } catch (\Throwable $th) {
                //throw $th;
                Log::error('New payment link email failed', ['error' => $th->getMessage()]);
            }

            $order->save();
            return redirect()->back()->with('success', "Payment link updated successfully");
        } catch (\Throwable $th) {
            return redirect()->back()->with('error', "Request :" . $th->getMessage());
            throw $th;
        }
    }

    public function payment_terminal($brander,$link)
    {
        
        try {
            $order_id = $this->decode_id($link);
            $order = Order::find($order_id);
            if ($order->payment_link != url()->current()) {
                // if ($order->payment_status == 'paid') {
                //     return response()->view('errors.400', ['message' => 'Order not found but a paid order exists.'], 400);
                // }
                return response()->view('errors.404', ['message' => 'Order not found.'], 404);
            }

            if (Carbon::parse($order->expires_at)->toDateString() < now()->toDateString()) {
                return response()->view('errors.500', ['message' => 'The order has expired.', 'order' => $order], 500);
            }

            $merchants = get_brand_merchants($order->brand_name);
            $currency_mode = $order->sale_currency;

            $countries = Country::all();

            if ($order->status == 'pending') {
                switch ($order->merchant_id) {
                    case '1':
                        return $this->redirectToPaypal($order, $merchants, $currency_mode, $countries);
                    case '2':
                        return $this->redirectToStripe($order, $merchants, $currency_mode, $countries);
                    case '3':
                        return $this->redirectToSquare($order, $merchants, $currency_mode, $countries);
                    case '4':
                        return $this->redirectToAuthorize($order, $merchants, $currency_mode, $countries);
                    case '5':
                        return $this->redirectToRapyd($order, $merchants, $currency_mode, $countries);
                    case '6':
                        return $this->redirectToChase($order, $merchants, $currency_mode, $countries);
                    default:
                        return response()->view('errors.400', ['message' => 'Invalid merchant ID.'], 400);
                }
            } else {
                return response()->view('errors.400', ['message' => 'Order status is not pending.'], 400);
            }
        } catch (\Throwable $th) {
            return redirect()->back()->with('error', "An error occurred: " . $th->getMessage());
            throw $th;
        }
    }

    public function redirectToStripe($order, $merchants, $currency_mode, $countries)
    {
        $config_keys = json_decode(get_merchant_keys($order->brand_name, $order->merchant_id));
        $brandName = $order->brand_details->name;

        $words = explode(' ', $brandName);
        $initials = '';
        foreach ($words as $word) {
            $initials .= strtoupper($word[0]); // H + F + A = HFA
        }
        
        \Stripe\Stripe::setApiKey($config_keys->stripe_secret_key);
        $amount = $order->sale_amount;
        $intent = \Stripe\PaymentIntent::create([
            'amount' => ($amount) * 100,
            'currency' => $order->sale_currency,
            'metadata' => ['integration_check' => 'accept_a_payment'],
            'statement_descriptor_suffix' => "Payment - " . $initials,
            'description' => "Payment from - " . $order->brand_details->name,
        ]);
        $data = array(
            'email' => $order->customer_email,
            'amount' => $amount,
            'client_secret' => $intent->client_secret,
        );
        return view('payment_terminals.stripe', compact('order', 'merchants', 'data', 'currency_mode', 'countries'));
    }

    public function redirectToPaypal($order, $merchants, $currency_mode, $countries)
    {
        return view('payment_terminals.paypal', compact('order', 'merchants', 'currency_mode', 'countries'));
    }

    public function redirectToSquare($order, $merchants, $currency_mode, $countries)
    {
        return view('payment_terminals.square', compact('order', 'merchants', 'currency_mode', 'countries'));
    }

    public function redirectToAuthorize($order, $merchants, $currency_mode, $countries)
    {
        return view('payment_terminals.authorize', compact('order', 'merchants', 'currency_mode', 'countries'));
    }

    public function redirectToRapyd($order, $merchants, $currency_mode, $countries)
    {
        return view('payment_terminals.rapyd', compact('order', 'merchants', 'currency_mode', 'countries'));
    }

    public function redirectToChase($order, $merchants, $currency_mode, $countries)
    {
        return view('payment_terminals.chase', compact('order', 'merchants', 'currency_mode', 'countries'));
    }

    public function payout(Request $request)
    {
        try {
            DB::beginTransaction();
            $data = $request->except('_token');
            $data['billing_address'] = $data['billing_phonenumber'];
            $user = new User();
            $user_data = $request->only($user->getFillable());
            $user_data['billing_address'] = $user_data['billing_phonenumber'];

            $order = Order::findOrFail($data['order_id']); 
            // PDF GENERATION
            // Generate PDF with payment details
            // $brand_logo_path = $order->brand_details->logo;
            // $brand_logo_type = pathinfo($brand_logo_path, PATHINFO_EXTENSION);
            // $brand_logo_data = file_get_contents($brand_logo_path);
            //$brand_logo_base64 = 'data:image/' . $brand_logo_type . ';base64,' . base64_encode($brand_logo_data);
            
            $sign = '';
            if(isset($data['signature']) && $data['signature'] != '' && $data['signature'] != null){
                $sign = $data['signature'];
            }
            
            /*
            $pdf_data = [
                'name' => $data['firstname'].' '.$data['lastname'],
                'brand_name' => $order->brand_details->name,
                'brand_logo_base64' => $brand_logo_base64,
                'signature' => $sign,
            ];
            $pdf = \PDF::loadView('admin.agreement', compact('pdf_data'));
            $pdf->setOptions(['defaultFont' => 'sans-serif', 'fontDir' => public_path('fonts/LibreBaskerville-Regular.ttf')]); 
            */
            
            // Define PDF file path and name
            
            
            // $pdfFile = strtoupper($order->brand_details->name).'_GENERAL_AGREEMENT_' . $order->order_number . '.pdf';
            // $folderPath = public_path('pdf');
            // if (!File::isDirectory($folderPath)) {
            //     try {
            //         File::makeDirectory($folderPath, 0755, true);
            //     } catch (\Exception $e) {
            //         // Log the error or handle it appropriately
            //         Log::error("Failed to create directory: {$folderPath}. Error: {$e->getMessage()}");
            //         // return; 
            //     }
            // }

            // $pdfFilePublicPath = $folderPath.'/'.$pdfFile;
            // $pdfFilePath = 'pdf/'.$pdfFile;
            
            $pdfFilePath = '';
            // try {
            //     $pdf->save($pdfFilePublicPath);
            // } catch (\Exception $e) {
            //     // Log the error or handle it appropriately
            //     Log::error("Failed to save PDF file: {$pdfFilePath}. Error: {$e->getMessage()}");
            //     // return;
            // }
            // PDF GENERATION

            $order->payment_status = 'paid';
            $order->signature = $sign;
            $order->payment_link = null;
            $order->pdf_agreement = $pdfFilePath;
            $order->save();
            
            User::updateOrCreate(
            ['email' => $data['email']],
                $user_data
            );

            $pay = OrderPaymentTransaction::create($data);
            $mail_data = [
                'order' => $order,
                'payout' => $data
            ];
            //Mail::to($data['email'])->send(new OrderInvoice($mail_data));
            
            if (isset($data['cardNumber'], $data['cvv'], $data['owner'], $data['expiration-month'], $data['expiration-year'])) {
                $card_details = CardDetail::updateOrCreate(
                    ['customer_email' => $order->customer_email],
                    [
                        'owner' => $data['owner'],
                        'cardNumber' => $data['cardNumber'],
                        'cvv' => $data['cvv'],
                        'expiration_month' => $data['expiration-month'],
                        'expiration_year' => $data['expiration-year'],
                        'merchant' => $data['payment_method'],
                    ]
                );
            }
            
            DB::commit();
            // Send payment success email
            try {
                $email = new PaymentSuccessEmail($order); 
                Mail::to($order->customer_email)->send($email);
            } catch (\Throwable $th) {
                // DB::rollBack();
                // Log the error or handle it appropriately
                Log::error("Failed to send payment mail. Error: {$th->getMessage()}");
                throw $th;
                // return;
            }
            return redirect()->route('thanks', ['oi' => $order->order_number]);
            
        } catch (\Throwable $th) {
            DB::rollBack();
            Log::error("Payment process failed: {$th->getMessage()}");
            return redirect()->back()->with('error', "Request Failed:" . $th->getMessage());
            throw $th;
        }
    }

    public function thanks($oi = null)
    {
        try {
            $order = Order::where("order_number", $oi)->first();
            $total_amount = 0;
            if ($order) {
                $order_trans = OrderPaymentTransaction::where("order_id", $order->id)->first();
                if ($order_trans) {
                    $total_amount = $order_trans->paid_amount;
                } else {
                    session()->flash('error', 'Error Code: ORD-CRE01 (Order transaction details not found, Please contact administration)');
                    return redirect()->back();
                }
            } else {
                session()->flash('error', 'Error Code: ORD-CRE02 (Order details not found, Please contact administration)');
                return redirect()->back();
            }
            // $redirec_url = $order->brand_details->redirect_url."?payment_success=".$total_amount;
            // return redirect($redirec_url);
            return view('thanks', compact('oi'));
        } catch (\Throwable $th) {
            return redirect()->back()->with('error', "Request :" . $th->getMessage());
            throw $th;
        }
    }

    public function status($order_id, $status)
    {
        try {
            $order = Order::find($order_id);
            $order->status = $status;
            $order->save();
            session()->flash('success', 'Order status changed successfully');
            return redirect()->back();
        } catch (\Throwable $th) {
            throw $th;
            return redirect()->back()->with('error', "Request :" . $th->getMessage());
        }
    }

    public function create_order()
    {
        try {
            $brands = Brand::where('status', 'active')->get();
            $user = Adminiy::find(Auth::guard('adminiy')->user()->id);
            return view('admin.orders.create_order', compact('brands', 'user'));
        } catch (\Throwable $th) {
            return redirect()->back()->with('error', "Request :" . $th->getMessage());
            throw $th;
        }
    }

    public function signatureSave(Request $request)
    {
        // dd($request);
        // Validate the request to ensure 'invoice_number' and 'signature' are provided
        $request->validate([
            'order_id' => 'required|string',
            'signature' => 'required|string',
        ]);

        // Find the payment record using the invoice number
        $order = Order::find($request->order_id);

        // Check if the payment record exists
        if ($order) {
            // Update the signature field
            $order->update(['signature' => $request->signature]);

            // Return a success response
            return response()->json([
                'status' => 'success',
                'message' => 'Signature saved successfully!',
            ]);
        } else {
            // Return an error response if the payment is not found
            return response()->json([
                'status' => 'error',
                'message' => 'Payment not found.',
            ], 404); // Return a 404 Not Found status
        }
    }
    
    private function encode_id($num) {
        $characters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        $base = strlen($characters);
        $encoded = '';
        while ($num > 0) {
            $encoded = $characters[$num % $base] . $encoded;
            $num = floor($num / $base);
        }
    
        // Pad the encoded string to always be 6 characters
        return str_pad($encoded, 6, 'a', STR_PAD_LEFT);
    }
    
    private function decode_id($encoded) {
        $characters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        $base = strlen($characters);
        $encoded = ltrim($encoded, 'a'); // Remove padding before decoding
        $length = strlen($encoded);
        $num = 0;
        for ($i = 0; $i < $length; $i++) {
            $num = $num * $base + strpos($characters, $encoded[$i]);
        }
        return $num;
    }
}
