<?php

use App\Models\Brand;
use App\Models\BrandMerchant;
use App\Models\Currency;
function get_brand_merchants($id){
 
    $merchants = BrandMerchant::where('brand_id',$id)->where('brand_merchants.status','active')->get();
    
    return $merchants;
}

function admin_get_brand_merchants($id){
 
    $merchants = BrandMerchant::where('brand_id',$id)->get();
    
    return $merchants;
}

function get_merchant_keys($brand_id,$merchant_id){
 
    $config_keys = BrandMerchant::where('brand_id',$brand_id)->where('merchant_id',$merchant_id)->where('brand_merchants.status','active')->pluck('config_keys')->first();
    
    return $config_keys;
}

function get_countries(){
 
    $countries = Currency::pluck('country')->toArray();
    
    return $countries;
}