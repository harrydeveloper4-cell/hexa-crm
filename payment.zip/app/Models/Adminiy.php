<?php
namespace App\Models;

use App\BaseModel;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Auth\Authenticatable;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Auth\Passwords\CanResetPassword;
use Illuminate\Foundation\Auth\Access\Authorizable;
use Illuminate\Contracts\Auth\Authenticatable as AuthenticatableContract;
use Illuminate\Contracts\Auth\Access\Authorizable as AuthorizableContract;
use Illuminate\Contracts\Auth\CanResetPassword as CanResetPasswordContract;
use Illuminate\Support\Facades\Validator;
use Auth;

class Adminiy extends Model implements AuthenticatableContract,
AuthorizableContract,
CanResetPasswordContract
{

    use Authenticatable, Authorizable, CanResetPassword;
    /**
     * The database table used by the model.
     *
     * @var string
     */


	protected $table = 'adminiy';
    protected $fillable = [
        'name', 'email', 'password',
    ];
    protected $hidden = [
        'password', 'remember_token',
    ];
    
    public function has_permission($id){
        $user = Auth::guard('adminiy')->user();
        $permission = UserPermissions::where("permissions_id" , $id)->where("user_id" , $user->id)->first();
        if($permission){
            return true;
        }else{
            return false;
        }
    }
    
    public function has_brand($id){
        $user = Auth::guard('adminiy')->user();
        $brand = UserBrand::where("brand_id" , $id)->where("user_id" , $user->id)->first();
        if($brand){
            return true;
        }else{
            return false;
        }
    }
    
}
