<?php

namespace App\Models;

use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use App\Models\UserPermissions;

class User extends Authenticatable
{
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
     protected $fillable = ['role_id','firstname','lastname','billing_address','country','state','city','postalcode','email','billing_phonenumber'];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];
    
    
    public function card_details(){
        return $this->belongsTo('App\Models\CardDetail','customer_email','email');
    }
    
    public function has_permission($id){
        $user = Auth::user();
        $permission = UserPermissions::where("permissions_id" , $id)->where("user_id" , $user->id)->first();
        if($permission){
            return $permission;
        }else{
            return null;
        }
    }
    
    
}
