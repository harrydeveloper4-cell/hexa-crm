<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Merchant extends Model
{
    use HasFactory;

    public function brands(){
         return $this->belongsToMany('App\Models\Brand','brand_merchants','brand_id','merchant_id');
    }

}
