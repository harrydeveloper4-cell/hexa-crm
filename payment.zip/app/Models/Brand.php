<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Brand extends Model
{
    use HasFactory;

    public function merchants(){

         return $this->belongsToMany('App\Models\Merchant','brand_merchants','brand_id','merchant_id');
    }
    
    public function packages(){
        return $this->hasMany('App\Models\Package','brand_id','id');
    }

    public function order(){
        return $this->hasMany('App\Models\Order','brand_name','id');
    }
}
