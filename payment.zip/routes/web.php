<?php

use App\Http\Controllers\ChasePaymentController;
use App\Models\Order;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\OrderController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\StripeController;
use App\Http\Controllers\SquareController;
use App\Http\Controllers\AuthorizenetController;
use App\Http\Controllers\RapydController;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\BrandController;
use App\Http\Controllers\PackageController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\InvoiceController;
use App\Http\Controllers\TransactionController;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Auth;
use function PHPUnit\Framework\returnArgument;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/order-agreement', function () {
    $order = Order::find(46);
    return view('mails.payment_successful',compact('order'));
});

Route::get('/storage-link', function () {
    Artisan::call('storage:link');
});

Route::get('/cache', function () {
    Artisan::call('cache:clear');
    Artisan::call('view:clear');
});

// Auth::routes();
// Guest Routes
Route::group(['middleware' => ['guest']], function () {

    Route::get("admin/login", [LoginController::class, 'login'])->name('admin.login');

    Route::post("admin/login", [LoginController::class, 'login_process'])->name('admin.login.process');
});

// Route::get('/generate-link',[HomeController::class,'index'])->name('home');
Route::get('/order/create', [OrderController::class, 'create_order'])->name('home');

Route::post('/brand_packages', [HomeController::class, 'brand_packages'])->name('brand.merchant.packages');


Route::get('order/create', [OrderController::class, 'create_order'])->name('payment.create_order');

Route::post('order_submit', [OrderController::class, 'order_store'])->name('order.submit');

Route::get('{brander}/order/{link}', [OrderController::class, 'payment_terminal'])->name('payment.terminal');

Route::post('payout', [OrderController::class, 'payout'])->name('payout');

Route::get('thanks/{oi?}', [OrderController::class, 'thanks'])->name('thanks');

Route::post('stripe_checkout', [StripeController::class, 'stripe_checkout'])->name('stripe.checkout');

Route::post('chase_checkout', [ChasePaymentController::class, 'chasePayment'])->name('chase.checkout');

Route::post('square_checkout', [SquareController::class, 'checkout_square'])->name('square.checkout');

Route::post('authorizenet_checkout', [AuthorizenetController::class, 'handleonlinepay'])->name('authorizenet.checkout');

Route::post('rapyd_checkout', [RapydController::class, 'checkout_rapyd'])->name('rapyd.checkout');

Route::get('rapyd_response/{data}', [RapydController::class, 'get_response'])->name('rapyd.response');

Route::put('orders/request-payment-link/{id}', [OrderController::class, 'request_payment_link'])->name('orders.request_payment_link');

Route::post('signature/save', [OrderController::class, 'signatureSave'])->name('signature.save');

Route::group(['middleware' => ['admin']], function () {

    Route::get('/', [AdminController::class, 'index'])->name('dashboard');

    Route::get('chnage-password', [AdminController::class, 'chnage_password'])->name('admin.chnage_password');
    Route::post('update-password', [AdminController::class, 'update_password'])->name('admin.update_password');

    Route::get('/brands', [BrandController::class, 'index'])->name('admin.brands.index');

    Route::get('brands/create', [BrandController::class, 'create'])->name('admin.brands.create');

    Route::post('brands/store', [BrandController::class, 'store'])->name('admin.brands.store');

    Route::get('brands/edit/{id}', [BrandController::class, 'edit'])->name('admin.brands.edit');

    Route::post('brands/update/{id}', [BrandController::class, 'update'])->name('admin.brands.update');

    Route::get('brands/destroy/{id}', [BrandController::class, 'destroy'])->name('admin.brands.destroy');

    Route::get('brand_merchant/status/{id}', [BrandController::class, 'merchant_status_change'])->name('merchant.status.change');

    Route::get('brand_merchant/destroy/{id}', [BrandController::class, 'destroy_brand_merchant'])->name('delete.brand.merchant');


    Route::get('packages', [PackageController::class, 'index'])->name('packages');

    Route::get('packages/create', [PackageController::class, 'create'])->name('packages.create');

    Route::post('packages/store', [PackageController::class, 'store'])->name('packages.store');

    Route::get('packages/edit/{id}', [PackageController::class, 'edit'])->name('packages.edit');

    Route::post('packages/update/{id}', [PackageController::class, 'update'])->name('packages.update');

    Route::post('packages/update_all', [PackageController::class, 'update_all'])->name('packages.update.all');
    
    Route::get('packages/destroy/{id}', [PackageController::class, 'destroy'])->name('packages.destroy');
    
    Route::get('brand/packages/edit', [PackageController::class, 'brand_packages_edit'])->name('brand.packages.edit');
    
    Route::get('brand/merchants/edit', [BrandController::class, 'brand_merchants_edit'])->name('brand.merchants.edit');
    
    Route::post('merchants/update_all', [BrandController::class, 'update_all'])->name('merchants.update.all');

    Route::get('brand/package/delete/{id}', [PackageController::class, 'delete_brand_package'])->name('delete.brand.package');

    Route::get('package/status/{id}', [PackageController::class, 'package_status_change'])->name('package.status.change');

    Route::get('orders', [OrderController::class, 'index'])->name('admin.orders.index');

    Route::get('orders/{email}', [OrderController::class, 'customer_orders'])->name('admin.customer.orders');

    Route::get('orders/create', [OrderController::class, 'create'])->name('admin.orders.create');

    Route::post('orders/store', [OrderController::class, 'store'])->name('admin.orders.store');

    Route::get('orders/show/{id}', [OrderController::class, 'show'])->name('admin.orders.show');

    Route::get('orders/edit/{id}', [OrderController::class, 'edit'])->name('admin.orders.edit');

    Route::post('orders/update/{id}', [OrderController::class, 'update'])->name('admin.orders.update');

    Route::get('orders/destroy/{id}', [OrderController::class, 'destroy'])->name('admin.orders.destroy');

    Route::get('orders/status/{id}/{status}', [OrderController::class, 'status'])->name('admin.orders.status');

    Route::get('invoices/{id}', [InvoiceController::class, 'index'])->name('admin.invoices.index');

    Route::get('transactions', [TransactionController::class, 'index'])->name('admin.transactions.index');

    Route::get('payment-recurring', [TransactionController::class, 'payment_recuring'])->name('admin.payments-recuring.index');

    Route::post('payment_recharge', [TransactionController::class, 'payment_recharge'])->name('payment_recharge');

    Route::post('customer_transactions', [TransactionController::class, 'customer_transactions'])->name('customer.transactions');

    Route::post('customer_card_details', [TransactionController::class, 'customer_card_details'])->name('customer.card.details');

    Route::get('merchant_configs', [TransactionController::class, 'merchant_configs'])->name('merchant.configs');

    Route::get('users', [UserController::class, 'index'])->name('users');

    Route::get('users/show/{id}', [UserController::class, 'show'])->name('users.show');

    Route::get('users/create', [UserController::class, 'create'])->name('users.create');

    Route::post('users/store', [UserController::class, 'store'])->name('users.store');

    Route::get('users/edit/{id}', [UserController::class, 'edit'])->name('users.edit');

    Route::post('users/update/{id}', [UserController::class, 'update'])->name('users.update');

    Route::get('users/destroy/{id}', [UserController::class, 'destroy'])->name('users.destroy');

    Route::get('admins', [UserController::class, 'admins_list'])->name('admins.list');
    Route::get('admins/destroy/{id}', [UserController::class, 'admin_destroy'])->name('admins.destroy');
    Route::post('/admins/updateAjax', [UserController::class, 'updateAjax'])->name('admins.updateAjax');
    Route::post('/admins/statusToggle', [UserController::class, 'statusToggle'])->name('admins.statusToggle');

    

    // Route::get('setings', [SettingController::class, 'setings'])->name('settings');

    Route::get('/logout', [LoginController::class, 'logout'])->name('logout');
});