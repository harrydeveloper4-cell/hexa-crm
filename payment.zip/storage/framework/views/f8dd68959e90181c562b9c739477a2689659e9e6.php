
<?php $__env->startSection('title', 'Users'); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb-title'); ?>
    <h3><?php echo e(__('Edit')); ?></h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb-items'); ?>
    <li class="breadcrumb-item"><a href="<?php echo e(route('users')); ?>"><?php echo e(__('Users')); ?></a></li>
    <li class="breadcrumb-item active"><?php echo e(__('Edit')); ?></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12 mt-4">
            <div class="card">
                <div class="card-header">
                    <h6 class="card-title">User Edit</h6>
                    <a class = "btn btn-info float-right" href = "<?php echo e(route('users')); ?>">Back</a>
                </div>
                <div class="card-content">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-12">
                                <form action = "<?php echo e(route('users.update', ['id' => $user->id])); ?>" method = "POST"
                                    id = "create_user">
                                    <?php echo csrf_field(); ?>
                                    <div class="row">
                                        <div class="col-md-12 col-lg-12 col-xl-12">
                                            <label>User Type</label>
                                            <select class="form-control rounded" name = "role_id">
                                                <option value = "">Select User Type</option>
                                                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value = "<?php echo e($role->id); ?>"
                                                        <?php echo e($user->role_id == $role->id ? 'selected' : ''); ?>><?php echo e($role->role); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="col-md-6 col-lg-6 col-xl-6">
                                            <label>First Name</label>
                                            <input class="form-control rounded" type="text" name="firstname"
                                                value="<?php echo e($user->firstname ?? ''); ?>" placeholder="Thomas D">
                                            <?php $__errorArgs = ['firstname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class = "error"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="col-md-6 col-lg-6 col-xl-6">
                                            <label>Last Name</label>
                                            <input class="form-control rounded" type="text" name="lastname"
                                                value="<?php echo e($user->lastname ?? ''); ?>" placeholder="Hardison">
                                            <?php $__errorArgs = ['lastname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class = "error"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="col-md-6 col-lg-6 col-xl-6">
                                            <label>Email</label>
                                            <input class="form-control rounded" type="email" name="email"
                                                value="<?php echo e($user->email ?? ''); ?>" placeholder="thomasdhardison@lorem.com">
                                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class = "error"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="col-md-6 col-lg-6 col-xl-6">
                                            <label>Contact Number</label>
                                            <input class="form-control rounded" type="number" name="billing_phonenumber"
                                                value="<?php echo e($user->billing_phonenumber ?? ''); ?>"
                                                placeholder="123-656-789 (0)">
                                            <?php $__errorArgs = ['billing_phonenumber'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class = "error"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="col-md-12 col-lg-12 col-xl-12">
                                            <label>Address</label>
                                            <input class="form-control rounded" type="text" name="billing_address"
                                                value="<?php echo e($user->billing_address ?? ''); ?>" placeholder="12345 Lane Street">
                                            <?php $__errorArgs = ['billing_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class = "error"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="col-md-12 col-lg-6 col-xl-6">
                                            <label>Country</label>
                                            <select id="country" name="country" class="form-control rounded">
                                                <?php $__currentLoopData = get_countries(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($country); ?>"
                                                        <?php echo e($user->country == $country ? 'selected' : ''); ?>><?php echo e($country); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class = "error"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="col-md-6 col-lg-6 col-xl-6">
                                            <label>State</label>
                                            <input class="form-control rounded" type="text" name="state"
                                                value="<?php echo e($user->state ?? ''); ?>" placeholder="State">
                                        </div>
                                        <div class="col-md-6 col-lg-6 col-xl-6">
                                            <label>City</label>
                                            <input class="form-control rounded" type="text" name="city"
                                                value="<?php echo e($user->city ?? ''); ?>" placeholder="City">
                                        </div>

                                        <div class="col-md-6 col-lg-6 col-xl-6">
                                            <label>Zip Code</label>
                                            <input class="form-control rounded" type="text" name="postalcode"
                                                value="<?php echo e($user->postalcode ?? ''); ?>" placeholder="12345678">
                                        </div>
                                        <div class="col-md-6 col-lg-6 col-xl-6">
                                            <span id = "card-details">
                                                <div class="row">
                                                    <div class="form-group owner col-md-12">
                                                        <label for="owner">Owner</label>
                                                        <input type="text" class="form-control" id="owner"
                                                            name="owner" value="<?php echo e(old('owner')); ?>" required>
                                                        <span id="owner-error" class="error text-red">Please enter owner
                                                            name</span>
                                                    </div>
                                                </div>


                                                <div class="row">
                                                    <div class="form-group col-md-8" id="card-number-field">
                                                        <label for="cardNumber">Card Number</label>
                                                        <input type="text" class="form-control" id="cardNumber"
                                                            data-card="<?php echo e(isset($user_card) ? $user_card->cardNumber : ''); ?>"
                                                            name="cardNumber" value="<?php echo e(old('cardNumber')); ?>" required>
                                                        <span id="show-cc-label"></span> <span id="card-error"
                                                            class="error text-red">Please enter valid card number</span>
                                                    </div>
                                                    <div class="form-group CVV col-md-4">
                                                        <label for="cvv">CVV</label>
                                                        <input type="text" class="form-control" id="cvv"
                                                            data-cvv="<?php echo e(isset($user_card) ? $user_card->cvv : ''); ?>"
                                                            name="cvv" value="<?php echo e(old('cvv')); ?>" required>
                                                        <span id="cvv-error" class="error text-red">Please enter
                                                            cvv</span>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="form-group col-md-6" id="expiration-date">
                                                        <label>Expiration Date</label><br />
                                                        <select class="form-control" id="expiration-month"
                                                            name="expiration-month"
                                                            style="float: left; width: 100px; margin-right: 10px;">

                                                            <option value="01">January</option>
                                                            <option value="02">February </option>
                                                            <option value="03">March</option>
                                                            <option value="04">April</option>
                                                            <option value="05">May</option>
                                                            <option value="06">June</option>
                                                            <option value="07">July</option>
                                                            <option value="08">August</option>
                                                            <option value="09">September</option>
                                                            <option value="10">October</option>
                                                            <option value="11">November</option>
                                                            <option value="12">December</option>

                                                        </select>
                                                        <select class="form-control" id="expiration-year"
                                                            name="expiration-year" style="float: left; width: 100px;">
                                                            <?php for($i = date('Y'); $i <= date('Y') + 15; $i++): ?>
                                                                <option <?php if(isset($user_card) && $user_card != null && $user_card->expiration_month == $i): ?> selected <?php endif; ?>
                                                                    value="<?php echo e($i); ?>"><?php echo e($i); ?>

                                                                </option>
                                                            <?php endfor; ?>
                                                        </select>
                                                    </div>
                                                    <div class="form-group col-md-6" id="credit_cards"
                                                        style="margin-top: 22px;">
                                                        <img src="<?php echo e(asset('images/visa.png')); ?>" id="visa">
                                                        <img src="<?php echo e(asset('images/mastercard.png')); ?>" id="mastercard">
                                                        <img src="<?php echo e(asset('images/amex.jpg')); ?>" id="amex"
                                                            width="40" height="25">
                                                    </div>
                                                </div>
                                            </span>
                                        </div>

                                        <div class="col-md-12 col-lg-12 col-xl-12">
                                            <button class = "btn btn-primary" type="submit">
                                                Save
                                            </button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js"></script>
    <script>
        $('#create_user').validate({
            rules: {
                role_id: 'required',
                firstname: 'required',
                lastname: 'required',
                email: 'required',
                billing_phonenumber: 'required',
                billing_address: 'required',
                state: 'required',
                city: 'required',
                postalcode: 'required',
                country: 'required',
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\payment\resources\views/admin/users/edit.blade.php ENDPATH**/ ?>