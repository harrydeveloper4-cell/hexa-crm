<?php
    $user = App\Models\Adminiy::find(Auth::guard('adminiy')->user()->id);
?>

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('css'); ?>
    <style>
        .custom-way-h {
            overflow-y: scroll;
            height: 387px;
            overflow-x: hidden;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb-title'); ?>
    <h3><?php echo e(__('Dashboard')); ?></h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb-items'); ?>
    <li class="breadcrumb-item active"><?php echo e(__('Dashboard')); ?></li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12 col-lg-12 mt-3">
            <div class="row">
                <div class="col-12 col-lg-6">
                    <div class="row">
                        <div class="col-12 col-sm-6 mt-3">
                            <div class="card bg-primary">
                                <div class="card-body">
                                    <div class="d-flex px-0 px-lg-2 py-2 align-self-center">
                                        <i class="icon-basket icons card-liner-icon mt-2 text-white"></i>
                                        <div class="card-liner-content">
                                            <h2 class="card-liner-title text-white">$ <?php echo e($data['all_dues']); ?></h2>
                                            <h6 class="card-liner-subtitle text-white">Total Orders
                                                (<?php echo e($data['total_order_count']); ?>)</h6>
                                        </div>
                                    </div>
                                    <div id="apex_primary_chart"></div>
                                </div>
                            </div>
                        </div>

                        <div class="col-12 col-sm-6 mt-3">
                            <div class="card bg-primary">
                                <div class="card-body">
                                    <div class="d-flex px-0 px-lg-2 py-2 align-self-center">
                                        <i class="icon-basket icons card-liner-icon mt-2 text-white"></i>
                                        <div class="card-liner-content">
                                            <h2 class="card-liner-title text-white">$ <?php echo e($data['today_dues']); ?></h2>
                                            <h6 class="card-liner-subtitle text-white">Today's Orders
                                                (<?php echo e($data['today_order_count']); ?>)</h6>
                                        </div>
                                    </div>
                                    <div id="apex_primary_chart_2"></div>
                                </div>
                            </div>
                        </div>

                        <div class="col-12 col-sm-6 mt-3">
                            <div class="card">
                                <div class="card-body">
                                    <div class="d-flex px-0 px-lg-2 py-2 align-self-center">
                                        <i class="icon-bag icons card-liner-icon mt-2"></i>
                                        <div class="card-liner-content">
                                            <h2 class="card-liner-title">$ <?php echo e($data['all_paid']); ?></h2>
                                            <h6 class="card-liner-subtitle">Total Sale
                                                (<?php echo e($data['total_paid_count']); ?>)</h6>
                                        </div>
                                    </div>
                                    <div id="apex_today_profit"></div>
                                </div>
                            </div>
                        </div>

                        <div class="col-12 col-sm-6 mt-3">
                            <div class="card">
                                <div class="card-body">
                                    <div class="d-flex px-0 px-lg-2 py-2 align-self-center">
                                        <i class="icon-bag icons card-liner-icon mt-2"></i>
                                        <div class="card-liner-content">
                                            <h2 class="card-liner-title">$ <?php echo e($data['today_paid']); ?></h2>
                                            <h6 class="card-liner-subtitle">Today's Sale
                                                (<?php echo e($data['today_paidorder_count']); ?>)</h6>
                                        </div>
                                    </div>
                                    <div id="apex_today_profit_2"></div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="col-12 col-lg-6 mt-3">
                    <div class="card">
                        <div class="card-content">
                            <div class="card-body">
                                <div id="apex_bar_chart" class="height-500"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <?php if($user->has_permission(5) || $user->role_id == 1): ?>
            <div class="col-md-6 col-lg-6 mt-3">
                <div class="card overflow-hidden">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h6 class="card-title">New Users</h6>
                    </div>
                    <div class="card-content">
                        <div class="card-body p-0 custom-way-h">
                            <ul class="list-group list-unstyled">
                                <?php if(isset($all_users) && count($all_users) > 0): ?>
                                    <?php $__currentLoopData = $all_users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="p-2 border-bottom zoom">
                                            <div class="media d-flex w-100">
                                                <a href="#"><img src="https://w7.pngwing.com/pngs/81/570/png-transparent-profile-logo-computer-icons-user-user-blue-heroes-logo-thumbnail.png"
                                                        alt="" class="img-fluid ml-0 mt-2 rounded-circle"
                                                        width="40" />
                                                </a>
                                                <div class="media-body align-self-center pl-2">
                                                    <span class="mb-0 font-w-600"><?php echo e($user->firstname); ?>

                                                        <?php echo e($user->lastname); ?></span><br />
                                                    <span class="mb-0 font-w-600"><?php echo e($user->email); ?></span><br />
                                                    <p class="mb-0 font-w-500 tx-s-12"><?php echo e($user->city); ?>,
                                                        <?php echo e($user->state); ?>, <?php echo e($user->country); ?></p>
                                                </div>
                                                <div class="ml-auto my-auto">
                                                    <a href="#" data-toggle="dropdown">
                                                        <i class="icon-options icons h6 font-weight-bold"></i>
                                                    </a>
                                                    <div class="dropdown-menu dropdown-menu-right">
                                                        <!--<a href="" class="dropdown-item px-2 align-self-center d-flex"> <span class="icon-pencil mr-2 h6 mb-0"></span> Edit Profile</a>-->
                                                        <a href="<?php echo e(route('users.show', $user->id)); ?>"
                                                            class="dropdown-item px-2 align-self-center d-flex">
                                                            <span class="icon-user mr-2 h6 mb-0"></span> View
                                                            Profile</a>
                                                        <!--<a href="" class="dropdown-item px-2 text-danger align-self-center d-flex"> <span class="icon-trash mr-2 h6 mb-0"></span> Delete</a>-->
                                                    </div>
                                                </div>
                                            </div>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>

                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
        <div class="col-12 col-md-12 col-lg-6 mt-3">
            <div class="card">
                <div class="card-header justify-content-between align-items-center">
                    <h6 class="card-title">Sales per Brand</h6>
                </div>
                <div class="card-body table-responsive p-0">
                    <table class="table font-w-600 mb-0">
                        <thead>
                            <tr>
                                <th>Brand Name</th>
                                <th></th>
                                <th>Order</th>
                                <th>Total Sales</th>
                            </tr>
                        </thead>
                        <tbody>

                            <?php if($brand_orders): ?>
                                <?php $__currentLoopData = $brand_orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $temp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="zoom">
                                        <td><?php echo e($temp['brand_name']); ?></td>
                                        <td class="text-success"><i class="ion ion-arrow-graph-up-right"></i></td>
                                        <td class="text-danger"><?php echo e($temp['order_status']); ?> <i
                                                class="ion ion-arrow-graph-down-right"></i></td>
                                        <td class="text-info">$ <?php echo e($temp['total_amount']); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        

    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('admin/dist/vendors/apexcharts/apexcharts.min.js')); ?>"></script>
    <script>
        var theme = "light";
        if ($("#apex_bar_chart").length > 0) {
            options = {
                theme: {
                    mode: theme,
                },
                grid: {
                    yaxis: {
                        lines: {
                            show: false,
                        },
                    },
                },
                chart: {
                    height: 318,
                    type: "bar",
                },
                plotOptions: {
                    bar: {
                        horizontal: true,
                        columnWidth: "10",
                    },
                },
                dataLabels: {
                    enabled: false,
                },
                colors: ["#1e3d73"],
                series: [{
                    data: [<?php echo e($data['months_report_amount']); ?>],
                }, ],
                xaxis: {
                    categories: [<?= $data['months_report_name'] ?>],
                },
            };

            var chart = new ApexCharts(document.querySelector("#apex_bar_chart"), options);
            chart.render();
        }

        if ($("#apex_primary_chart").length > 0) {
            options = {
                chart: {
                    type: "line",
                    height: 80,
                    sparkline: {
                        enabled: true,
                    },
                    dropShadow: {
                        enabled: true,
                        top: 1,
                        left: 1,
                        blur: 2,
                        color: "#ef4336",
                        opacity: 0.7,
                    },
                },
                series: [{
                    data: [<?php echo e($data['total_order_generated']); ?>],
                }, ],
                stroke: {
                    curve: "smooth",
                    width: 2,
                },
                markers: {
                    size: 0,
                },
                grid: {
                    padding: {
                        top: 0,
                        bottom: 0,
                        left: 0,
                    },
                },
                colors: ["#ef4336"],
                tooltip: {
                    x: {
                        show: false,
                    },
                    y: {
                        title: {
                            formatter: function formatter(val) {
                                return "";
                            },
                        },
                    },
                },
                responsive: [{
                        breakpoint: 1351,
                        options: {
                            chart: {
                                height: 95,
                            },
                            grid: {
                                padding: {
                                    top: 35,
                                    bottom: 0,
                                    left: 0,
                                },
                            },
                        },
                    },
                    {
                        breakpoint: 1200,
                        options: {
                            chart: {
                                height: 80,
                            },
                            grid: {
                                padding: {
                                    top: 35,
                                    bottom: 0,
                                    left: 40,
                                },
                            },
                        },
                    },
                    {
                        breakpoint: 576,
                        options: {
                            chart: {
                                height: 95,
                            },
                            grid: {
                                padding: {
                                    top: 45,
                                    bottom: 0,
                                    left: 0,
                                },
                            },
                        },
                    },
                ],
            };

            var chart = new ApexCharts(document.querySelector("#apex_primary_chart"), options);
            chart.render();
        }
        if ($("#apex_primary_chart_2").length > 0) {
            options = {
                chart: {
                    type: "line",
                    height: 80,
                    sparkline: {
                        enabled: true,
                    },
                    dropShadow: {
                        enabled: true,
                        top: 1,
                        left: 1,
                        blur: 2,
                        color: "#d9f3fd",
                        opacity: 0.7,
                    },
                },
                series: [{
                    data: [<?php echo e($data['today_order_generated']); ?>],
                }, ],
                stroke: {
                    curve: "smooth",
                    width: 2,
                },
                markers: {
                    size: 0,
                },
                grid: {
                    padding: {
                        top: 0,
                        bottom: 0,
                        left: 0,
                    },
                },
                colors: ["#d9f3fd"],
                tooltip: {
                    x: {
                        show: false,
                    },
                    y: {
                        title: {
                            formatter: function formatter(val) {
                                return "";
                            },
                        },
                    },
                },
                responsive: [{
                        breakpoint: 1351,
                        options: {
                            chart: {
                                height: 95,
                            },
                            grid: {
                                padding: {
                                    top: 35,
                                    bottom: 0,
                                    left: 0,
                                },
                            },
                        },
                    },
                    {
                        breakpoint: 1200,
                        options: {
                            chart: {
                                height: 80,
                            },
                            grid: {
                                padding: {
                                    top: 35,
                                    bottom: 0,
                                    left: 40,
                                },
                            },
                        },
                    },
                    {
                        breakpoint: 576,
                        options: {
                            chart: {
                                height: 95,
                            },
                            grid: {
                                padding: {
                                    top: 45,
                                    bottom: 0,
                                    left: 0,
                                },
                            },
                        },
                    },
                ],
            };

            var chart = new ApexCharts(document.querySelector("#apex_primary_chart_2"), options);
            chart.render();
        }
        if ($("#apex_today_profit").length > 0) {
            options = {
                chart: {
                    type: "line",
                    height: 80,
                    sparkline: {
                        enabled: true,
                    },
                    dropShadow: {
                        enabled: true,
                        top: 1,
                        left: 1,
                        blur: 2,
                        color: "#f89938",
                        opacity: 0.7,
                    },
                },
                series: [{
                    data: [<?php echo e($data['total_paid_generated']); ?>],
                }, ],
                stroke: {
                    curve: "smooth",
                    width: 2,
                },
                markers: {
                    size: 0,
                },
                grid: {
                    padding: {
                        top: 0,
                        bottom: 0,
                        left: 0,
                    },
                },
                colors: ["#f89938"],
                tooltip: {
                    x: {
                        show: false,
                    },
                    y: {
                        title: {
                            formatter: function formatter(val) {
                                return "";
                            },
                        },
                    },
                },
                responsive: [{
                        breakpoint: 1351,
                        options: {
                            chart: {
                                height: 95,
                            },
                            grid: {
                                padding: {
                                    top: 35,
                                    bottom: 0,
                                    left: 0,
                                },
                            },
                        },
                    },
                    {
                        breakpoint: 1200,
                        options: {
                            chart: {
                                height: 80,
                            },
                            grid: {
                                padding: {
                                    top: 35,
                                    bottom: 0,
                                    left: 40,
                                },
                            },
                        },
                    },
                    {
                        breakpoint: 576,
                        options: {
                            chart: {
                                height: 95,
                            },
                            grid: {
                                padding: {
                                    top: 45,
                                    bottom: 0,
                                    left: 0,
                                },
                            },
                        },
                    },
                ],
            };

            var chart = new ApexCharts(document.querySelector("#apex_today_profit"), options);
            chart.render();
        }
        if ($("#apex_today_profit_2").length > 0) {
            options = {
                chart: {
                    type: "line",
                    height: 80,
                    sparkline: {
                        enabled: true,
                    },
                    dropShadow: {
                        enabled: true,
                        top: 1,
                        left: 1,
                        blur: 2,
                        color: "#ef4336",
                        opacity: 0.7,
                    },
                },
                series: [{
                    data: [<?php echo e($data['today_paidorder_generated']); ?>],
                }, ],
                stroke: {
                    curve: "smooth",
                    width: 2,
                },
                markers: {
                    size: 0,
                },
                grid: {
                    padding: {
                        top: 0,
                        bottom: 0,
                        left: 0,
                    },
                },
                colors: ["#ef4336"],
                tooltip: {
                    x: {
                        show: false,
                    },
                    y: {
                        title: {
                            formatter: function formatter(val) {
                                return "";
                            },
                        },
                    },
                },
                responsive: [{
                        breakpoint: 1351,
                        options: {
                            chart: {
                                height: 95,
                            },
                            grid: {
                                padding: {
                                    top: 35,
                                    bottom: 0,
                                    left: 0,
                                },
                            },
                        },
                    },
                    {
                        breakpoint: 1200,
                        options: {
                            chart: {
                                height: 80,
                            },
                            grid: {
                                padding: {
                                    top: 35,
                                    bottom: 0,
                                    left: 40,
                                },
                            },
                        },
                    },
                    {
                        breakpoint: 576,
                        options: {
                            chart: {
                                height: 95,
                            },
                            grid: {
                                padding: {
                                    top: 45,
                                    bottom: 0,
                                    left: 0,
                                },
                            },
                        },
                    },
                ],
            };

            var chart = new ApexCharts(document.querySelector("#apex_today_profit_2"), options);
            chart.render();
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/allinflo/public_html/portal.allinflo.com/resources/views/admin/index.blade.php ENDPATH**/ ?>