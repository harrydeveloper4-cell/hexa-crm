<!-- START: Header-->
<div id="header-fix" class="header fixed-top">
    <div class="site-width">
        <nav class="navbar navbar-expand-lg  p-0">
            <a href="<?php echo e(route('dashboard')); ?>" class="horizontal-logo text-left">
                <img src="<?php echo e(asset('admin/images/logo-t.png')); ?>" style="width: 60px;" />
            </a>
            <div class="navbar-header  h-100 h4 mb-0 align-self-center logo-bar text-left">

            </div>
            <div class="navbar-header h4 mb-0 text-center h-100 collapse-menu-bar">
                <a href="#" class="sidebarCollapse" id="collapse"><i class="icon-menu"></i></a>
            </div>

            
            <div class="navbar-right ml-auto h-100">
                <ul class="ml-auto p-0 m-0 list-unstyled d-flex top-icon h-100">
                    

                    <li class="dropdown align-self-center d-inline-block">
                        <a href="#" class="nav-link bell-notify" data-toggle="dropdown"
                            aria-expanded="false"><i class="icon-bell h4"></i>
                            <span class = "notify">
                            </span>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-right border   py-0" id = "notifications">
                        </ul>
                    </li>
                    <li class="dropdown user-profile align-self-center d-inline-block">
                        <a href="#" class="nav-link py-0" data-toggle="dropdown" aria-expanded="false">
                            <div class="media">
                                <img src="https://w7.pngwing.com/pngs/81/570/png-transparent-profile-logo-computer-icons-user-user-blue-heroes-logo-thumbnail.png"
                                    alt="" class="d-flex img-fluid rounded-circle" width="29">
                            </div>
                        </a>

                        <div class="dropdown-menu border dropdown-menu-right p-0">
                            <a href="" class="dropdown-item px-2 align-self-center d-flex">
                                <span class="icon-globe mr-2 h6 mb-0"></span> Visit Website</a>
                            <div class="dropdown-divider"></div>
                            <a href="<?php echo e(route('logout')); ?>"
                                class="dropdown-item px-2 text-danger align-self-center d-flex">
                                <span class="icon-logout mr-2 h6  mb-0"></span> Sign Out</a>
                        </div>

                    </li>

                </ul>
            </div>
        </nav>
    </div>
</div>
<!-- END: Header-->

<?php $__env->startSection('scripts'); ?>
    
<?php $__env->stopSection(); ?>
<?php /**PATH D:\xamppp-73\htdocs\dtek_payment_terminal\resources\views/admin/layout/header.blade.php ENDPATH**/ ?>