
<?php $__env->startSection('title', 'Packages'); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb-title'); ?>
    <h3><?php echo e(__('Packages Edit')); ?></h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb-items'); ?>
    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.brands.index')); ?>"><?php echo e(__('Brands')); ?></a></li>
    <li class="breadcrumb-item active"><?php echo e(__('Packages Edit')); ?></li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12 mt-4">
            <div class="card">
                <div class="card-header">
                    <h6 class="card-title">Package Edit</h6>
                    <a class = "btn btn-info float-right" href = "<?php echo e(route('admin.brands.index')); ?>">Back</a>
                </div>
                <div class="card-content">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-12">
                                <form action="<?php echo e(route('packages.update.all')); ?>" method="POST" id="package-form">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" class="form-control rounded" name="brand"
                                        value="<?php echo e($brand); ?>">

                                    <?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="form-row">
                                            <div class="form-group col-md-10">
                                                <label for="inputEmail4">Package Name</label>
                                                <input type="text" class="form-control rounded"
                                                    name="old_package_name[<?php echo e($package->id); ?>]" id="inputEmail4"
                                                    placeholder="Package Name" value="<?php echo e($package->package_name ?? ''); ?>">
                                                <!-- Display validation error for old_package_name -->
                                                <?php $__errorArgs = ["old_package_name.<?php echo e($package->id); ?>"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="text-danger"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <div class="form-group col-md-4" style="display:none">
                                                <label for="inputEmail4">Price</label>
                                                <input type="text" class="form-control rounded"
                                                    name="old_package_price[]" id="inputEmail4" placeholder="Package Price"
                                                    value="">
                                            </div>

                                            <div class="form-group col-md-2">
                                                <button type="button"
                                                    data-href="<?php echo e(route('delete.brand.package', ['id' => $package->id])); ?>"
                                                    class="btn btn-sm btn-danger delete-row" value="<?php echo e($package->id); ?>"><i
                                                        class="icon-trash"></i></button>
                                                <input type="checkbox" value="<?php echo e($package->id); ?>" class="change_status"
                                                    <?php echo e($package->status == 'active' ? 'checked' : ''); ?>

                                                    data-toggle="toggle" data-on="Active" data-off="Inactive"
                                                    data-href="<?php echo e(route('package.status.change', ['id' => $package->id])); ?>">
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <div class="form-row">
                                        <div class="form-group col-md-12">
                                            <button type="button" class="btn btn-sm btn-primary add-row"><i
                                                    class="icon-plus"></i></button>
                                        </div>
                                    </div>
                                    <div id="append-row">
                                        <?php if(isset($packages) && count($packages) == 0): ?>
                                            <div class="form-row">
                                                <div class="form-group col-md-10">
                                                    <label for="inputEmail4">Package Name</label>
                                                    <input type="text" class="form-control rounded" name="package_name[]"
                                                        id="inputEmail4" placeholder="Package Name" value="">
                                                    <!-- Display validation error for package_name -->
                                                </div>
                                                <div class="form-group col-md-4" style="display:none">
                                                    <label for="inputEmail4">Price</label>
                                                    <input type="text" class="form-control rounded"
                                                        name="package_price[]" id="inputEmail4" placeholder="Package Price"
                                                        value="">
                                                </div>
                                                <div class="form-group col-md-2">
                                                    <label for="inputEmail4"></label>
                                                    <button type="button" class="btn btn-sm btn-danger remove-row"
                                                        value=""><i class="icon-minus"></i></button>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                        <?php $__errorArgs = ['package_name.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="text-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="form-row">
                                        <input type="submit" value="Save" class="btn btn-primary">
                                    </div>
                                </form>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function() {
            $('#package-form').validate({
                rules: {
                    brand: 'required'
                }
            })


        })
    </script>
    <script type="text/javascript">
        // add row
        $(document).on('click', '.add-row', function() {
            var html =
                '<div class="form-row"> <div class="form-group col-md-10"> <label for="inputEmail4">Package Name</label> <input type="text" class="form-control rounded" name="package_name[]" id="inputEmail4" placeholder="Package Name" value="" > </div><div class="form-group col-md-4" style="display:none"> <label for="inputEmail4">Price</label> <input type="text" class="form-control rounded" name="package_price[]" id="inputEmail4" placeholder="Package Price" value="" > </div><div class="form-group col-md-2"> <label for="inputEmail4"></label><button type="button" class="btn btn-sm btn-danger remove-row" value=""><i class="icon-minus"></i></button> </div>';
            $('#append-row').append(html);
        });

        // remove row
        $(document).on('click', '.remove-row', function() {
            $(this).closest('.form-row').remove();
        });


        $(document).on('click', '.delete-row', function(e) {
            e.preventDefault();
            let element = $(this);
            let url = $(this).data('href');

            swal({
                title: "<?php echo e(__('Are you sure?')); ?>",
                text: "<?php echo e(__('Once deleted, you will not be able to recover this!')); ?>",
                icon: "warning",
                buttons: true,
                dangerMode: true,
            }).then((willDelete) => {
                if (willDelete) {
                    $.ajax({
                        url: url,
                        type: 'GET',
                        success: function(data) {
                            element.closest('.form-row').remove();
                            toastr.success('<?php echo e(__('Package has been deleted')); ?>');
                        },
                        error: function(err) {
                            toastr.error('<?php echo e(__('Package has not been deleted')); ?>');
                        }
                    });
                } else {
                    swal("<?php echo e(__('Your data is safe!')); ?>", {
                        icon: "info",
                        timer: 2000,
                    });
                }
            });
        });

        $(document).on('change', '.change_status', function() {

            let element = $(this);
            let status = '';
            let url = element.data('href')
            if (element.is(':checked')) {
                status = 'active';
            } else {
                status = 'inactive';
            }
            $.ajax({
                url: url,
                type: 'GET',
                data: {
                    status: status
                },
                success: function(data) {
                    console.log(data);
                    toastr.success('Status has been changed to ' + status);
                },
                error: function(err) {
                    toastr.error('Status has not been changed');
                }
            })
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\dtek_payment_terminal\resources\views/admin/packages/all_edit.blade.php ENDPATH**/ ?>