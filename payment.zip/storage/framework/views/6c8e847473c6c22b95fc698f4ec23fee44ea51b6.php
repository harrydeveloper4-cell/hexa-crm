<html>

<head>
    <meta content="text/html; charset=UTF-8" http-equiv="content-type" />
    <style type="text/css">
        @import  url(https://themes.googleusercontent.com/fonts/css?kit=pR0sBQVcY0JZc_ciXjFsK5y9kYW5VHv8HfZjDC02_a8ITPORH_hQriCcoQ2Y8llt);

        .lst-kix_lcbcmordipw4-2>li {
            counter-increment: lst-ctn-kix_lcbcmordipw4-2;
        }

        ol.lst-kix_lcbcmordipw4-4.start {
            counter-reset: lst-ctn-kix_lcbcmordipw4-4 0;
        }

        .lst-kix_lcbcmordipw4-8>li {
            counter-increment: lst-ctn-kix_lcbcmordipw4-8;
        }

        .lst-kix_lcbcmordipw4-0>li:before {
            content: "" counter(lst-ctn-kix_lcbcmordipw4-0, decimal) ". ";
        }

        .lst-kix_lcbcmordipw4-1>li:before {
            content: "" counter(lst-ctn-kix_lcbcmordipw4-1, lower-latin) ". ";
        }

        .lst-kix_lcbcmordipw4-3>li:before {
            content: "" counter(lst-ctn-kix_lcbcmordipw4-3, decimal) ". ";
        }

        .lst-kix_lcbcmordipw4-2>li:before {
            content: "" counter(lst-ctn-kix_lcbcmordipw4-2, lower-roman) ". ";
        }

        .lst-kix_lcbcmordipw4-4>li:before {
            content: "" counter(lst-ctn-kix_lcbcmordipw4-4, lower-latin) ". ";
        }

        .lst-kix_lcbcmordipw4-7>li:before {
            content: "" counter(lst-ctn-kix_lcbcmordipw4-7, lower-latin) ". ";
        }

        ol.lst-kix_lcbcmordipw4-0.start {
            counter-reset: lst-ctn-kix_lcbcmordipw4-0 0;
        }

        .lst-kix_lcbcmordipw4-1>li {
            counter-increment: lst-ctn-kix_lcbcmordipw4-1;
        }

        .lst-kix_lcbcmordipw4-6>li:before {
            content: "" counter(lst-ctn-kix_lcbcmordipw4-6, decimal) ". ";
        }

        .lst-kix_lcbcmordipw4-5>li:before {
            content: "" counter(lst-ctn-kix_lcbcmordipw4-5, lower-roman) ". ";
        }

        ol.lst-kix_lcbcmordipw4-8.start {
            counter-reset: lst-ctn-kix_lcbcmordipw4-8 0;
        }

        .lst-kix_lcbcmordipw4-8>li:before {
            content: "" counter(lst-ctn-kix_lcbcmordipw4-8, lower-roman) ". ";
        }

        .lst-kix_lcbcmordipw4-7>li {
            counter-increment: lst-ctn-kix_lcbcmordipw4-7;
        }

        ol.lst-kix_lcbcmordipw4-1.start {
            counter-reset: lst-ctn-kix_lcbcmordipw4-1 0;
        }

        ol.lst-kix_lcbcmordipw4-7.start {
            counter-reset: lst-ctn-kix_lcbcmordipw4-7 0;
        }

        ul.lst-kix_juslxf7j1ovd-7 {
            list-style-type: none;
        }

        ul.lst-kix_juslxf7j1ovd-6 {
            list-style-type: none;
        }

        .lst-kix_lcbcmordipw4-5>li {
            counter-increment: lst-ctn-kix_lcbcmordipw4-5;
        }

        ul.lst-kix_juslxf7j1ovd-5 {
            list-style-type: none;
        }

        ul.lst-kix_juslxf7j1ovd-4 {
            list-style-type: none;
        }

        .lst-kix_juslxf7j1ovd-0>li:before {
            content: "\0025cf   ";
        }

        ul.lst-kix_juslxf7j1ovd-3 {
            list-style-type: none;
        }

        ul.lst-kix_juslxf7j1ovd-2 {
            list-style-type: none;
        }

        ul.lst-kix_juslxf7j1ovd-1 {
            list-style-type: none;
        }

        ul.lst-kix_juslxf7j1ovd-0 {
            list-style-type: none;
        }

        .lst-kix_juslxf7j1ovd-2>li:before {
            content: "\0025a0   ";
        }

        .lst-kix_juslxf7j1ovd-1>li:before {
            content: "\0025cb   ";
        }

        .lst-kix_juslxf7j1ovd-3>li:before {
            content: "\0025cf   ";
        }

        ol.lst-kix_lcbcmordipw4-2.start {
            counter-reset: lst-ctn-kix_lcbcmordipw4-2 0;
        }

        ol.lst-kix_lcbcmordipw4-6.start {
            counter-reset: lst-ctn-kix_lcbcmordipw4-6 0;
        }

        ul.lst-kix_juslxf7j1ovd-8 {
            list-style-type: none;
        }

        .lst-kix_juslxf7j1ovd-6>li:before {
            content: "\0025cf   ";
        }

        .lst-kix_juslxf7j1ovd-5>li:before {
            content: "\0025a0   ";
        }

        .lst-kix_juslxf7j1ovd-7>li:before {
            content: "\0025cb   ";
        }

        .lst-kix_lcbcmordipw4-4>li {
            counter-increment: lst-ctn-kix_lcbcmordipw4-4;
        }

        .lst-kix_juslxf7j1ovd-4>li:before {
            content: "\0025cb   ";
        }

        .lst-kix_juslxf7j1ovd-8>li:before {
            content: "\0025a0   ";
        }

        ol.lst-kix_lcbcmordipw4-3.start {
            counter-reset: lst-ctn-kix_lcbcmordipw4-3 0;
        }

        ol.lst-kix_lcbcmordipw4-5.start {
            counter-reset: lst-ctn-kix_lcbcmordipw4-5 0;
        }

        ol.lst-kix_lcbcmordipw4-0 {
            list-style-type: none;
        }

        ol.lst-kix_lcbcmordipw4-2 {
            list-style-type: none;
        }

        ol.lst-kix_lcbcmordipw4-1 {
            list-style-type: none;
        }

        ol.lst-kix_lcbcmordipw4-4 {
            list-style-type: none;
        }

        ol.lst-kix_lcbcmordipw4-3 {
            list-style-type: none;
        }

        li.li-bullet-0:before {
            margin-left: -18pt;
            white-space: nowrap;
            display: inline-block;
            min-width: 18pt;
        }

        ol.lst-kix_lcbcmordipw4-6 {
            list-style-type: none;
        }

        ol.lst-kix_lcbcmordipw4-5 {
            list-style-type: none;
        }

        ol.lst-kix_lcbcmordipw4-8 {
            list-style-type: none;
        }

        ol.lst-kix_lcbcmordipw4-7 {
            list-style-type: none;
        }

        .lst-kix_lcbcmordipw4-0>li {
            counter-increment: lst-ctn-kix_lcbcmordipw4-0;
        }

        .lst-kix_lcbcmordipw4-6>li {
            counter-increment: lst-ctn-kix_lcbcmordipw4-6;
        }

        .lst-kix_lcbcmordipw4-3>li {
            counter-increment: lst-ctn-kix_lcbcmordipw4-3;
        }

        ol {
            margin: 0;
            padding: 0;
        }

        table td,
        table th {
            padding: 0;
        }

        .c12 {
            margin-left: 36pt;
            padding-top: 12pt;
            padding-left: 0pt;
            padding-bottom: 12pt;
            line-height: 1.15;
            orphans: 2;
            widows: 2;
            text-align: left;
        }

        .c0 {
            color: #000000;
            font-weight: 400;
            text-decoration: none;
            vertical-align: baseline;
            font-size: 10pt;
            font-family: "Libre Baskerville";
            font-style: normal;
        }

        .c10 {
            padding-top: 18pt;
            padding-bottom: 6pt;
            line-height: 1;
            page-break-after: avoid;
            orphans: 2;
            widows: 2;
            text-align: left;
        }

        .c21 {
            color: #000000;
            font-weight: 400;
            text-decoration: none;
            vertical-align: baseline;
            font-size: 11pt;
            font-family: "Arial";
            font-style: normal;
        }

        .c18 {
            padding-top: 18pt;
            padding-bottom: 6pt;
            line-height: 1;
            page-break-after: avoid;
            orphans: 2;
            widows: 2;
            text-align: center;
        }

        .c2 {
            padding-top: 16pt;
            padding-bottom: 4pt;
            line-height: 1;
            page-break-after: avoid;
            orphans: 2;
            widows: 2;
            text-align: left;
        }

        .c1 {
            color: #000000;
            font-weight: 700;
            text-decoration: none;
            vertical-align: baseline;
            font-size: 10pt;
            font-family: "Libre Baskerville";
            font-style: normal;
        }

        .c13 {
            padding-top: 12pt;
            padding-bottom: 12pt;
            line-height: 1.15;
            orphans: 2;
            widows: 2;
            text-align: left;
        }

        .c4 {
            padding-top: 0pt;
            padding-bottom: 0pt;
            line-height: 1;
            orphans: 2;
            widows: 2;
            text-align: left;
        }

        .c19 {
            padding-top: 0pt;
            padding-bottom: 0pt;
            line-height: 1;
            orphans: 2;
            widows: 2;
            text-align: center;
        }

        .c14 {
            padding-top: 14pt;
            padding-bottom: 6pt;
            line-height: 1;
            orphans: 2;
            widows: 2;
            text-align: left;
        }

        .c9 {
            -webkit-text-decoration-skip: none;
            color: #000000;
            text-decoration: underline;
            vertical-align: baseline;
            text-decoration-skip-ink: none;
            font-style: normal;
        }

        .c11 {
            padding-top: 12pt;
            padding-bottom: 12pt;
            line-height: 1;
            orphans: 2;
            widows: 2;
            text-align: left;
        }

        .c16 {
            color: #434343;
            text-decoration: none;
            vertical-align: baseline;
            font-size: 14pt;
            font-style: normal;
        }

        .c17 {
            color: #000000;
            text-decoration: none;
            vertical-align: baseline;
            font-size: 16pt;
            font-style: normal;
        }

        .c3 {
            font-size: 10pt;
            font-family: "Libre Baskerville";
            font-weight: 400;
        }

        .c20 {
            background-color: #ffffff;
            max-width: 468pt;
            padding: 72pt 72pt 72pt 72pt;
        }

        .c8 {
            padding: 0;
            margin: 0;
        }

        .c6 {
            font-weight: 700;
            font-family: "Libre Baskerville";
        }

        .c5 {
            height: 11pt;
        }

        .c15 {
            font-style: italic;
        }

        .c7 {
            font-size: 10pt;
        }

        .title {
            padding-top: 0pt;
            color: #000000;
            font-size: 26pt;
            padding-bottom: 3pt;
            font-family: "Arial";
            line-height: 1.15;
            page-break-after: avoid;
            orphans: 2;
            widows: 2;
            text-align: left;
        }

        .subtitle {
            padding-top: 0pt;
            color: #666666;
            font-size: 15pt;
            padding-bottom: 16pt;
            font-family: "Arial";
            line-height: 1.15;
            page-break-after: avoid;
            orphans: 2;
            widows: 2;
            text-align: left;
        }

        li {
            color: #000000;
            font-size: 11pt;
            font-family: "Arial";
        }

        p {
            margin: 0;
            color: #000000;
            font-size: 11pt;
            font-family: "Arial";
        }

        h1 {
            padding-top: 20pt;
            color: #000000;
            font-size: 20pt;
            padding-bottom: 6pt;
            font-family: "Arial";
            line-height: 1.15;
            page-break-after: avoid;
            orphans: 2;
            widows: 2;
            text-align: left;
        }

        h2 {
            padding-top: 18pt;
            color: #000000;
            font-size: 16pt;
            padding-bottom: 6pt;
            font-family: "Arial";
            line-height: 1.15;
            page-break-after: avoid;
            orphans: 2;
            widows: 2;
            text-align: left;
        }

        h3 {
            padding-top: 16pt;
            color: #434343;
            font-size: 14pt;
            padding-bottom: 4pt;
            font-family: "Arial";
            line-height: 1.15;
            page-break-after: avoid;
            orphans: 2;
            widows: 2;
            text-align: left;
        }

        h4 {
            padding-top: 14pt;
            color: #666666;
            font-size: 12pt;
            padding-bottom: 4pt;
            font-family: "Arial";
            line-height: 1.15;
            page-break-after: avoid;
            orphans: 2;
            widows: 2;
            text-align: left;
        }

        h5 {
            padding-top: 12pt;
            color: #666666;
            font-size: 11pt;
            padding-bottom: 4pt;
            font-family: "Arial";
            line-height: 1.15;
            page-break-after: avoid;
            orphans: 2;
            widows: 2;
            text-align: left;
        }

        h6 {
            padding-top: 12pt;
            color: #666666;
            font-size: 11pt;
            padding-bottom: 4pt;
            font-family: "Arial";
            line-height: 1.15;
            page-break-after: avoid;
            font-style: italic;
            orphans: 2;
            widows: 2;
            text-align: left;
        }
    </style>
</head>

<body class="c20 doc-content" style="margin:auto; !important">
    <p class="c4 c5"><span class="c0"></span></p>
    <p class="c19">
        <span style="
          overflow: hidden;
          display: inline-block;
          margin: 0px 0px;
          border: 0px solid #000000;
          transform: rotate(0rad) translateZ(0px);
          -webkit-transform: rotate(0rad) translateZ(0px);
          width: 389.04px;
          height: 126.28px;
        "><img alt="" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAATcAAABjCAYAAAD+SkdnAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAGx8SURBVHhe7b0HvF3Vdee/n/SeukAC1CVABURRQaKIbnozxmBscMU2seM4Pc4/Ezt2nExmMjOf+SfTkjhxxkmc2Mam9947EiCEhCRUQBJCvaHepfl91zrrnnPvu00FIQi/99Y9++yydl977X322aelR0vH3UmwH4ObdqUOoha72717t67x15Lsv0U/QodddqkL97nvyNN4YLD/0m2lWGLYITPw21LIlPsDLe3iDrcmilswzm7cB3TIqH1a8l9QyEJNNJMa+OxqwmOHZiIUGrGCTbDCr5N++S/FEYZ6kdJPvK/UQ16/1ZGnoRGn/YdmYiJNDaEC8/zRYgrYXXHfAHne66cM17y8nMrbq2qkR4eOkl1Klig6jiWypWPajQDb3SJ7dzeGFlI//OumZWf9RACPbN/ROKb9i/2XblJOmbrQCr5ujjsv40CleHMe+1e4NfIRXKwZFNK2N2icGiuhAy7cAsUBJ0AdZMO7W9SApbssZHU0SjYciK+ROPAU1ecWykcj7Gu9lnBAhZvyluWvg/yRV1S0KDuvS9l3Ta0mtmAVVwdenIG7ZZBVmE247Wrc3ZzLviNP24HB/kq3pRxmGcPQCriNTmVlX9bQcvFWrJX9JdzcR30/pXQX4vckFtPpfBpxauQO4PpBCDdrx7op+rcc2X/MX2oDH7ukBDRCIx+4E1dLrjZWBXXQqB181IUbihc57KB4W1T2HTGXCDfZd5bMg02RAM4evAi/px7xx13L7o+FW0MUpRmX7DYfPshbdeFWFGzefJpJFX7q+8M1BGst7LYGayb7y4zZxQ3RThr1pWYEEl4+COEW5RD+7RoCr4X2jc9akaobyYllnEbo2FSKiLRen/Luv6tWcgpoNv/7BdZW4HgghBuuCLhMUysIt7iS95ZOmXADxas3WZD/lvnLSq5lDyV/FsxQNFeiLK4DhHrpqY9aqXSOMRIH/8y2LD4EWzQPh7sXbfyuGKoWyuuuFhpykodIUykdpeSEQXFlo2g9hECq5S+42bXgqZ1/eajGI8IHGqUHRJ4s9f6fCTQPjdk0A7sroGABBxduFb6cdQm4trbnZIh0cLUloKy91MJudebw0b7k24et56MYvn6s7REhuXqaoUJsxrCcf6M4mkmNxedGM0Mh0EJhoIRa2jQtlfl9RbEREXHAE1S0cb/4jkS5OQ+/vxA8QaQryEHxeGPzu6JLmD21+HKb3A8wf/yLBS5O5X6A86CD+LUeGvvwCm6olUH1vciDx9UoxmamQFEGjVDpp1p5VcLyUpHKvPvXhoWzTqlYFE1eT3msCKQOVfJX5E7cO52bKPOb3Ton/+1olu0Raaf+d2bXenBXT2VMqXNwA8eipccfcBd+Mx6Zq4d0FEOXIG+eG0cppHlu3HqL/GuhqbYENWIkfCzchEhXkCMXbtXidTtPbTyKqfRn9/wrKlycyv0A57F/hFvE8VEVbqRlZ4OWbSGaig8+ziuERIThmmsBOarF7C2AAc59enF46PgD+Klc4/K73K4a/yKKPo1zO+EGokXlKY80gGhD7gN7d+M+qAwV0+RSey7EzaWRUG4GHwu3/YDgCSJdQQ4Xbu6verzYuo/mhFugWIHR2PmN2PYVxEvZ1oPFV57c9jgIhRslvZ39R/Cjc+keMmFudvhqnGbyxpKKTV/MIv8NKkdeN5Vpcrc8xkpOcb+zsFjoRVtIZWbEb+OBSWlWgeacHXbN+OTiqNJXnlKukXvg905FePt2n8ErNzssXAOJQ6hIzT4ja5v18LFwEyJdQY4Qbo2An8bCLWA+isJAleTOfm0cX2MQ70dVuFFKO0K46Q9BEO3Ir46GWrAJthyEL793VGojYV/0TUthbQ6UfBfWxbhCu6qUU1GTwzW0xfpQGBNujkh7MRxsw0d7jnlbc7HlCDu7LwsiTpmnsLaBpcIu51QLeZnsC5wHeajP7WPhJkS6ghzNCLdIXfX02T1WpY5U8EFDl33wbxxX8yCWj6pws5LKehUuLtw8v9GevGM3LlFcw0cxlmKoIhf8OLnvCMMTutaswINnCJcIb/elcsLGL+VpbJ/b6hDnkCxCpMmvjvyhQ3WekS7WCoMTV6OKAEW+Fq1uIj4CRNlnRVATrCfucOM+wdMZqa2Nj4WbEOkKcuxf4RaolocIXz+u5kEcjRoawrXhGkkTwq0ZwQaaEW4dOijVirNcmykPxR0bN3Oz+wmNJ3zjo1HtmdZSYO9hnOJ3V6RF+TSvuvU4I14JN920KoPcR3iopBXpxwRd3BRQTCOmctdakK96wk1ptbjMS5bu7LcYI/Vf1HAjSKVw66B7s5JjOEV8wMpAbq1+WxMItq1u3Cd4ehvVrtL4sXDL0xUEsIm4c59FhL37ApXps3v9t+usRW9yqhVDNZTHUB3EUc9fa2tr6tCxQ9q+c2faKaqJLN21UtexY8fU1tZmPHbsqD8mNxJu8OrevXvaumWL8dqVbQ5vX6ZoSri5Pb9B/Bbv3a46yJM9mcw8cR91XcyvCze3iXLNp8JZxxa1Kk3cu29vO0xDMQPjIKlRWdd+l/8Wp4n1ga/gnv/yZJcBJ082P5WliK2npBnhhvA2q8yj2Ks+icftuCBFaj0NDuyQz23tUlKOyvKphWZ8qUl1+PPM/L4jGkcAc/tir4098bsniHQFgVJcNBY3FVC9Cip92n37wNb4As1WZsDCNiD9VovWgBAZPmJEOva449LWbdvS5k2byoRvs0BA9h8wIJ1x5plmXrVqVV0+9dJEng4/4vB05VVXpW1bt6VNGzembUqbubULpRJrUZeUVGF6uiujHSKeotrV/LhWgrkaudbincQ7uN8j7OKe/JRylJVrUUN0MxtIW0xrCYEXv0XAZ6esERxQHo+7eTrcLtLVmMrfn8hTRiRmlQG7cnj4nFMZqeyK9x2oVxHNC3gM7mZmnClv3TQiK0dda1KWVn7rEahmXyTq44AiigxwLTWk7J7M0WhoMPkISVJzVGZifxAoT1shVfLg/qhM95GHLf5Vuffg5cgai1EdFDkhAEywEcSowKOM7L/UiSqpg4TboCGD06gxY9Jhhx/mU8G9AEKyT58+6fQzTk9Djz5ao7tqSxHXohzclFlY/rp365HGnnRS6tO3b+rUqXPkOvNRDjo0O/QhXm3eqXxDO8TXSMG2yx+aQj3yPWU5WcrEx66QRa8ap9yzq732I0JD6ihqE7WauYPsVJYyQxYmiLD6lT5aIhOyKpgQZhF/wEOVUxFeNlFGTqV0Kw/OM78SlxFmo0KeLWzOD62MXf9B4S9Po/xTOEZ+T53sbEDm1dpoRmbjVOxvkRuI1gmhHeeEXMjSmv0RIijys3ctez+gmLWoAMyAJEaGKgWc/+47cn7lHIvpKkN5Dy0h0hpp5D6oFoJTdY5V0I5ZvZDuVtNHh5bUo2cP05S6dulqHXVvQLiuXbum/v37p56HHNKQj7vWSJUc0f56H9Y7denSJXXcC4FrnPXD1fqOmDZDeQeH+PW0Blm90olLcJ/YWEeTAQLejpnuosWIN6T7CO7CJrqxJZJ/o2YAG8jbWvsrBJynC7aYekfaMLtgC8EXoXJ4O84FCPx8ip3xLiQY9zA1JAtXSklGzrVUI+pnbs5DFvMZxH0RlfcAf+87vIjaR18qrBJZlQsRwguYUbK0qLkfUS1NINJTTJkB76Sjkkp/mGtTERnHmjBuhYBmVGRRRvUoUNtN3D3h+wWRzHpUjB2091PuXg+MMzbWlK556dtaUPbHfU2iLIN0H7FHWOtE8gaxlsRLikzP2BvHAw07jQLRYJJUmlhGO3RvWiT34mG88QJvGdy/m0HEh6nsTumqJBA+Kzu6uwL4qo3IwskFapGwC3cP4WUAl2p/ZbBkexweIrtS7o2o5N/J05+Vp9IUr7oVyZDdiIV8ZkkQyvwYwsYJ/h84IsHllVDIhHKVa3D/PmFllHWI/Yqs01RFHTfvcNlNU6jvuSxne1jJ4Z1r0L4AgUlXpL21KmVtok4ZYUbQuZBSO92904Wa7KGY9vEgwqa4kHGNzlwukHAzUmFa592zQm0Aj3lfQGoszcqHkeUjJxdUtlAgX6Xc1CDxs3ajsoV0H9PMVmUeop/TsGLg2SVPrFUG7dA966ompLM/eMcV8jSRvoMEJIvisYaRUfxZISjjLvs/uoiKh/Y1q/BgXawasc4W7q0VbntCLRkf+FVzLxLxtHZsLVE1P3ma27sX1wajGRfB5v8ghFM7D00gWhjp4EpHa9O1s1GLqEPqLFWuk9xbqaIsohBoPC8urmXlKaUN89DBKdaMAj5VdB781UNwzJWA6tSIz54gX+sqpxAiVmYlcz1yWPlaGXs50LchF3ChJe8y4tQhO3lItFsDScqoMIwYUSLtVvkOxFaQRogKQ13GQDMm00YqERY1KRhGRq+4AwMqxCKuA6vYBgmKplbPm0WjCm+EZrQ3Fra7duuWRo8ZnQYMHGDCItDW1moL90cdfXSa8tpr6Z0FC9L27dW3cZB/G1hkImnF1LW1dUpHDT06nXPB+WnmtDfSKy9NTDt31t4OUi9nLUpvn3590yc/85n04gsvprfnvpXWr1uXuTrmvf12mj9vXlqzerUCFMqgZnEQY51Y5eRCyBnYlFHXaHMWWj9d1KlCozCtigJREOtSutIieahh61pm70kyQS0iqQTxpo0LflzPQRCGMISivM0/cVVgjzR3BW/Gd7EoidFj9f4WKejYQiod+C+56cf9uOiyhwz1YAGJ0PnHQGT5zewoIxfyDsrFkdtxDT8Ro4fO78EHJtzYHzVw0MB0+OGHp7ZOKPye/GJiPdNk3pMeMnpPE7xzx860efOmtHHDxrRx48a0afNm20/F/qx6DYYqs4irgIXvvv36pT5HHJE6KS/1EHmrl26PRr+V8VUEqseFPK1auSotendR6t6jezr51FPTkUcOSa2F9LFwP2rUqDR4yJD0xrRp6d2FC9OOir1uJKGbOtfhHTqmAdKa+rZ2NG2lmLQO4tlz8OA0cMKEtGb2nLR8ypS0a1c5nyIqs1UG8e6sdtDv4ovTExMnprfenpc2bNiQOTpmvzkrzZc9AvSooUd554dpVhzl/K3m5KbxW2lavnSZymVl2rRpk7kC3NlCwpWw3slcwzIBk7HvpPbB1BR7qaqppWOH1Nalc+rctVvqogGki8q5S9euVh4gS05JuFkbliVE+wUh3HKdQ6R4aKOrVX8rliyxdtmjRw8J/X7pcLWxDkpQI+GG684dO1Sn76Y1a9akbdsab5klXQErh8wUZqhji1KsvPDAp0/ffunQQw/FU3gW8vLeqHpbunhxWqv4d1UeOpcxDL5RLkXhRi4IVdnO3c1BeW1XQK4lXvaXm8EHJty6de+WTlXnu+DCC1I/VSCbSi0hpCtLUZZEa2jYuXV9IVEN27dvT+vWrrO9WHT+lWroy5YtSytXrExr33vPBB5+YuNooJ5wO7RXr3TmWWeKzkr9+vbNbKsj0lsv3aVoKuPLAjWT5+XLl6dXJk1K9919rwRaqwaPQUrnoWVTuk4aSM4888x0zMiR6flnn0tz5sy2vBMtGlo3FfYREmrD1FmPlXZ2rK5HilcXNe5oNKClU1vqMHxY6iyBtOP119O2515Qz6ot3OpCce5UG9jwuWvTT+5/ML0mTZB6KYI627xps4Ty4PTZz19n+eooQV0smGLRmbV+tm7dmp5+8sk0SZrlYgn9AO5F4WZTWt2RR6ZcIdza9NNJ8XSTADvk0N7pMAmaw6VlHta3T+otcy8JZdoCAzRCOuDhvcTC1mLz/3aEcFsioYAG/OSjj9rA27d//3S62thZ55xjg1WZbMujyiEPWzTAvfj8C2nSiy+mxYsWWd3WQ3PCTVNFtaHR48alMz9xbhp54ol4qooF0rCffOjhNH3q1LpxF8uGNLiZ3yiR3C6UHBA+tikQa3DBJ2Z34Rdh/IEJNzSf4084Pv3lf/vLNOH001PPnj0zl/cHjHo0mM3S2lZLyM2RtjFp4stp8quvpFnSCpYuXWqdZ4dGvhgh6wm3HkrvNZ+5Jn3txhvTmWef5ZrEB4y35s5Nt/zq5vSf/uw/qrOUC+pA586d02WXX57GjjspPXD//WnqFAmmbdtsv1ZvNeBjJMwulkZyturnKJm7oa1kYYtoEZ+O0gA7X/fZtEOdadsDD6bdDd5SqAnFu12a5Npvfyv9p3/7eXp24iQTZpVAMI8eOzb94C/+LJ1+5hlWB/XKnXpkQ/CP/+7v082/uCnNeGN6qW6ZQcUSBxxMuMnA2g8dBK2rVQNul65dbD/g0cOGpbEnn5wmnH12Gn7sMaZRdZdmhYDdH3VPumZOn5Fuuemm9KP/9b9NKPc+7LB0zec+l77127+ZRh5/fFPxUJevvvxK+scf/Sg9/cQTaYUGvMhzNTQl3CCVxRVXX51u+NY303ka0GphsuruR3/11+lRta0t6mt1IeYRX8BrxGdwUGjStk4pJ1JG3W2XNlnS3Kg7c3E/JuBUVlw/EFB5b858Mz3+2BPqlG81fH1nX0FmmZLxis8gTafOOufs9Ovf/vX0Z3/xH9Of/vkP05e/8uU08riRNhVophHRaaZoKjbxpZdstKzXgA52INgQap/p3iP9Ya/e6VqVwQhpbbUE2wcFNIH5895O//ov/5wWvvNO6S2G/Q3qv5M00yFHH5Wu0AD2e3/yJ+kH/+2/pm9/5zvp3IsuTEcNH556amq2vwRbOXJ+a9euNQ3sgXvutele5cyiGljuGT12TPrs9dens8891/Yg1kQTTRYv6OMs0RP7vrbymHfxW+KdaWHQdtluDZL9NsWKHWRPo/HLwwVb4FSKIPW92GbjE2SR/Hxgwg1hgFB4TlOjKa9NSWtWr8lc3l8wRUPIsQGV9b5jNAp/4vzz0td+7evpj777R+nKqz6ZjjxqCMqEiqj4V47dKtSF8xakl6S1MFK+38J5T5BVL3Wekao8Ixv2ogPJjVF5bKfOJtg+K6F2orSj3pqWVq6xHSiUklgAAiSEyPp169MrEyeml154oaFWAqwcsj87LDJIjR+O8eQS/nSNXVLfDpGmdpqmX7/xh99JX/31b6aLLr8sjTzhhHS4pqI8qEGAxBPn/Y88P6yfzdc076nHH7d2xoDaCKSpm9J46oTT0meuuy5dcvkVGtB7SiuNnIpUwBDtwMony4aXVY64j+eSCKKiezXAa6fSsEMD484iKd7tst8mYiVwmzhtEzN7U0SBnJieezsNu+2iraLNciP361XfXHlHdQc8jeDpfDeLP7RJ9IEJN0DDnDNrtqaHE9Ps2bObGpn2J2gI9mCgb990woknposvvTR9/otfSJdedmkaNnyYjcxUZrUKRRXesH69pjpvpIfuuy+tXLEi7WiwvnEgUavPl6xlQLANVB4/oanXeRL2aG891Wk/yEZB+oyKckOZ8a6ozqAy5gHB8888aw8YGCAbw7lmXTkza6CTkbxC3LepLIYcOUTTrovSl3/txnTplVemMePHpwGDBqVu0viLa5cHAvSP9WpjszTDefj+B+xBETOeRiCdR/TpkyaccXr65Kc+lU6ZMMGm0B00aFn2S6WZX6K8o4SK4L5ZrY12h98iBU/MvkmDa+Zu/rMHLKUIPH0IOdzwi+rgr9T5tRTewuZ+ivSBCjfw3nvvSfN5Nb08aZKp4R8EEHKMxmhy50iVv/Zzn0uXXHZZOvLII1MnTc8qdZi4QxgvWbIkPfXEE2n6tGlqiBusQX5YwHR0jLS20yXgj1b+uW8EckdD8pHXR3TMm6QJbdL9XpHKcavC01hLXaiiGK1c7V9TFAm41159NU1/Y5o9Ba0H7yY+ijuF/oJ5twT8LieNVgP699VU7pz0uc9fJ6FwpT3NZ/B7fzS05kC+2f7y7NNPpzdef73dg5ZaQMDxNH/Cmaenq6+9xg5KQEAfiLzEBmcozKYXy1grdq+nMOX3lQT8Gvp4xZ/iCmJ75AE7FaQaSASjEy9Ljxw5Mg3SKFmrAhAmO6Sqs9bCdU+IeAC861Uwi9acdtG//wDbOjB/3nzbYlEKD7nRsGvnTnvk3qPnIZrOHmVPtSKdB5pWSHt8Y9r09Jy0GtKb5zI3MSU/5phj0sD+/dPSuXPSuRs3pZNa29Jhagm1S4WmJIEmnhtF7ynPqzR923DE4al11Ilp2fz5acHMmWnltu1ppdyq0YpdCoN5R3u3lSqvtT17plZNpZ57fWpaKA2F00piUKlMF08WmaKxJWGABBD1Va08EILwmTzp5fSmymX1ipXGKxdutIfdmrK12Hae8y68MH3289encz7xCdN06rUTyhdCk9yb9lhJpHXZ0qVp+tRp9sQbuwDtifz21nSZp9wcLlAvbQEEHAJt4MBBxm/xu++m99a8Zw/WgJVvgU0YsS9yp+7ZsI2AHHfKyWno8OHuUAU8oX35hZfSvDlzbVoNJ8qbP1ok+wEDJbeKvLjvRn95enNU8DkYNvGSuXHjxqVvfuub6evfuLGm+s+oNW/evDRP05Ed6iTNomNrR3vBmykH204QYPVAo2Wf1cwZM9J/+y//1R6tr1m1umqBct+5S6c0QgLjyquvTsNHDE+dO3dxxwL2vpDbV2Et8MT3pRdfTHfcelvaqQ6Rh8xNPC29/IrL0ynjTkrTHnoo3bBocTpW9j1qlDlAo0K7mqJOPGnL5jRT13UsuI8dm6762lfTi48/mR6+7XbVST4t9+aXI/JftA0zHWfwsGHpG9//Xvr5Tb+UFv9ySSOLhlyEfYxFbebIo49OF2oKec5555W1GfxbGNUjA9MTjz6aXnru+fTuOwuxLUDdTcKNfYAcA/VHP/xh+oQEHE8pa7XBAMLoPWlU8HznnXdMeKA5OCpTXM2mAkrrIgmfF59/Pj3ywIPGPwZUwKB03kUXpj/83nfTGWedZW9tNAN4IMxWqzz/8Uf/kO5SPbFnMHjbxvks3TFoU+LF3LNKyWkytO8b1UcvqPO09FWelv71/0yP3veAlb1BfMk/JcRTzog74qEuccc6yjBLSlXg10VlexTtDgrhBkaPHp1ulGD7jd/6ds2KmzN7drr37nvSXXfebSNys6Ch9pRmNWjwwHTCiSek004/PY0aPSr1Yn+SGnY10CAY5e6+6670k3/4sTSiN9J2dWov2CJUyNJiWGhmGtBd11L6VbL4jfWBPUfEVLxSXdWrbOvWbRoA1tgePrSbPJ25KYTbmePHpQXq9DdISxogwVVrSoq2tlQd9y5pDi+psc6XAFuL4BSfURqQvnLj19NTjz+R7rz11pK20V4cKcVZ0osuYUZzOlrawH/40++nm391szQXF24l9wp+nOcGGERYSjhMVPRCh3FtwbUeNsa+t2ZNlfW53amtU6utqX3rd34nXfHpT2sAPNL3z1VBaFCzZsxMr738Spo25XV7esuG2R1yK3bMyhoiLZX5KAcP2LZaOsk7cRVBmzpbGuV/+MH301maOjcr3AK0Z7b93KmB77677k5vo1mR5vdLuN3/YGkrSPBlCQPh5tHRPnPNjZJB6PlffeDXSrKsONuHOmiEG8Lmxl+7MX37t3+zZsVN05TlX//lp+lf/ulf2u1gbwRGPo76QUUfM3ZMuuDC8236gTZXS8Axer791lvpf/31/0iPPPiQVO7FZZXuyKojq6Aob38a5ffNPmkqR5EbiPtmxKQ3kDx0bgrhdt7J49Oaxx5Pn3t3Yeq9s/Zjc6aNz0so/Gjte+ltlcdG68S+T3Hc+PHp66qzJyXc7kC4Vb7GlZUJIFQ08kC4MfgMleb2vR/+wPbpVQo3rm723xBuJYhvsUvkwi04VEeLPB7R54h05rnnpu9Kaxsq7Y18VQPTTzaBowE+88RT6fXJr6YF8+abMNomgV+pdURq4pVCUlJfuNWHC7dzJdx+sFfCDbBZ/VWV7d2335nuuf2OtGLFcgnlvGXuL+H2t+ov1YQbfNjuYYUls9eQ4mJglVXWk5pC8RsSbsruCwxqtemPHNAq0MRmvflmevD+B9Ivfvbz9PRTT9oaQeUoGUAgHj10qO2JY9rJy98B6qhWU6XccaNw6/n7IEFOeBuBF7nrpW/j7l1p7vZtaV5BsFVHBRca7H5EWQNuAHw1Qx1b21I/DXYItyFHHWWCvxrQKNDOWAv7pdrNvXfflSZPnpyWLV+etqpscCe3oS262YvAbLA4gIhpXyXYIsIm6Muv/GQ65/zz7M0KNufuT0TZMnOgVzn5BhzsK4ui0X1NZFksy2nhhtj+3Qi3AOo5T2Wfefrp9Muf35Se10i8aWP1KS7qMg3+7HPOSSdpCsbDgubgVcRvbjq4QKPbtquxRkmH7apy4F1Tpq65wM6FYp7PAqp0sHrxlAOf1XwrTkWEpteeODnETw/h2mKk1IsIhCIdXIN4P3TI0UPTyadNSJ3rPBVl+8Xc2XOknd6ennj88bRk6VJpaztscdzFWlGoZVOt7D5cuR4IMFDzFk7lmh0gf7wfOuGsM9I3vv2tNGrM6HTIIYdYmVWiPKSj2TwQrwuz9n+gHZ8ssrD3MqtN3gYVSPHE01jirPz7CAo3SionX3hsTxTI1ClT7L3DGTOm19TewICBA9Oxxx+XBmsKyzSDl5h5PQfth8KONbXgbj1Qc56WFnU2Nk/qviEpfDMoz11tKpoqXbhuk0a2QoIezYzDFWuhj7TVCyUErureIx3X1ikdIqFhR4rLrWGao9FlDS9GcGv4ClyeKqsVXLJ7v8PWt2yk1Mbapgab3r0OK6feQb3t2kvXQw/rlQ6BevdKnbtJcElDie8tGInnoXI7cujRtjRRb5q3bMlS24v57FNP27qYF5eXQNaaysidqFP9yaL02lAT5DAuFfD46sHWBDdtsj2AC+bV3gPYo3t3e4vhN373d9Kpp56WDu15qNKpUlaa7cRdKIsv/rzGGyPKgP5Au/L69ntDljV4Avcb/iJ0VhKeBFHYsW3Hz9TrYrRLMw/nbu8Jq31Ev+sol4+gcAtEQQmlQsqJC6+0sEHytVcnW0OoHOkCPF2lAwwbMcLWHlT3Ft5HkGiYebUEl7yj4rsBYLrfEKkBYS6SPyhYtnNHWiINZEuNfAPeVBii6fnne/ZMv6VpzDc00n9aneNUaTqDNa3rkgm6xlBJWcFlVBFllFQxjVyDN1e2awwbMTx9+3d/O/3xD76fvvdnPyzRn1TSD2X/wz9Nf/jdP7anjDzssfgzIFx5CZ5lh0MOVecuuBXBcsa0qVPTc08/axu1bRCMJGbJ5ELHNCuxyawN5Vy5q0eBIodApZ/2oP1u2bwlPf3Ek+nBe+9Lb06fUdr2UQTaLFtEeLD26WuvTSeNH5+6dO1cijXLid8I1VJYDx5avwqQcwlz0cb95X+5q10tQrehVzH88KiHGQQHOTCbYFZBG+wsYokF+eYHILBO+QHvcwv07dc3jRs/Lp162qlV1WSwfNmy9Lq0LV7Xqv9eYV6ANkJYIZUDKxoDjZqnbbyuwppEtbjxw1R2wfx5adrrr1sD56no8GOOSWNPHpdOGDU6jZRmN/I40ciRfj1+ZDr2uJHpGJmP0RWz2e8TjUzHGR1XlYYMGaJpdKe0cuUKT3eVjLe2drR9bv0G9LfDA7quXp0GqmHwZkKVYjI7PoDCS/X91VqOlIDhTYbjlf8TBw9KI04am3YtfDe1zJmTOAinq/zh3xaJK4BNkaKWWuS3l6ZL53zi3DT9jTfswY3vc8Of58Ku4o2/0844QwLrAtM+KHfK1glzgVQXCC9O2+AsOA5MCMDzhNGj0nkXnG9vp9RqczwwePiBh9KjDz2k8Ksz2/aAn0+Jq5DyF9Pkqu4ZdVTP1EWgZOCYg6n2kUcfZQ8T2E+J/0rQnhmwb7/5Vtvwy9P9w/scYe270j/3vILYS9orcZHPZcuWWtu28tZPMQX4p0xPamKf28QXXkxz1R58n1vOx831/8IXKKkJylcINvQx2lcnlVWb0tSqcmlV+6X1+rulGWT4iAq3HFZgpRznCCsaxGGsQ5x+hp3+UGt6grq/YMGCNPmVV9L2rVsl3Lqnk5XWyz75yXThJRenU049tUQnn3pKGi/y66lmdvvcz54TPJxPLTpaU6ztO7anqWrYdBBvLOWITbz9+ku4qQGuWbZcwq0lHaF8d6ZFVwG2TMMRXIfL32DxGK6OcfTAQemIMaNTbwmjQfPmp6My4ccrXf1kxu+hoq5qfIy2/NFco+uaWQa20jCVPNeE2/S0RB2kUrgBOh71hSZ96hmn27YNzjpD86pK0jLpwG9I8+LEjRXLXegDBM74U04xrY5BoRYWzF+QHnrggTTphZeqakEB+JEW3mrhWCbK16hffzu6qHRfh3gNkIMbNm3amOU1Yy40Ldw2bkoP3HtvmqLZCJomRzENHDzYDowgDANJgHseKnB8FPZLVI8b1q9T3Dt9Jkjd+MUEM8KtmU28CLe3MuEGIkaryxLDGlSE7kNgkVs0M4QbyxMcRWUnt5gdS0S7Nf331kWbIpCa3r9v4UYLQhtAOHBaCJ2/GnisvVDC7eWJk2yvEw3pqKHD0pnnnm3vpLJ5l/dRh9Yh3N9P6tGju2kpTz/1tKUvFws5QrixqZn3eecuWZK6yS/CrbeIUbEZdBCfVk31Oo86MR2iBj14/vx0ggTb+M6d08mikzRt5SX8YaL+8ttTDTJ40wRLDzJkRToZYNDceFcX4cZggu9iHvBPva9QOzhq2DA7rw4BVuywlWBh/dWXX04zpk1LKxFuYoLvto6tacKZZ6bzLrzA98nVANuPODqIY7HqgfMIGbwuu/KT6XwJTMxGas/jRSefdpqZ69GYcSfZJvN5b7+l/G82ARdoVrjxcOxhCeP5qo8lixfZgRQI+sFDjrTjmyrDUXZsWkbDoy+8I2G+acPGTJBbDUmcoFm2ZJrbKdaWawHhxkkmc2dnbyg4C4uHavJrHaJ2dI1q55JPSWlDrrm17N4pYcZR5BJqKiYXbObZhBtrcNWlyL8jcArtBlXmcjX8eiMzQoEnaqz7UAmbt2xOr78+Jb34wgu2f4iG9WECjYYUs4/tXuX/PnWKuRIEtUugPuBHA0T741Wu4SqnCSqvT0lj+Oahh6Q/lmb2XdENh/RMYyT8uqiT2RqJEmENOG+bJQI2CnPNiPrifeQnHnkkvSXh3NyL8+1BJ+8swdtFaakF6pQDQNeuXdewfjnaffgxI9LFl12Wrv3858vos0bXN6RrPnttOlfT5P21RWPz5i3pzZkz089/+q8241hXcXR7gNkKx85frfgvueySdMQRh6v8GRyzUlcdhPBphPDBlTpFo7VpuVs3RJQyV1/HdBu/d2C2DcESbjv4QI/duTDT5N/aIe3qY82NzqiR+2Sp27y9UOvVLDSJt2bPSS8895w1Enakb6ZjiVFfTT1oHDSSZhrA+wVesGZaxzaX7t27pdPPOMP26I0fP96+mwCxpYWFZNaoDpHQGaJ0jxg9KvUbNSr1lBZ2uKj1hBNK1FYwF6mjyqpVU9LWE09MLd26phaN/q3HHW9uhAnqIuomv4eKf/9Ro9PwsWPSqJPGpmN0PW7sWDOfJI3lZGkEp2mqydabQYMHpeNOOD6NydLMtVu37jag2JspatQcLNqv/wDzS/3VKnc0t8kvv2LfeVgpQUV74K+ttc00qwlnnmGaTTUg0Nj0Sng0knpAGJGHU0+fYBolg+GeEqCNP/7ww7a+tyOb1oE91dwWLngnbdq8STy22/coVixbbn3sCE2dqx0GwEm7rDnznu4qTWdXr1qZNmSDNoKb+ExzO5lpaQPNLZuW8t713oA4TaQVkogRspVh/pV+xG/2KRg7ZslIZoQigvAjr7l5gfi1GrCnYhFq9QSTF7iKXNfAlq1bbGp3/7332rcImhW4BwJ8dIVGzBoOJ9bm1CN1lTAivzTmnrrvrOnsWk1ZpqmDPawyeED0tMpkeqfWtKJr57RNgnJ3j26pRf5KJI2spWtXzglKuySQtovXZvEt0paMtslth6ijwh2maeTxvXulC6QdXNmvTzpXnW1Er97pEKUTrZg1MtLMycxQ94w6d+ls9WT1oIFl5fJl6ZWJL6VZ0kzqadwgatXFWnlbKFRnVVBOtV7HagcxtjhUfntFGZv9AW+t/l4pg/HLL72U7rnjTlsP4+FBJewJquroeA1W11z3uXTeRReZkGY91NwblFMlinnBbOGt+yhVjci9GtmHd0TUMO+m5odXprRNbXyr0r1JadykCNDhceOoJP+oz4cSZLs+KFAeF7P4PVad70hdu0dF2a+DEZG1CN4zraUxAtY/eL3IRiMqCTtVBMdh88WmVzS6M12icj5okIbt27elBfPn29NdvnIVxMMGviTFCRRzZs2y9w1flyb8qtyeevXVdMvESennL01MP584Md0sukeay1Ov8h7llPTu1Klp7RvT0tbp09NOhMq8eWn3mvfS2nfeSTPF9zFNfR6qQQ9m9IjomVcnp5mKd+XUaanDdPGZPiMtnjnLXkSf/9bbacbUN9I0pWmq6HWlC+Lk3Y1obZ5DDSRbbVr6zrz5DYVbNVBGaEax6F0NCBymiHT6ZvH+1P7eCT6aorVTtV20+qcff8LOhePkEQbiyrYaW0R4Y+OKq66yp9Jo9xE3AqqZdLRLbRaumbDloi03uYDz03iZjrKVCVViq+whBBun91Kb+EfD+5BOS19rqCWx6DhAAu1yaR2Xq8I49eI9VfJqdQTm4150/vL18BHHpCs+dWUaIJU8pgeVsCnf69PS808/a1PUnbt8lOHrSju2bbenUkOGHGkaButA+DnQtHTJEvui1QvPP2+CeLXSzAGHaJVB+GGza9eu3ewDMZNfedWEIG6LCv7e1rTmDdlPFk2f/465reMookWL09bFi9O25SvSLpVp27Cj00IJoacefiTdNntWeuHteekl0QsSoM/p+qyE1bMyPy16dp6bn5Md/qaJb9uSpWmXaLmmmYM0RX3uqafS5EmTTPC+u/CdUnrIyzYJbHqIa+L+9sgoTW9P1TS73vvBk19+OU23aekKC2/P39QAjtd0mWkWnxWsBoTb2vfWWpub/eabqu98gb/YVTHRZo/XFJxtPzyZZPpcjdA68VutjfP+KtO6xx5iWrpKwheh7fHg/6g9mJbyyUZ/t1O5RStUfjeu35DWr11n340dMfLYqk9QAeXKQwZOS+HEk1X2IGa35Y2tIEfXmZbyMOhlDfb2Yn72rnFw9z7HXT1ymEk/YWOaXwaMTi4K/U0Rvwf2AERa3YdUuE1uKNx6dOyQTtO07Hu9D0ujO3VOA1s72nlisxSOWTlHH7MTm13qY9WprrjyyrraG4/J+fjFpGdfUNzb7dRQCpXi37lzV+nLWizgTpYGxOGbRWKHO09a308ijimTX7MnXqVWUQGE9wgJc3taOmeOHZO0o/C9UW8kTjv0s0kZXS7tZobKjVNBnlWHeVHXGRLqGw8/PPUePTptkSDcqcY8WGXHGw2IGTYGc+7bSspG17USDOvUsdfr3q6iVTKTzoGa2o7r2yf1POP0NDN7Wrp544assWZNmPyIbHF6t2+k5kkp2zlOlYZRX7i9kmZIuMVWEDozWveQo45Mx514fDpq6NB2HTyAQJsx/Y00U9rq1q3oBwgLkuIL7r7o7oljgzftYOYb0zVlnlROagOs3/GNWLShaufFuXBbnB596JFszS2Em7QQlW0IN96DrSfcHrE1NxduDAL4tH1gum5evz6t1UCB1jrs2GPtNJtq25+w76365cw88r9508Y07JgRGgzG2wkutbBUdfdKYStIVntGVmpWeLVJv/jKCHNO7uLwPMlGFlx5kFAKrQvrbx9JzY0s9lXOxksru1CVhC62RB1sQY/uaX3/fvbRjA2bt1gDZ/sHX1LiOwqs99Rq5HNnzbbXWpie7VCntEXLGE504X0+Rt2ZM2amaVNft+lf0Ouagk19XdOsgt37QXzdaaG0nK1btkZraAcTbtlWEPa5IdyYanuzyANhiobEFZ1lu8qLwypXSzAt0/22I45IA8eMTS/OnZvuU/wLNVVEqPXSVH9Ep7Z0QudOtizAufcISYRl8CQGynC7LI6Qn5NV/30l3CZNm5oWLHo3bUDLkS/i5eptP0tlxoT1wnE8iFD9NdLcZkqjXbViuToC+6HoELtT375H2Ebs42ITb5W6R3tB231HGixXQDrKfXqn4/sOHG7KRuTKuuF4pGnS/Hm3ky9pcQx4beEWmlvxgULzws0fKCxIW9XGvct7eonP/EhLZlmC9TTe3KA/VAo4/KLBsXfvMGlxbL9hL96JY8bUFW7xQGEun4zcISUgs8+qTMBUm9rXQHWUlZ0ZszwWqLoU+ZCju7SykZomHieaJiF4l0adh1VwrSecmL5www12dtdFl15igg0hyQGYaFcIz21beXeQgs7Bmo7tcteUigYXj6ijOPEPH07C5cDBhe8sLCOmVZV27wdx5DnfZ32/UBJwEm5M73k3FS1sgTrlFJXbq6KXRZOk4bwqAbtEmgd73D6p6c+RrW1lm4SjOa+RBrhUmuM6XQ9Rh8WOLg2ht0TnsOaqIRnBVq4NNAPqimOd2C8VlNJaCZBFEgKxb7EaeCgzZuxYe5Jb73RegnMMF0KDAyzb0cJ3rR1wMg3roY1QLTV7kmdvmZl2g0UG3vdk4HjrrbfS3XfckZ558klrs9Xyj3DjvepLrrgiXX7VVfa0lBOzG4E6C/K6ir88XbWIEG6u/YcrvJg5xZQ0fs1VxtDoPnLgC+kj2zqlQyXk7lTDvUc5XiwVvNe4k9IJGnnOv/ji9MWvfDldc+1nbJ3kvdVr0n333GsHUz711FN2MOUijUA8ZUJo8fHmuZp2zdPoTePwasoK0kz1UavjvB+ItB0IEBOCnsXddZq+LZOw42ikqRJwTF1flDbL/TAJNj7yjPAqgvCEZa/dIg0a7DqnQzCZKT8DTw4INky6YlekZkFIeJAKBN3a1avSO/PeTss1KHBwYzWgIQ2TpsLHt0/kO61VtlE46qdkT9pAtLBi/ormZhD5tDLDQoArueTTeGwT4WHTg/fdnya+8IIN7MVNwwGeFqMpXnz5ZTb9R+OsB0+nvwRfTLujcQ5y8VWfLB4ZPL7gXM7/IyncBklbYO2HqejdGzekd7r3SKMuOD8NPW6kjazLRWepsf7W7/5O+ta3fyONP+VkWzC/9Ve3pH/5yT+nX910U3pEUwMOTWTqNumll2w6zPldvl0wQ3lZfowC0PAWSmC5gNtmywRMVwOUIsWHAGP9bQXrb5k9Jgj3siLOBBvNGzHlomoPYR3COa/jfWFp47NmzLApYS3wxHTMuHHpyk9fZfsZWY+KLRIB51j7r1mE7wgXfxHDnqIYys3+t2tX9nX6555N9999twk49sNVE3AI82OPP94eJgzW1LgR8lS6iZJyak5wNfLHD6fz2B9m7AS7FgaRj6Rw4yVwsrhMnWuDBBz7eph6DB02PI07+WR7EscHoXk/9PwLLzAh92f/6S/Sjd/4tdSnzxH21gGn7/7p976X/vLP/yL93f/5m/SSBNxmTbcQboxKgVj/+RjtQdEg5NaJOqoRtoqscWbImqf95WXqPryBswxeqX8QzoVcCMBGCL9GuuGKUN0sDXPBgvnpxWeesTXTWtoV61E8obz62mvTl274ip0aXL7Zu5lU7DngGtRsXgMWRkVmnT/IncxAmVOiG9etT08/9ni66ac/TXwPlplKtXJgNwDT8j3ZFuN1GLWYPdhQpPVI/wauNUnJgyyVllZy40autCXK60Ml3Bgt+dgLBU3jqkYsmPtuKH8NiHWejevXp5dffCnNmzvXNiaecvrptmVi2rSp9qifJ0LHaNp6iVTv3/2D309/LkH3e9/5A9vhz0dp3tKUlP1s0UiMu/hyMm+9tASxdlHNfn8Ti+o85j8YQMPiRft+ShOniLBOBwW8STq640/1Cihee5Rvf3SI6BqOCOdhrambqRH825Z8yFcCNyM79mnFyvTcs8/a9pN6n82jfFmj/fyXv5z++PvfT9d/6Uv2FgWL8dQvr3JV1kcZdfZ24F+pV35qrN2BYtnsLUyQZ2T8gqnIy1ilqsbcUfdb1m9I0ya/JgH3r2nG1KmmCOwLSvxFPMUMc3GYakT1EO4lxSK70jdjHY6HfR+qbyjY14GkVXF6brWP0zLiLFz4Tto2c1Y6SQJthDr6HRtUcdK4evTpm665/rp0wze/Ya/sTH51sj22Zw3h2GOPsddOWF9BLUddZ18bi8Bs7bjpZz9Pr02eXHo3j4bZuVNn+2ISrzFxmkgjHIhC5mEC33zgfDofy9qDDnbZ5ZenCZpmvfTgg2mmGnP+4ZtoNt6A6qWZtacTxOPar38tvfDkE+mh2263R//UXFeF5lBLlgYQWhyX9OSmzWm2pqc8gADBm/PizpI2cMOoUWnMd34//ed/+1l6buIk21YT8LTkqdkt4YDNgIED0jd+41vpdzUQVdMoaA901B//3Y/SLb+4yZ4mw8c6OuJOjDlm6JCeh6bLrrwyfeXGG9PY8eNtq0YtwJPvO/Axcfa+sZ/MnmzatLpeialzK0K+g3D6WWemwUOGtBNw7IPjwdb/9wffSXPenF36ehS+6BMcLMA5djwxrdZHePDFdpfv/NZvp2elja5e7WVIeItJyUPIxD1mP8xgd+rQ1pr6qjw/de1n0me/8AWbhu6Jlhawbyj81f9Ij9x/f/a0Novbfv1QyXpo4FxCtAfnLZihdGfGg0q48bGR36wj3Kj8lWr0aFEcy1IJ1hHmzp2T7lNDbn3ttTRhx860Q43xJgmld5XLURNOS1/82lfT5774BRNgaG/w6t2rdzpx1In2jmIxbhoLU9of/e3fpttvuc2+v2AquxpE185d0plnn5U+edWn7F3Ninb6gQBh/Ngjj6Sf/Pj/liq/El0klPlAzOWnnJw2PvFEWjJtetpREm7No1XCbeDYsenkL38pvfn00+nlO+9MG7J1K7QBOg1E+fNQ4Y2t2xKbqJnWA36Jr580mQu6d09XqzMd9nu/k/7m579IL6qDUM/lyMNVCje07EbC7eZf/LIg3IyLkxLBmWBHHNEnfemrX01XfeYaO367C6+W1QFbTOBN+7BvgSpvtcocRNn20SDLCRzV0hvC7Y9+X8JNwrP0aTwBjY8Phv/xD/6koXD7Awm350K4KWIEhk8QJdCKZigTbojmVmmYnEx87fXXp0s/daVtcmYQ2xMg3P7mr/46PVwQbiFQrewbSa8GzgH4laHSQvcqog/PPjemXfYhXmlZAwcOrEpHHXVUenfZsjTvnXfSLk0zLurSNS3fuSMtVWNcqcbTUTwQRnwSjpeIOTnhXWmE7A+KL3ITfxB739jtzwg976230y6N0Kz4oOFxBtnoMWPSZRIWnAnGlLdamg4UtWn0ZUf50089lXVgr/NozFCbOsnIY45JZyq9Zy9bnkavW5/Gq0zGqxGP2wM6SWV1vDTggWPHpB6LFqW2uW/ZiR288kZHWanBZ5Y0tckSarNV9ht2xxflc7BkwLFIxzBt79Ur7VLdT9GAs2jRYnvjohrIla/P7bZ3ZTnwgH2K9fa5vWqbeItHHuU9waYyGhQ5Q23durUmdNDieYhA/deaPiJc2CZCG8A/Wyaq1UkQ7hBnp9VKKw812MDMGwp8J3enBmevO2+TvDjPF/Ebv6HwoL04v3XzZhMsZUT7VpZMqIl8DdnLFeG4VoKabU+8vTBIbQQttlpctUD6eTgxZ84s/yqY/QGulGV98vXUxkReyv6Ul8q/5lP9IQAZ5ISHT1xwfhoiLe11NUB21p/ZtVsa3tYpbZKwY5rJhkpGRV7QPlGjEwLxSWkx9919j71nyZS0JBzEkwP6TjppnG1mpAoAwm32rFn2qhOHWFZ7ynQwIZpPgOOGekpj6aUy6qXGu6d0qIjwTCt5++AFleffrl2b/rfK+CfSlO/ZsDFN3rLVvnnK2paXZg7S0l9TVt77ZZXwyc2b0maVYTOl2J5bYxCiSKXSyFhR32zAvv2WW+3DxRz0uENpj3ZwIOFpzOMtddymk5IJMklu09Qgs3XAxhfdPZYgwOuEnH7zwF1329SSE6j3vgxy7s6heT55yPZkiAwVM1aBj5RwCwwfPiJNOOusdPjo0emWDetVILttx3xfNZJVq1amSZMm2kvuCCS0NY6iHoXfX92c7uSL3JoSFIUVr/mgouOnOB1Au3hj6rR0q8LBj5Hvw4QabaIpFMPS9nnbwz8IUqUhFkDpIRxP1rT+mu49THtjo/X87D3EDxIsdbz91tx0xy23pP//L/9LevKxx2zbEELuQIEyowyjHAFlTUet049LUHGW/IWGBnEfdWKf3csIwWXCq3TF0+70tjTxR+5/MD10z702/ead2GaRx694SZABxgcWH0nhxjuiY8eNS+PPOTst1BTgbQkdXqI/UpoCi+5Tp05NK5Yvt8feCKve2fulLNieOHqUPSDIK0VajsLy+J8z+4u71HltafHiRab1sX7H+fUfNPJUH3jUa76kiy06x0tTu0IDCm8tsE+fNxumizYcKM2XhARVgL7NOXFvv/W2Te1+8vc/Tjf967/Z60Q8RDhQg5frORAPPXwiRkdFWNVDOOPPv86Wa27A3MkkF90Y2V3x6n/r169LMzRw33Pr7emZx5+wgwua1eCIx6aNiiA+Tk7IZsjhQrEW6SfzVx8HjXCj4BghETg8CS0Sr0TtCSF0OK55zLjxqd/w4WmOeHdTx+IrTi1bNqe35s5N8+bNtxN0QSd1ONYxPnvddbbvjSdZxXUG0sYZaIcf4S8Sh/ZGZWzU9GvO7Nnpmaeetrca0OYq078/qVp+g3jqycvWzVX9/gP71/jA82EdO5QRR5fzPYURGmBYpzuza9d0mjS2Ia1t9tT0VU1lpyrNvNmAFrHHUBgETr1ywY2DAWwKViiY8s6Ug7rmhfN3WbvUoHXLTTelX/z0p+mOm29JzzzxZJquQYzjlxB2PD2nDfFwqpn6aURbVRasEfrpIxJq9GOZYqVJhWTrctXCQhE/WhbfHvB3aCUQjEctVC931pbJIw8IbvnZz+3QCO4bLb+gCLCToFPHNhfIZuuxR5nXo3opDTT24ThonpayreKqq69K111/XZlgaTYj5VBDVuXyTt9tv/xlmq9G+Rm1FDrUHZs3pqXqZL/1u7+XvvClL1q89QAfnojxShbfreQ7p5z6gRCLV3Z4ssZbDl/56lfT8Sccb9styrF3uaiGepx4d/HRhx9J//fHP5bHFnsYwh4rvjMaYD/WxRdfmL548ilp3CuvpJ0SzLu31d6dXwstymPH445LnVVnb0uzeebee9Nz0lzZtBtgXa+b4u4lQce2EDQ3NLRZio/3UFdrGoh/pi/s/P/9P/pDO1CRgxEqvzTFGimdd7sGQBbByRHbeD7z2WvTF778pdS1S/unm2gg1NMdt96WHnnwYdsmQ326Gz8uRICXa3tBgBbEUeR9NFgee9zx6YRRJ9rrSNyzXNFFg14Xxc1JvLZ/LQu3N0BITp/+Rvrff/XX9kCAwYp8onmxp5JP8H3lGzemMePHqY+0f1qK4OFMvP/13/97mvbqlLThvbVZ7igJz6nn2G0BZs91nm+uYUfdtHXpZDsM2Eo1/rTTbF27Fjjq6N/+8R/TfbfdYYMAa3h5nM65HiLeet5wYpt+fU7yd7AIN05d5aPHQ4cerbu8kbXPQOPkuiqfNIptSyuWLkur1ai/pAbK15ie0qj86I6t6fxLLk3/4bvfTadNmFDzaRAdgQ71lEbw1ydPsVMOOCXh//yP/2mnHzDSgjjF9NiRx5p75dMwU6X3E4xTjSKgI/OkC00SgXuSOsHgwUMsPZECRtYxml6fK412qDTY3fK/ey/WlFrgOWhQaptwWtoye05a/9qUtMn4FDuOb5pdo073rtze2b7DHjCsr/LktE/fvulTV386vTxxoh2muWF9+RSfL75zjM7KVatKwo2nlWjcw4YNK2nTnk/pOVmG0ew4r27xu4s01VrvloKlsgnh5u4uAPjANqcFU9fdJdiMenRPPdTZO0sb3dd6Zsbx3ntr0pszZtgSR6xzwRWx2fvww+xEl16HH678yTYraowRM19mm/nGtLRm5WoJRx+08BbunptAiLlwdVOQoyXtatllOxSuuvba9DkpBONOO7VmXtF6n1N/ufVnv0gP33Nv2qh7eyJrc2OVYlF9roKPpHDj60F0QnZyk0H/y/Po18ZJdRU+gxrHLnWm4RJSv9bzEPswCRtJf7JxfVqlkffXf+/30xVXflICYHA7gYRg45QHNLWJL7xkU9V+/ftJ0D2ZfvWLX1hHCc2NVCEg6Wy8QcEIXoSlZz8JOPaQ1QIjNydObFEDP7R37/SpT386jR4zukyT5FwwPok3sG+ftGHhu2m9hEW9qUat6BAmh0iQDx45Mq1YvCgteevtUnkECAux141hgKemaGq5SHFQMuz051OIvA3CeihaTBEvPvd8evH5F+zJdAg3Opi/HdC51NmilGkFtqdK/yx1MN1rt2bWhHALnQcXBAxaMFpTC8KUtyqk2nHvi/bFkHsO2u4uTaG3bdls08KIPUAf4XDVDhKk/mjGOzltqwMDusqWKS1lx/al3bxrlqGoU0Ze4b6zkOQwVuaEoaiz+gcD5RVqUzf+9m/afrhqAi60x+effCr94if/nJ589FHVvzgofdYzGwk3K8f6wP1DJdy8IiPBnsEw56LC/dSDh8vDsx50kUbar6nzjFEnWKjG89P1a9PDajxHjx5tqj6nPdhHjfkOpkZFTtPlETjHMb/6yqv2gIHpHdrDfffck2bNmmVrH5GSRgUY+dgfqK5jloMyapOgHTp0qO3lY0oTsSPE0Vb5UtMkXkmTUKr10rjnq3qJs07JJwIvueLyNGXyZJuyVzuyu1HZAAYDNuR+8Yav2GDCZ/QqX4VasniJnafGoML6WV6a5Z2haN+gHylxtYVbcI1JFfcICIg/NCdcoFIZSbg0i8qkRbx0WhNYQHFggiwehBdXawWeDmYpLliB0ml+9Gce3db5uiniwYQXhJvvG8wALwX2kO6X4YgrgwgfB7/i6qvTtV/+YhogpYDBpVLIoYFyuOvzTz2VfvoP/5hmzJjuygCJKkRVC84t46mLmQgXVjLH7MyoUNH+Qn3m/eAQbpEchyfaE1w0V1RDTeA/QvAx4HM0Rft8jx52eOLiHTvTL9evS49IXd6skbBX78M0tTnSvhR/zLEj7fujHLHMbnG+Uo42xobGGdOnpyeltbH1w4679tbTVHpAnpt9QzMcvHk7QqOIcKwfXSqBNOaksenB+x+w73Iyfa+O2nlk2sum6xu+/nWbtt95622mLewNeGeYp9Hf/dPvp1tvvsW+M8oxU0XEWhnIc5fnq4hSWdctLASAlxTeIkyYgzPCrVSWsjMyJ3cHCB60yWgTAb/L7SpTG/dhi7jhrLmiL4QoNi5EPQrc3VZ/ujE+9HiLimvkSpAHfyvBKfNt+cC7CTf5N/7mSe4IfdmZP4vfzRBfIWNqfP1Xv5ou/uQVadCRQ2ygq8QODXRLFy9OD9x1T7r9VzenN9V/1qnfVRRRXXhKHSWTDJbVTLghtDtKuGGGNflAS+TasTV1+HMcqtH+QjXe1Yjkkcxyu3KzZ6EegoMD30yLaAScIDtDHZnjslcwhZP2xh4ejkFib9vMGTPs9S2+qMR7rF27drE9cC9oSvTYI4+auwm29wWRywZUxaod1QHTyRHS2jhVlbW5pUv8mHHv5pV/tUsbbRAeYyXgFrw9X413xl5vlWDk57sOvHfJKbasj7F+WAtew8Vabo9wr0WOyGHwKoShwegfpQDi1soCc9aZQn8CoTFkvgzVTAFCWUj4cXWj8SxpbuGLyHVFtILwY7b8FGPKjPjOslC4hgEfbk/mCGL1nblFzdutPLkPB1r++nVrNfgsT/0GDEhH9Otb9RBPlmk4GmqwZkMcpbRM7YzN8Uxbs2iqEoj0xH1cgadH7mbJYJANOLiZDcINIedLFwcJrDoycxG5LVefFri5FhWBBH9Ho8gv1m9I/3n1mvQPKmheB2L9J0CBs07BQwIEGQdXvjb5tdTr0F729PH+e+9LMyXwWLf5GB8lVLaW6ghf1rHUbLxjeUcyZPdcim3Y790ut3U7gwzwc2Puh27thFl/DM6Q7l1AyW90cvdkhDn8QKFpmk/dF7xm2g08OaHYTyl2gZnFY2EUmnAEyEB6GHimvPJKuvXnP0tTpGUX34EtgiWQgYMHpc9+4fPptLPOTL14w0f89gc8jUKWtsgXoExxO4iEW2NEhqLSqpFluAqKu7IbAWE3d86c9Hd/87cm6JYtW2YN7GN8dJC3kxpthvqmk1hHib8M7mSEgAgtg34LRTssp7Ar/BlvUdbhsTMGZgt//uLqgocpsWsp5tvsiu7YEX9Jo5EkDq0mJCF/pDu0G7bs5P7lN9KFd2aoXPRjRQLJlY8iTZ70SrrtFzelR+9/wLSzWhh81JHp+q982baTDBg0cL8JuADpCwp4ORzU8ArMTaLsUpv4qY7KAqgFBBmbM3kyx3cReNr2UQLTR56q1ntK2gxYOGbU9o2nzZRsdRCWMuYAA7aA7O30ds9QalFV4W3F81RqWqUslue1XdaNaXvOdOponiWe2Cl87lsiSna5qCr4FZmgksFdyt0qUbIvpA9jEPBDRDnBxZ+/EmtReHoZYJuHCTMCjS97PXTvvfY5P7ZNVWsHPHQ47sQT0iWfvDxdfPnldthAbN3ZW1iZZVG5uPZU+dXdFMX7fyqIFfAeAP9RuCDuSzd1kIeqj5ha1AOdd692zu8VPJeNEJ2jWTjXvFRYIOYhCaehsP+Lo7b3RsjRKdkzB3gPceniJXst4OBFSHbX8xCHJ9U7qjx53RMU81wbeXrdr4cphgtzdV4FW+WhdCe2mItpsGtWee7m7tm/kSHz4ylzs7tLq5LUwWzTxyzpEUP4iTsTmmYuecwhM7eIl06aeiLg8A+iRCI0qGwdEQ9+efC2Yf1621zNPlW29Ni+yoxfgN0GnOLCu9y86cB2H4Rh+5EhR6ShyAm+LnzzdJTHlOMgEW65D6+UyJZQuHcqmttT/DZCM8LtwCLPQT1UtJmGcK5eZgY1Jt6v5VUxFnj3VoiEdjtfApLF4n1dj6ShoymziXVfBRsoy3NdeOdyv3nbKqIxH4WTJwstdsHDiV8H5rAH1tbL+ra7FK0ivIXTj+lzFkfBvvSX3+O5pMe4V0MY4cVUlOecvIdKrPZQJOMdf2iPvjZXYJKZ+WVg3LBhY1q1YqUGuzbbxM7DJjRxNvSWyNbl/K0Z9uuxn5GBtV5dR5xlMVNmdnUqc8zg9vLXqc5WkJoOe4gq8VcFe1fsCkXkSqTNna3Qw7J2yqgGXGv7cPBEpSFU05V8bOTQEMoV0Mmp4Ga1FqucQtgI529JWE7L7CsRZQR4MwJNrBLsbEfjhIeVpf05ir7hVMxLJQjfjFYX/C1vhTRZGvagbPAVH16pLAMvn/b2tWDrRzXyFjx81cl5mS8zlvMmL3y9HD7hkofHt3f8YizV04edlw/CxHjKptR2siBcvMSj7iCZZfAF/yymbHTO7kqImHEOczSZYlFQmh0Vb2f5Io/0BzZY821Zf5DQUemSvey2JV8mKMaF2XPg6CAtvtdhve0NhhNGj7JX00oRFgKyOZkHEvffeVd6+aWJ9j3UYnlhcmJ67AELwa0ebF1QmTJ7mfPQDrPXz8Er3DJTyWxO/ARVB1nOsl0XeyPcmIZRabyPysGU7AZftnSZTe9Ym2u0VkRn49Ud3qNkZCMM761izwbiXr1623SRV6iKrwoVEWXECMi7lQMHDSx1fEBn2bJps2lUtuFVaSp2vtJVjYTvP7CZl3PtKtdAOChxuaYObJPh4yn1AHcOwWTawX61QUMG2YIzU9UFmmauUR6rd/gckZ4jjz7SvtzO0d2cKks4pjRDNOXBnf1vnLXWCLxr2n9A/9S3bz/VW543OiuvNr2z4J20bj1nlbkoKW9jOQ495FA7bJJXn3Bh1z+dk/RxUsbmLSobOZQ1J92XtxwH9cQBkLwuxiEM27ZoGv72PPvyGodM0n5IDXvmvM58/Yu3DxBsBrt4bOZH5RZx40R58QcfBFy4uUDIwsmM4GBPXSf5ZDzBPzqUCTfewJBwI/RO5Xfrbt8qFDHx61SIG6EjjexwtUnaEx+zDjc36Edpo33uUplzKCaam01NC7A8GDUn3GhWxbIupUk/dYVbc2gcvDzqHJiL9+Gz3C6/98EKP8qYLnmmyvkazCKzNW+5D27zMbs5IEyOGTnSjujmnU3WrdBK1q1bn2bPnpX++Sf/ZB2P908rkckj66QItm/8+jetczzxxBNpxvQZtu/sC1/8ogbMjmmSRrMnHn/SpozVobwrKwjD8y44P13zmWtsShivF/E+4bJlS+27D7wozpSgWD5eLLpXR2Ok/eZvfCsNV2c7tHcve7WHzk5H49UzTjp5/NHHbDNmPXBSCse0n3fhhfbeKmWDEOEL7Dx1vvO225SWefatzFpobWtNh/U+LN34zW/YCSzPP/ucfXkdsAfuK1//mr0p8uRjj9srcJXIa9fBqbe8Wsf3NhEqPPjgpGDeolgwf0G69Ze/SnNmvanOFlpJkUNuPu6EE9I1n7s2nXb6BAmyLbbhGQGCgJ38yivpCaWHAQ5xgiBiD5xfvdK96bWknof0TCedckq6VGlCULPIzqZn2gFpeZ3DAtb4sULETppJk+mLxsTr3QWTX4GlO5JrXjMHwawVKAtegHNGQLSag4eyJ6LmjBuhFVYW29Qm3FfGM0NudpOFkICjbbnQ9bxgQlS6AHVNFdq1kwgtRiFLp35zG34IncPShQd4ZD7dn0i3XCJEPuTvNSymBhS/5YiE+DWnSuSc9CcPNioVKH4B4W20K1CRZ/jMQzQHjp3mzLcrrrwy9dHoxDrT/HnzTfNC6/G01OeKRsIBASeNOykdf+KJ6UgJqOOOPy595tpr7bhy0rl69ZpsNOOuGoEWe2uC16vOOuds48k5/osXLU6LJYiWL1tui/N5w8nh6XRi8+6q1avSMnXU7nzbVdMJBDiaCVolR/pUe6WqCBob2t9Fl16aLrj4ItOuWM9jzyCx0JHRdju0elMrxl8k+HTq0tlO3aAsEE7ewfxVr5EqJ87T69O/XylMEZV2Xbp2SUNHDEunTphgQhEtljRRPggmL2M6n3fAHHkZQ5yAcdwJJ2qqNTp1auukcllp60QIPfJ8ymkTlLeof2/L5JT1rKBO0mr79x+Qrr3+unTGWWemto6taeG8BWmhhCxC17QZhQ4R4jFTJpGj7KqLC428z5gl9Wx1nYcttX9Zm6aT2QfwvUudybQ1ESK+1K8QHAi03WHrKIYHHiPEr4OZgh3LpJkJZMdwbRfpuhNiEIZoV4rD0+Wcg7/bOeJaCVKVy4FcjLrZ7b3FfUhgGVWqixn2LLmNm6NSM/WVXBq8CqJQ9hQ9enRPgzQF5MtZTLf4HNydt9+Rbv7Vr9IDDzxgQq7RtDTSzaiMJshrLJdedplpYLz98MD9D6RXpQ1s3sQ5c6S2GuWIta0333zTvpvw0IMPpocffMi0rSVLlljjqgo1XjoUHf7eu+5OP/2nf07PPv20CTTOMbv5lzenf/uXn6YXnnvOThiuB56MjRk7VkLkNOuoN/3bz9M//ujv04//7u9Ne3z6yadM2O7ghArFa5tRq5LXFZ2XsuGbGsNVPpTR0GFDS+fokWMGOFAslUrCC+0CzeytuW9JE3w2PaKyeeSBB9NTjz9heeXbCc2AlkMeKNd/+ocfK48/s6e6R0oLn3DG6TYlt3amfDgUO3WT1U9HaeS9pBmfKr8cjzR39uz0xMOPpLtuuTXdprKeNfNNOxfQtb5c8/My0VX3JqTIUXNJNliSst/83u3yv9zeIsqozH4/geIoCv3QTT1KfhvDBG9mboQPlXADWdkX4HdRQN44XA2OYotKitHR1zQiTHO0XdORDes32qg07uTxEkgX2HcrWVtiK8SePi3s379/uuCiC9N1n7/epm8ccf7SCy/aOgQVWN68ilQOBCVHLaHBXXTxxemss8+yd2URfM6nOhiZSTNaFkcMLVdn54nWRmltnMPFYZ5Ms2sKyAyssw0bMVzXHvbFpQfuvTdNnfK6Her4mDrwLTf90qfH4t0Ynsc+EmwcGsqX0H7zd347ffXGr5uGWzy5Je+c/ke9Fq+Wc5UBX41iHfD0M89M56u8+XIUa3EsEVCvTUHlSDkwheTMvFkzZ6VF7y6ywYxTn4tnq1kOrNHk3BGwbJlg+sr09GQNBGcoHQMGDUqrV66yVwDReOiM1ukV1gZoCd8YoOEWAq6ZTmvpqPkXg3yUl/svCWQRPcT9mct+AemOr6K5cPN8WXzKZFla6qI5XxoL93UrSDOZ94oOKR3A3KzENoTXLEqX/DkfRn0ahgs24L94z1VYL0DlOwvf3N82aR583Jk9WGgWg4YMThNOn5A+8Ylz7UQRHiow+qJuF8PxF6BzMqW9+JKLbVrDQjWdjCnSxJcmpqVLl9Z5iT0H+TyizxE2jURz4FSNnj16pD59+9g+I7St2dIGQqDkKcjhZeFAIzpp3DhNu0+yhwdoKDwEiClptfABput8kYkPFk99/XXb1BkarE9vnBqBNLAQfaHK5mhpRExle/Y8JPUb0M9ODOE9Vg6w5ASSmRKcsaAMopa9Zj0uPuZz8imn2PooZcyDHE5I4fONnFjBQabsz3L/cCjnFlerZwnGEceOsHKnzi7U9JvpJULrqceeSJNfftkf3Mg92qCZs2zvZB1z8yY7j46yOERlxjT7jHPPTmeff55pvKtXrkyb1m9wwWYaXA7MJU1H7o5GZeru4SsvrfKQuS0mWqsLNsDTUrtm9/XgIcvhHEXkSVceXPCk2MuFHw9hxyHplvoLPlGWjWB++fV/Q1w/XMItg4dzBA+7UohZcrinqLitJEBjCR7NAN471Nl5Qsb3EmbNmGmL7v36D7CPx/ASOp2GEdrTlFOgKNzobIR5XVoO61KsobFuFt92qA2lW2kJ4cYZaI88/HB66IGH0jPPPGsfZJ45fYY95SS9RUTeA6Wy2AfhhubIh3NGHHusPWAhfoQqaUTA8G4hT4Dp/LTgyrIJIg0IaIRbW1unNGnixHTXbbfZZ/n4+DHaHAvw06ZMSW9Om56Fi5oHRRuPe/zJp5h2PenFifZNBKbIr73yqpUP5cxbGvQfo9JQF1ycowu3M9Ix0o6x4cQYvobG08BXlEa+mLZSvCxvYpT/efkGH4QWES1csMAOo3x77lwrJ3jhPk/a/7LFi9Xx87DAw0fq/D53bQ7u20M6cgGW88zdg7sPFigGxbDVEXkuInhbv9SVzcJcgy8o5iRSZZwor0pknrlEuNy/m0FciwPEhwKRcIA5CjWu/JDxXFNzuB/PMA1lT8F0ggaOpsRUZNu2rTbisj2E+65duviInfkvIuIugq0anDRyhzrwtKlT7fubF196STpeGh3fH20W8OUAStLB2g9aJdMuOjcay/sNHj7wiUPOWuOjPDfc+LX0qWuuTleJvvCVL6cv3XCDPSBAeNPIa6FYRmjHM954Q9Pah0UPpWcllDgpZOdOtGIGJsinNmH2es35FGsCAcz0lMGFJ7kcPMp0mgc8Dvktec/DBZjCk6aZ099Izz39TFqmvLI8sVVatn0GUn5qtT9A3fAx5svsQ8cn2nFRmzSIMIhRLuzat3U751AB2VFu8M14B9/6KPJyc7WwlQpAZb8JIbg/ENqZ8/dfYqfe8noslWRVRLqawYdKc6sM61dv2MYnOo8uUYggrriW+d8DsKeMD0ZzFDadg6d5bMfgSSVPKTkbbdHCd22K6fHkFKCDMfJPmDDBduM/LuGGhrJp02bTflg0X7v2PTtAsvbeMqVc+ex9WO80bPhw00yYlvaRJnf00KPTcNkNHDgoLVm8SNrXe/7UtIS8roq1RudnTYv9e0xpeThBOtjrBuqVlD3p27krdVOHRfjztJMpKlrl2HEn2QeL0VAXL1yUtkiDA5R95R+aG9osH8xGiL2hKS7Tva1bNrtmOX68CYkZGgje0pQ7F2aeukijy4F4ynmCPcllmwnlxTac4ccMtzQtWDA/++AJeSS0BQwG2bUl9evX396LZM319ltuS3fdfofVIzvx0UbnzJ5lT19t4Z8wAmVLR+aONPKUlaN/rv/aDWmk6ouXx+MjzQxAHPQ5TRrvmlWrLNoQYlYysohpLvA1sCZEDh4IYwRPNxsf/Zs9/PGb/baH2xfbSi1YWjNzwGMQKS6rL9146p2ju+f9MecgkRfGAvIenSN4ZP+GuH5gwo2rU9g0RtFnzif7kwXXKDwrHPPkdn5T8q2/sGmOaGAdO2r079SWevToaVsN0NymT3sj3X3nnXaqLa8j1VtfYv8P+5vYmsCX4WdpusXiPYvUdGgEBa+ysIm39j43pV1pYU8ao36r0rRx4wYLi5Ai7whYnr7S6cqFWzkipeyWZy8ZR6TzYZIpk1+zja7wBOS/HnjqumTJYnuKjF/KgKPOeZDAk0k0LzZtIkiioxZJP0p7i722c0TfPmmV0o02yBQOKcEmXKbhnM47e+bMtFyDSNQLKF09crunnA855FDjS73sYC2U3iVXyod6W7FimU+Xq3Oz327du9laINN0HpS8q7g5JQaBTrrgNV+DUXzvwNpf1gZYW1IONR3jaPIOaau0fa6dpT2yvWXte2tNE3zknvvSIj6mwjKAojUehKdcrIykz+gaC+7F1NZEMRsi0pGH8Tsr/+we8lQ7Mh/2V7SvBfdZDucqIh92zSwyEMI0NdwtLQUP5rmAGv3KQ+jX/w2la6cqp/LjiKU7+K9H3J5BpTQNf/VQ7iNCuIrKXRnHoudCBtulJys50uONQH7Nu9vlPh1lcdSF+7RGqQaJpoaGgaCyTrxlq+0HQ9MKYdAeWQqURkZqhBtaEWt2TOvgbVNb8eXTfDwxrae5AfhwSGAvaSiW98ieIuIc/jWrVyW+wVncnlKZZ08VQaXp2AJ+T/PPuiJPUtmI68j9lZeig+jRqkj/oeLDFAvfTLsQkv6xE96UKBwuKJZw5U0Rqy9deerIgj/lgcDesM4X/BEiTLMZXDZtWJ+2rWerjLcT46Ffo4wX+7dapS3xcIXlhLIvRSkAQoQnn5vZVNyu02Q5zKzZe4cWiPZIPfNkk7zCmykuwu29NatTyy4vzZJgM0KweX7bFL5Lt86pa88e6nSdTZNiU/EW1f+mtevSbjvdudh+FDoLS/nCtbJd14WFyfyK4JNZh5VIf8E8Q3At1rWfRpx7wpy7AszUR/Q1B6zNn8oEF8YWCKFv7UBX3Kl7cl7to94QsLTaH1AohcludBc/QgQQJNxiCd5hidE/lYQDRLgI62bzZYjoArlLddRydb7Oy7SuMmQWco70lP/qarn19FhVlCerHYijrhdzrPChOBhh8rUaVYoaNUKtfnw4ugfSSUehfD2c29tHRtSpAfaN9mBZw5f/CFOENTF1HF5zqcxCEeFEyQWvYrpw5zf8WUfLzCDM5kM33JO3eG+SV5UQavCiekhpaZ1MFQBfnpQhftmeQxdgTxh+7f1YEaBDsK4Y9h1kDX/gafSOv1O8CFHaGmplGj5Bnn40L9bS6Gj1QOf3HfdRL8RAGyi8Q6uythxndRkgttKUS86tStkuhduhG0Q9QhiB1kFl1JGr5QR4Oi0cJm4EjgSPl9urdJIyRPsmf/iMuotQlDklzp8hu5T781++fhWI9gryPgd5nkgc98Yjc3c7F25sdyaONiXQygxn0Q5rB15/ZpFdnNzCzApivLOwIDeVo4pw40cNL0sQjlkRG4Jx3EfEgWKkgfY21UDxZKZaAQoOxXjMRJqztETHrIe9ebe0OmDUiBlcGnFqhk9zoCTai7w9B7kvppwyL/KN1Jb7KheCpRyp8WKLYLPDEVWXhEC48eai6ZeywE8xLL783vl73rxbQBEzaUC4wYcO4tsY3IeHdBh/tRXjafHVB6Hzrl0dcAuNpIhiOeCOcCN92+XP9NgsHbwC1QFBW0ppQShm92THvndAJHir2UkcOOOttAkYXll82PtgInPmbtwUyP3mMP9hIb/tYSEtXyYwMz/GSfE5FJfFI81dVgxwrYqLK2BgKhdubk8K28WYsYySqYf90Qf2C6zASxlsT/FXDdiGG2Vb3dfHeL9QbGZhrqwD7r0uvROYQFN9u2CLOga1Gm00Zz/BAr/FOMrDhk8H1yIFiuZ9hhJQTA+oTGNESKfjcEgm72xodUHWPj25sAtOoqyBI+PqUQf549QPtEHM8ELQObfoSz4Ietz6k6EkjzLgC8GIP5u1WHozsnvCZGHlu5KI3/k7BeCb9+sCdINNcUAhHPGZ1o9QFKGSNaKDQnODg+1QFlEx7WCVAx8bf8yqWjzAeFWkqRo+1twaI+o/Uk6ZF/nmqS3Pn9VN5hj1aRqHYJ1Ejqz0YoO9aVoiwnWUmkD6AffRSfzef+ijmN09YkdYZh1GFth5aA+bhbZfD9UcCN+M5lbk6GmO+NxEvlvJa5b4Upfnv2z5AIPqD8GR2aHIYLS8EcwYmKEmKF/idF+EJh0SNbJgMPF1NLetRGUf9PPecpS0s8yeO9PcrL/kgS3vJkvw4/VIEBOMoljtp3y9HShd5jdS7PCUR36yOMuTVBUHnXALhNHCmpmCiex5+vYFHwu3xoj6j5RT7kW+eYq9q5pJBq+a8vxyF9Mio8wZ/yE82MDK6GydwCwysxj6PT/yr7DFhg532LmQDGEUbu1BOO905WmshpxfbVg6+C+xc4MPxZ4O3qjwdTW3cVv3R+4iqL15oZuiP9woJ6Zu7k9uDXp3Z/UVX9dSiIw5goW8mLastJiQwzJDqTgyK24xlksI7N0i8sYdk2rTqI1JBJAP+OuWMFaXVqfO09wE3JyHC97gUFkOmDxEczh4hJv+drZQROVxWeYsCvnIhJvdNdEw6+Fj4dYY5L6YcmqmmnDLu6bDhYHblcJmjTqAuTyU7DLhFi7unw6BGzy4c2HjL5mHHw8B+VQH20iV/wasfUWnaqINRXz1YDmDpbFznp4Cz7O7u3DLN6vKCmGlNJhgyHyy4I6fPKxzpL2St1L+cKiDzoqBt2eZkpLN8A6v0Nx8aYC4HZ5yv4YZ0AeNQ0V/KCVBPKyc5Og+SKFczQPh3J7bKHuQm8yLgbQUq8XCuNGvhfCNcJAIN680m5bqz6S67F1q6z5j4I3AC6J9w8zvq6WhEh8Lt8aI+o+UW11kZhApJj6u4c/DlJddjMD8FO2B2csy6s1//RoiKq6AxXgXbOXpwYd3fhBc8nDA4lD7xtXbeH3go5Fwq0Sefo/HiGgl3Hj1nw+F+2YZb/c7JajttXn54XRF/EQ4EGlwop+4uR44KhIh6X0pEywZR8Ii3GwqSV/XNQjkZeiwUiYDFeXl3PzXQsudsCCPL/hn9vDJkHOLlAlm5XfhGiZ+Sz5zNjVRbBvN+H+fQJKzolAO7Jr9+SgX0xVHnmkH90Efbuy/HLwfZVG7fbhLuXt+FzMoq0G7ySnsona9Hot/buv2ecdjoAu74JV3YefmArCcQFxzQ3006a0ET1N7wMfbMutYTjw5Jp0M4OaGvTi4hud5gNzsg1Y8GKiHHRKkHDK5TSW1TeHiAY5tl0FjJDGiKK3stirwG2Wdkwsy25pCp80QfIq8MEddBLwWnVf8AoRf5Lncv5MJd8x5kJooaW6evRzOLOcQrp7Q3G/RD6jkU35XHREXf8GfP8+kTMow9tvlbq9y66ZSc4t7/Hno+mikuRm3ZkrQ0Ci2/cUHNPYT3XxPURmGVJe3gfJyxVwkEGH86qBztLKfoOipAs452oB7cO/cuwl7XNDc+Ct2AqiozYSdh6iEXPSPS5lrdlMeojwv1RBuxBcIs6fU2zFbQdCo2mTB01LsabcIalv7EiN7giq74InJNTaPJzo3U8t6MOElcKGHuzDNUmNRiY/s2WvnfPO48thBNmXOwuRdIhtKsr5JEGQcfsweu+wXWNiSS5G/g+x76jwMW3ksjG5Nw+Yqt/J+7oirwfxlxs4tHSV4XVzlwbwQ+QPYmC0ZkZX7cMQGv7DD3YWTAw45p/oo8i0i7IkpRu5awG9eRLVhxx1n5loIXoFQqcsFK+ZGse0/eANxlKUtu1orsTQ1yp28luWjcZnVQjPlbQ+LKpLkrS6Hd7P26S5OZXBnMRwrjgbCxQWcCzu/ovlYVzBuRQJmNpb6KfAudlz71cW55H6qAd/emjw9QQFs0by6mtkfKqCp2awk4leeol2x/822y+g+3yojyN7KAm/utSbKt2B4mYTZr2IgXjHFtSmq7BB47kPXzGx9Dn+yME0Nt8ydJ57u2/lY3gp2JBT/uHm44J7xyKgEpYmUkh7i3cV9VIzMHRgkdU+pRFiXNzLpP+IicbacZRm1K8CcMWsSHs74lbBnHOojUuTFdCAROZOJRpUhN4Hyuw8vDnTZ7h3yVBbLPczFq0h1ZppFFUKo8OcqAR0oCwMyO3MPuyZQzafz8HT7Qj4Ca5cLLpFtn6DzZhmjQ5fcMv90VhMO+OWtjyaqCv9sjdkhyq9oiHITIUBhwwAXe+JsD5nS6xqxl5FPl12I2cZbEVcj+TH/MttRTfJjZOEz4V2guOfP7fIy42pmhffycLI8u7VlKgSdcVEAq0+7D7hv/LV0bWn10BnCaIXpxjwwjGSZM5Kf0NwKPEh4EURQcN5rBJ96vDytnuF6YERshCIPCrGIKOQDjaIWUcxlyWTpbFRKjsq1m8alVh3NlPf+0tzMB5qbrhEvv9FRIO+chZLKDOp/Je7OJ4Z1R7VWWumnGnBHKEUp8Btxh511dvqK0u7pYwrqGl2r7vBF/Cz0c6azay6Um6giAZ7viKE6KG/rmfJmcYviEEzM5AoO2AH8+j5B0lHkLbPSDEiGuWXO8Ipq9b6ZaaXmlqfR3XQtsg1Y3uzHAH/LtxHlkZc//KLNtGRyx+LKGEc8pvFhbwnEZS9B2KJgq+RVcDqo0CjPRfdKwQYahf8Y7w+83Pl1E+0rKDpFTLEYwGxaJ0cTFroGIdf1XyB+3z/AHeFhWhRmI++OxbgjDxB91lxQKux9Xc9zM/A8OWwMsxsXW5ALheyaEU9q48FFHpNz4TfElfV3Jc4EP9uzsi1aOS8XQvBykll5sGtm5yFEFpHHZmzNFDaZnwIBv1Im2V3mEO4Bn5aae846ImgGZNR4ZASCU5EONhTTXI0CYa7n9jEOLCrLPcQD5IIBoebaeQg5pn926kQF6T8TdK7LtKf9BCUaYWVCq4xkacLLLrrzOGU0cG9TaMjuc7d6wI8JETGztxWUSZ9a+r2R8ZZfUS6U3GwbpykYpab4B2eb0ioM62EhsLnXv8gFW0l48Wdpz3jjT0LDSPzcT14epTD6K+VbZFPksM+uNhWWfwLaVYgrlorLM1G0zKkxShFlf7AvFob/1UfE5upkPWo2Vc3BU1ufVLL8OjDHfXYtuH6MAwZK3btGdI/QduzJo1FoR7kZNw+DbuLdL9qe9c4iyc1p/wFueafPKDN4u/ZOHO+bmpCQm5N6F2ShGqOjQjPdbcsIM4RACzP8ff1NASxhyAIuUbLcq1QlIVtcQioNlKL3RHurSCb6ZqQfuNlh/V/83AelrqlrJjjz0ocI62R/lEGW38i3LpkdvophyxFcKDcLZDYZIqnNohC0hOrR1kb4r0f7E1lxNfxzv/zkuaSwM4NfP8YBBuWek3eTIG8r3gXpSmHvk60Qanm48O8d0O7lHPb7CwgN06JkjqmaHQ1FG5K9x8VT3hbbLmL73yQACOMaSrFFNgfPpUhxWDxEpaut44nY88b2Kt9ipbwj3CCFKZWS/LN1pRMkP1Cb0gWxZcVOM9GVtEe5Aa6ZCPQ/+bF16swD5WFmCxuwGLNfdzJzyYvcwhy8zI+nOSfnQR5yyKbEZw8Bs0pYZqs5HAQgWfXIUDLUAY3mYxxQ1Cpxb+uh4Yd+URRiYS63i1o3O2Oe2zntH3AOXQi4EnfdW5qt83uHLL1dkLmb8ID2BPJvU2/xjqeuaK+8nwptU0KgknCT33hp3eSgftCSELaddd9Z9l10RbhhzoUcD0Q8rZZC+fE64Nfrwom7LBvm0bxWgYfLhVdmNribWWf3RR4u1DLBZuk3y4zExKsYBItyKv75fe4KimbgvHL7arS3KEt7RoFq8ewJgfxepRKWQGYvQjcfWESqQJiLiSia60DeqoWspObQvM9aiLor1mU1qg1PcaQk0l+kHG4T9mVCUNLN/WYx1o+0hEpveXzRn2QylsFfkAGzx+0CIdJi2lYW0jUefOivyfQEV8J5jFkM0rT4C03KXPCmawggckM0TFttGitLJ9cqId5bRajZ4ZMWh4ciPGl0fkWKVADPG3++rJUJ8gLhkxAluzywQDpzAdoOKjtCtfTqIPFNhcoPiUDClxUynkvQfcGiFGkF2lnJYxVvew4SWUBl6gJNNYAKXtWQF2+WVzMyXcDNw/NbtYALKCWnXrqMZ2N4zTiK+S+ZdTFTA2bFdNdOlnOt7e5o5A6KyQn/cC+G9dJu79N+s4aHq2k5xYCGPBymEFLeabwWbb1G9q7T+S/aDGb8uSmPEwHj5S0qJqsq8gRZ2uSf0LZuJsJqZ4edJizsnDW52/RUU1PShdAhEP6YriIMTNuSXzYtc8/eBmNN223XfnHJ0VEds6QhZmkxsyjyCgf2vxEzcDfS6uVREjxMPWWwtGOjgJQbGh+vd8EjS7nIwV3AkioLFgbIu8fgvCMXWSkLbsMv5EIRclCi1MlO/RXLl3TF3r3g1SFU5chIOTnL4r0VVEaZczuU89h/qORbjZpFJL8RlaHQo6qVVk0KY0MUwtSlaiikWJdqoYIqESEr6WBApLeYfn+XsXZqi37bw/3G0zp/tEAX8m5kQ3uLE38l3sWGX0k4G1WPOWzwGQRscCkIKUwIbtvYGywssHPwqGTOOrHD3YrAe6yxWVDJHI5KR2jyoMF/3RRveQATCrrxdOkGQVSKCH/ZX7ZWqIuIe5xNOpQoStRKNXPL7TL2sC0D+XaSNyeD+/Zf19c8TqIlfjO4hcjtWtL/A+nMZWloBOwzAAAAAElFTkSuQmCC" style="
            width: 389.04px;
            height: 126.28px;
            margin-left: 0px;
            margin-top: 0px;
            transform: rotate(0rad) translateZ(0px);
            -webkit-transform: rotate(0rad) translateZ(0px);" title="" /></span>
    </p>
    <h2 class="c18" id="h.h6vjufa2577h">
        <span class="c17 c6">GENERAL AGREEMENT</span>
    </h2>
    <p class="c4 c5"><span class="c0"></span></p>
    <p class="c4">
        <span class="c0">This Agreement is made on the 7th day of October 2024, by and between
            Design Sketchers, a professional web design and development company,
            hereinafter referred to as the &quot;Company&quot;, and the undersigned
            client, hereinafter referred to as the &quot;Client&quot;. &nbsp;</span>
    </p>
    <p class="c4 c5"><span class="c0"></span></p>
    <p class="c4">
        <span class="c0">This Agreement constitutes the entire understanding between the parties
            with respect to the subject matter hereof and supersedes all prior
            agreements, understandings, negotiations, and discussions, whether oral
            or written. Any amendments or modifications to this Agreement must be
            made in writing and signed by both parties.</span>
    </p>
    <p class="c4 c5"><span class="c0"></span></p>
    <p class="c4">
        <span class="c0">In consideration of the mutual promises and agreements herein, this
            agreement is intended to make sure clear communication, accountability,
            and a shared understanding of the project&#39;s scope, deliverables, and
            expectations are fully established before the commencement of the
            project.
        </span>
    </p>
    <h2 class="c10" id="h.rybkvwuqsax0">
        <span class="c6">1</span><span class="c6">- SERVICES PROVIDED BY THE COMPANY</span>
    </h2>
    <h3 class="c2" id="h.7dju4c5pcl1h">
        <span class="c6">1</span><span class="c16 c6">.1 Scope of Services:</span>
    </h3>
    <p class="c4 c5"><span class="c0"></span></p>
    <p class="c4">
        <span class="c0">Design Sketchers will provide a set of web design and development
            services, specifically according to Client&rsquo;s needs, as detailed in
            the project proposal. These services cover all essential elements of web
            design and development and will help the Client&rsquo;s business
            establish a strong and professional online presence.</span>
    </p>
    <p class="c4 c5"><span class="c0"></span></p>
    <p class="c4">
        <span class="c0">These services include, but are not limited to web design, front-end
            and band end development, mobile responsiveness and optimization,
            content management system (CMS) integration, E-Commerce website setup,
            search engine optimization, UI/UX design, website maintenance and
            support and more.</span>
    </p>
    <h3 class="c2" id="h.30yz88pxakjp">
        <span class="c16 c6">1.2 Additional Services:</span>
    </h3>
    <p class="c4 c5"><span class="c0"></span></p>
    <p class="c4">
        <span class="c3">If the Client requests additional services beyond those outlined in the
            project proposal, the Company is more than happy to accommodate.</span><span class="c1">&nbsp;However, these additional services will be charged at either an
            updated rate, a revised standard hourly rate, or a mutually agreed-upon
            price, depending on the nature and scope of the request.</span>
    </p>
    <p class="c4 c5"><span class="c3 c9"></span></p>
    <p class="c4">
        <span class="c0">These could include but are not limited to additional page designs,
            plugin development, marketing services, or custom features. All changes
            or additions must be documented and approved by both parties in writing
            to avoid misunderstandings.</span>
    </p>
    <p class="c4 c5"><span class="c0"></span></p>
    <h2 class="c10" id="h.fjfd8ndyfdsz">
        <span class="c6">2- &nbsp;CLIENT RESPONSIBILITIES</span>
    </h2>
    <h3 class="c2" id="h.qxmu3ohdm02c">
        <span class="c16 c6">2.1 Provision of Information:</span>
    </h3>
    <p class="c4 c5"><span class="c0"></span></p>
    <p class="c4">
        <span class="c0">In order for us to create the best website possible, it&rsquo;s
            important that the Client provides all necessary information, materials,
            and content in a timely manner. This may include text content, images,
            logos, branding guidelines, product details, pricing information, and
            anything else that is essential to the project.
        </span>
    </p>
    <p class="c4 c5"><span class="c0"></span></p>
    <p class="c4">
        <span class="c0">We understand that gathering all these materials can be time-consuming,
            but the sooner we receive them, the sooner we can integrate them into
            the website design and development process. Delays in the provision of
            these materials may result in delays to the project timeline.</span>
    </p>
    <h3 class="c2" id="h.acsfthnus9ph">
        <span class="c16 c6">2.2 Timely Feedback and Approvals:</span>
    </h3>
    <p class="c4 c5"><span class="c0"></span></p>
    <p class="c4">
        <span class="c0">Web design is a collaborative process, and we value the Client&#39;s
            input at every stage. The Client agrees to provide timely feedback and
            approvals on design drafts, revisions, and other deliverables. Clear
            communication helps to keep the project on track and ensures that the
            final product meets the Client&rsquo;s expectations.</span>
    </p>
    <p class="c4 c5"><span class="c0"></span></p>
    <p class="c4">
        <span class="c0">We encourage open and honest feedback so that any issues can be
            addressed quickly and effectively. If at any point the Client requires
            changes, we request they be communicated as soon as possible to avoid
            affecting the schedule.</span>
    </p>
    <h3 class="c2" id="h.wson7k23www4">
        <span class="c6 c16">2.3 Content Responsibility:</span>
    </h3>
    <p class="c4 c5"><span class="c0"></span></p>
    <p class="c4">
        <span class="c0">While Design Sketchers &nbsp;is responsible for the design and
            development of the website, the Client is solely responsible for the
            content provided. This means that any text, images, or media uploaded by
            the Client must be original or properly licensed for use. We cannot be
            held liable for any copyright infringement, plagiarism, or other legal
            issues related to content supplied by the Client.</span>
    </p>
    <h2 class="c10" id="h.jjhbe3lcixgo">
        <span class="c6">3. PROJECT TIMELINE AND DELIVERABLES</span>
    </h2>
    <h3 class="c2" id="h.2dlqzud0tnqr">
        <span class="c16 c6">3.1 Timeline:</span>
    </h3>
    <p class="c4 c5"><span class="c0"></span></p>
    <p class="c4">
        <span class="c0">We know how important deadlines are, and we strive to meet all
            agreed-upon timelines. The project will proceed according to the
            schedule outlined in the project proposal. However, we also recognize
            that web development is sometimes an iterative process, and unforeseen
            delays may occur, either on the Client&rsquo;s side or ours.</span>
    </p>
    <p class="c4 c5"><span class="c0"></span></p>
    <p class="c4">
        <span class="c3">To mitigate any delays, we will maintain regular communication
            throughout the project and update the Client on progress or any issues
            that arise.</span><span class="c1">&nbsp;If the Client causes a delay such as by failing to provide
            feedback or necessary content in a timely manner the project timeline
            may not be extended accordingly.
        </span>
    </p>
    <h3 class="c2" id="h.pcwhdoqugi09">
        <span class="c16 c6">3.2 Revisions:</span>
    </h3>
    <p class="c4 c5"><span class="c0"></span></p>
    <p class="c4">
        <span class="c0">We understand that there is always some room for adding perfection and
            to make sure the final website meets the Client&rsquo;s expectations, we
            offer multiple rounds of revisions included in the project scope. These
            revisions allow for adjustments based on the Client&rsquo;s feedback. We
            are committed to making sure the Client is satisfied with the result,
            but any revisions beyond the agreed-upon number may incur additional
            charges, as quoted in the proposal.</span>
    </p>
    <h3 class="c2" id="h.egggr0szc1ly">
        <span class="c16 c6">3.3 Final Deliverables:</span>
    </h3>
    <p class="c4 c5"><span class="c0"></span></p>
    <p class="c4">
        <span class="c0">Once the project is completed and the final payment is received, Design
            Sketchers &nbsp;will deliver all website files, including HTML, CSS,
            JavaScript, databases (if applicable), and any other relevant files. We
            ensure the handoff is smooth, and we provide guidance to the Client on
            managing and maintaining their new website.</span>
    </p>
    <h2 class="c10" id="h.12yqtkeqm8xz">
        <span class="c6">4. PAYMENT TERMS</span>
    </h2>
    <h3 class="c2" id="h.ucbfqm53r3n9">
        <span class="c16 c6">4.1 Project Fee and Structure:</span>
    </h3>
    <p class="c4 c5"><span class="c0"></span></p>
    <p class="c4">
        <span class="c0">The total project cost is detailed in the project proposal. Payments
            will be structured as follows:</span>
    </p>
    <p class="c4 c5"><span class="c0"></span></p>
    <p class="c4">
        <span class="c6 c15 c7">- Initial Deposit:</span><span class="c3">&nbsp;</span><span class="c6 c7">A non-refundable deposit of &nbsp;25% of the total project cost is
            required upon signing this agreement to secure the project start
            date</span><span class="c0">. This ensures our team is committed to the Client&rsquo;s project and
            sets the wheels in motion.</span>
    </p>
    <p class="c4 c5"><span class="c0"></span></p>
    <p class="c4">
        <span class="c6 c15 c7">- Milestone Payments:</span><span class="c0">&nbsp;Payments will be tied to project milestones, which are outlined
            in the proposal. For example, a portion of the total fee may be due upon
            completion of the design phase, another upon development, and the final
            payment before launch. This staggered payment structure ensures fairness
            and gives both parties accountability as the project progresses.</span>
    </p>
    <p class="c4 c5"><span class="c0"></span></p>
    <p class="c4">
        <span class="c6 c7 c15">- Final Payment: </span><span class="c0">The remaining balance is due upon completion of the project and before
            the website is handed over to the Client. Full payment ensures the
            Client owns all rights to the final deliverables.</span>
    </p>
    <p class="c4 c5"><span class="c0"></span></p>
    <h3 class="c2" id="h.9kxg9fep2qnd">
        <span class="c16 c6">4.2 Late Payments:</span>
    </h3>
    <p class="c4 c5"><span class="c0"></span></p>
    <p class="c4">
        <span class="c0">We value punctuality, and we ask the same of our Clients. Late payments
            can cause disruptions to the project timeline. If payment is not
            received by the due date, a late fee of 10% will be added if the payment
            is delayed.
        </span>
    </p>
    <p class="c4 c5"><span class="c0"></span></p>
    <p class="c4">
        <span class="c0">To avoid delays, please ensure payments are made on time. If the Client
            fails to meet the agreed payment schedule, the Company reserves the
            right to suspend work until payments are brought up to date.</span>
    </p>
    <h3 class="c2" id="h.yah5ut7jwlk">
        <span class="c16 c6">4.3 Refund Policy:</span>
    </h3>
    <p class="c4 c5"><span class="c0"></span></p>
    <p class="c13">
        <span class="c0">For refund requests, all requests must be made through our support
            team. Each request will be evaluated on a case-by case basis, and we
            reserve the right to approve or deny any refund request based on the
            specifics of your situation.</span>
    </p>
    <p class="c13">
        <span class="c0">If you request a refund before we&rsquo;ve sent you the first design
            concepts, you&rsquo;re eligible for a full refund. However, once
            we&rsquo;ve delivered the initial designs, the refund structure changes
            depending on how much time has passed:</span>
    </p>
    <ul class="c8 lst-kix_juslxf7j1ovd-0 start">
        <li class="c12 li-bullet-0">
            <span class="c6 c7">Within 48 hours</span><span class="c0">: You can request a refund, and we&rsquo;ll return 66% of your
                payment, minus a 10% processing fee.</span>
        </li>
        <li class="c12 li-bullet-0">
            <span class="c6 c7">Within 48 to 96 hours</span><span class="c0">: You can still request a refund, but you&rsquo;ll be eligible for
                only 33% back, and the 10% processing fee will still apply.</span>
        </li>
        <li class="c12 li-bullet-0">
            <span class="c6 c7">After 96 hours</span><span class="c0">: At this point, we&rsquo;re unable to offer a refund, as we&rsquo;ll
                have put significant work into the designs.</span>
        </li>
    </ul>
    <p class="c13">
        <span class="c3">If the client goes unresponsive for </span><span class="c6 c7">5 working days</span><span class="c0">&nbsp;during the design process, we won&rsquo;t be able to issue a
            refund in such a scenario. If there&rsquo;s no communication for 7
            working days, the project may be paused, and there may be a fee to
            restart it, depending on the scope of the work</span>
    </p>
    <h2 class="c10" id="h.mbpa3hsktjow">
        <span class="c6">5. INTELLECTUAL PROPERTY AND COPYRIGHT</span>
    </h2>
    <h3 class="c2" id="h.gq3cp5mbmb6r">
        <span class="c16 c6">5.1 Ownership of Deliverables:</span>
    </h3>
    <p class="c4 c5"><span class="c1"></span></p>
    <p class="c4">
        <span class="c0">Upon full payment, the Client will own all final deliverables related
            to the website, including design files, code, and any other assets
            created specifically for the project. This gives the Client full control
            and ownership of the completed website.
        </span>
    </p>
    <p class="c4 c5"><span class="c0"></span></p>
    <p class="c4">
        <span class="c0">However, it&rsquo;s important to note that third-party software,
            plugins, or external resources used in the project (e.g., CMS platforms
            like WordPress or Shopify) remain the property of their respective
            owners and are licensed, not owned, by the Client.</span>
    </p>
    <h3 class="c2" id="h.x2zdbs801gk2">
        <span class="c16 c6">5.2 Retention of Rights by the Company:</span>
    </h3>
    <p class="c4 c5"><span class="c0"></span></p>
    <p class="c4">
        <span class="c0">Design Sketchers retains the right to showcase the Client&rsquo;s
            website as part of its portfolio. This helps us demonstrate our
            expertise and the high standard of our work to potential clients. If the
            Client wishes to withhold permission for their website to be included in
            our portfolio, they may do so in writing, and we will honor that
            request.</span>
    </p>
    <h3 class="c2" id="h.xm8x3hcgotxp">
        <span class="c16 c6">5.3 Third-Party Licenses:</span>
    </h3>
    <p class="c4 c5"><span class="c0"></span></p>
    <p class="c4">
        <span class="c0">Any third-party licenses required for plugins, themes, or software will
            be outlined in the proposal, and the cost of these licenses is the
            responsibility of the Client. The Client will own the rights to use
            these tools as specified by the license agreements but will not own the
            tools themselves.</span>
    </p>
    <h2 class="c10" id="h.r4vebinod87n">
        <span class="c6">6. ONGOING MAINTENANCE AND SUPPORT</span>
    </h2>
    <h3 class="c2" id="h.yurer1gymr7i">
        <span class="c16 c6">6.1 Post-Launch Support:</span>
    </h3>
    <p class="c4 c5"><span class="c0"></span></p>
    <p class="c4">
        <span class="c0">After the website launches, we understand that there might be minor
            issues or bugs that arise. For this reason, we offer 7 days of
            complimentary support to resolve any issues related to the design and
            development of the website. We will be available to fix any bugs or
            performance problems that may occur during this period.</span>
    </p>
    <h2 class="c10" id="h.ph3qr5qru9sh">
        <span class="c17 c6">7. CANCELLATION BY CLIENT </span>
    </h2>
    <p class="c11">
        <span class="c3">The Client must provide written notice of the cancellation to the
            Company.</span><span class="c6 c7">&nbsp;</span><span class="c3">Verbal cancellations will not be considered valid or enforceable.</span><span class="c3">&nbsp;</span><span class="c1">If the Client cancels the project, all work completed remains the
            property of the Company until full payment is made. However, once
            payment is received, ownership of the deliverables can be transferred
            under clients name.</span>
    </p>
    <p class="c11">
        <span class="c0">In the event of cancellation, the Client will be responsible for paying
            the Company for all work completed up to the date of cancellation. This
            includes any hours worked, services rendered, and any non-refundable
            expenses incurred by the Company in relation to the project. The payment
            due will be based on the percentage of work completed, as reasonably
            determined by the Company.</span>
    </p>
    <p class="c11">
        <span class="c0">Also note that the deposit client makes covers the Company&#39;s time
            spent in preparation and reserving the project timeline. Any initial
            deposits made by the Client are non-refundable, even if the project is
            canceled before significant work has commenced.
        </span>
    </p>
    <h2 class="c10" id="h.obordcqyq6dv">
        <span class="c17 c6">8. DISPUTE RESOLUTION</span>
    </h2>
    <p class="c4 c5"><span class="c0"></span></p>
    <p class="c11">
        <span class="c3">The parties agree to make every effort to resolve any disputes arising
            from or related to this Agreement through amicable and constructive
            negotiations. If a dispute arises, both the Company and the Client will
            engage in good faith discussions in an attempt to resolve the matter
            within </span><span class="c6 c7">30 days</span><span class="c0">&nbsp;from the initial notification of the dispute.</span>
    </p>
    <p class="c11">
        <span class="c0">If the parties are unable to reach a resolution within this timeframe,
            the dispute will be submitted to binding arbitration, as per the rules
            of the law of the court, or any other mutually agreed upon arbitration
            body.
        </span>
    </p>
    <h2 class="c14" id="h.kl0exzepxu2n">
        <span class="c6 c17">9. SIGNATURES</span>
    </h2>
    <p class="c11">
        <span class="c0">IN WITNESS WHEREOF, the client hereto have executed this Agreement as
            of the date first written above.</span>
    </p>
    <?php if(isset($pdf_data)): ?>
    <p class="c11">
        <span class="c0">Name:
            <span><?php echo e($pdf_data['name']); ?></span><br />
            Date: <?php echo e(\Carbon\Carbon::now()->toFormattedDateString()); ?>

        </span>
    </p>
    <p class="c11"><span class="co">Authorized Signature:</span><br /></p>
    <img src="<?php echo e($pdf_data['signature']); ?>" alt="" style="
            width: 200px;
            height: 100px;
            margin-left: 0px;
            margin-top: 0px;
            transform: rotate(0rad) translateZ(0px);
            -webkit-transform: rotate(0rad) translateZ(0px);">
    <?php endif; ?>





</body>

</html><?php /**PATH D:\xampp\htdocs\dtek_payment_terminal\resources\views/admin/agreement.blade.php ENDPATH**/ ?>