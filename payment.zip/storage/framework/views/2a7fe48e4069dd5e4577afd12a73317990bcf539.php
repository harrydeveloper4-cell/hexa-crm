
<?php $__env->startSection('title', 'Brands'); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb-title'); ?>
    <h3><?php echo e(__('Brand Edit')); ?></h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb-items'); ?>
    <li class="breadcrumb-item"><i class="icon-home mr-1"></i></li>
    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.brands.index')); ?>"><?php echo e(__('Brands')); ?></a></li>
    <li class="breadcrumb-item active"><?php echo e(__('Edit')); ?></li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12 mt-4">
            <a class = "btn btn-info float-right" href = "<?php echo e(route('admin.brands.index')); ?>">Back</a>
        </div>
        <div class="col-12 mt-4">
            <div class="card">
                
                <div class="card-content">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-12">
                                <form action = "<?php echo e(route('admin.brands.update', ['id' => $brand->id])); ?>" method = "POST"
                                    id = "package-form" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-row">
                                        <div class="form-group col-md-6">
                                            <label for="name">Name</label>
                                            <input type="text" class="form-control rounded" name = "name"
                                                id="name" placeholder="Name" value = "<?php echo e($brand->name ?? ''); ?>">
                                        </div>
                                    </div>
                                    
                                    <div class="form-row">
                                        <div class="form-group col-md-6">
                                            <label for="phonenumber">Contact Number</label>
                                            <input type="text" class="form-control rounded" name = "phonenumber"
                                                id="phonenumber" placeholder="Contact Number" value = "<?php echo e($brand->phonenumber ?? ''); ?>">
                                        </div>
                                    </div>
                                    
                                    <div class="form-row">
                                        <div class="form-group col-md-6">
                                            <label for="email_address">Email Address</label>
                                            <input type="email" class="form-control rounded" name = "email_address"
                                                id="email_address" placeholder="Email Address" value = "<?php echo e($brand->email_address ?? ''); ?>">
                                        </div>
                                    </div>
                                    
                                    
                                    <div class="form-row">
                                        <div class="form-group col-md-12">
                                            <label for="description">Description</label>
                                            <textarea class = "form-control" name = "description" id="description"><?php echo e($brand->desc ?? ''); ?></textarea>
                                        </div>
                                    </div>
                                    
                                    <div class="form-row">
                                        <div class="form-group col-md-4">
                                            <label for="currencies">Brand Currency</label>
                                            <?php
                                                $brand_currency = json_decode($brand->currency);
                                            ?>
                                            <select class="form-control select" name = "currencies[]" id="currencies"
                                                multiple>
                                                <option value = "">Select Currency</option>
                                                <?php $__currentLoopData = $currencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $currency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value = "<?php echo e($currency->code); ?>"
                                                        <?php echo e(in_array($currency->code, $brand_currency) ? 'selected' : ''); ?>>
                                                        <?php echo e($currency->country . ' (' . $currency->code . ')'); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="form-group col-md-4">
                                            <label for="url">Link</label>
                                            <input type="url" class="form-control rounded" name = "link"
                                                id="url" placeholder="Link" value = "<?php echo e($brand->link ?? ''); ?>">
                                        </div>
                                        <div class="form-group col-md-4">
                                            <label for="logo">Logo</label>
                                            <input type="file" class="form-control rounded" name = "logo" id="logo"
                                                value = "">
                                            <?php if($brand->logo != null): ?>
                                                <img src = "<?php echo e(asset($brand->logo)); ?>" class = "w-50">
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="form-row">
                                        <input type="submit" value = "Save" class = "btn btn-primary">
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function() {
            $('#package-form').validate({
                rules: {
                    name: 'required',
                    description: 'required',
                    logo: {
                        extension: "jpg|jpeg|png|bmp"
                    },
                    link: 'required',
                }
            })
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/allinflo/public_html/portal.allinflo.com/resources/views/admin/brands/edit.blade.php ENDPATH**/ ?>