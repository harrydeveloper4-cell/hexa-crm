<!-- START: Template JS-->
<script src="<?php echo e(asset('admin/dist/vendors/jquery/jquery-3.3.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/dist/vendors/jquery-ui/jquery-ui.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/dist/vendors/moment/moment.js')); ?>"></script>
<script src="<?php echo e(asset('admin/dist/vendors/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/dist/vendors/slimscroll/jquery.slimscroll.min.js')); ?>"></script>

<script src="<?php echo e(asset('admin/dist/vendors/select2/js/select2.full.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/dist/js/select2.script.js')); ?>"></script>


<script src="<?php echo e(asset('admin/dist/vendors/datatable/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/dist/vendors/datatable/js/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/dist/vendors/datatable/jszip/jszip.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/dist/vendors/datatable/pdfmake/pdfmake.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/dist/vendors/datatable/pdfmake/vfs_fonts.js')); ?>"></script>
<script src="<?php echo e(asset('admin/dist/vendors/datatable/buttons/js/dataTables.buttons.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/dist/vendors/datatable/buttons/js/buttons.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/dist/vendors/datatable/buttons/js/buttons.colVis.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/dist/vendors/datatable/buttons/js/buttons.flash.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/dist/vendors/datatable/buttons/js/buttons.html5.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/dist/vendors/datatable/buttons/js/buttons.print.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/dist/js/datatable.script.js')); ?>"></script>

<script src="<?php echo e(asset('admin/dist/vendors/bootstrap4-toggle/js/bootstrap4-toggle.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/dist/vendors/summernote/summernote-bs4.js')); ?>"></script>
<script src="<?php echo e(asset('admin/dist/js/summernote.script.js')); ?>"></script>
<script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js"></script>

<script src="<?php echo e(asset('admin/dist/vendors/chartjs/Chart.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/dist/vendors/apexcharts/apexcharts.min.js')); ?>"></script>
<?php echo $__env->yieldContent('scripts'); ?>
<!-- END: Template JS-->

<!-- START: APP JSS-->
<script src="<?php echo e(asset('admin/dist/js/app.js')); ?>"></script>
<script src="<?php echo e(asset('admin/dist/vendors/toastr/toastr.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/dist/js/toastr.script.js')); ?>"></script>
<script type="text/javascript">
    (function($) {
        "use strict";
        toastr.options = {
            "debug": false,
            "newestOnTop": false,
            "positionClass": "toast-top-right",
            "closeButton": true,
            "progressBar": true
        };

        // $('.homerDemo1').on('click', function (event) {
        //     toastr.info('Info - This is a custom info notification');
        // });
        // $('.homerDemo2').on('click', function (event) {
        //     toastr.success('Success - This is a success notification');
        // });
        // $('.homerDemo3').on('click', function (event) {
        //     toastr.warning('Warning - This is a warning notification');
        // });
        // $('.homerDemo4').on('click', function (event) {
        //     toastr.error('Error - This is a error notification');
        // });

    })(jQuery);
    $(document).ready(function() {
        <?php if(Session::has('success')): ?>
            toastr.success("<?php echo e(Session::get('success')); ?>");
        <?php endif; ?>
        <?php if(Session::has('error')): ?>
            toastr.error("<?php echo e(Session::get('error')); ?>");
        <?php endif; ?>
    })
</script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"
    integrity="sha512-AA1Bzp5Q0K1KanKKmvN/4d3IRKVlv9PYgwFPvm32nPO6QS8yH1HO7LbgB1pgiOxPtfeg5zEn2ba64MUcqJx6CA=="
    crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script>
    // for delete confirmation
    $(document).on('click', '.delete_confirmation', function(event) {
        event.preventDefault();
        var url = $(this).attr('href');

        swal({
            title: "<?php echo e(__('Are you sure?')); ?>",
            text: "<?php echo e(__('Once deleted, you will not be able to recover this!')); ?>",
            icon: "warning",
            buttons: true,
            dangerMode: true,
        }).then((willDelete) => {
            if (willDelete) {
                window.location.href = url;
            } else {
                swal("<?php echo e(__('Your data is safe!')); ?>", {
                    icon: "info",
                    timer: 2000,
                });
            }
        });
    });
</script>
<?php /**PATH D:\xampp\htdocs\dtek_payment_terminal\resources\views/admin/layout/scripts.blade.php ENDPATH**/ ?>