
<?php $__env->startSection('title', 'Orders'); ?>

<?php $__env->startSection('css'); ?>
    <style>
        #form img {
            width: 200px;
        }

        #form .error {
            color: red;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb-title'); ?>
    <h3><?php echo e(__('Order Create')); ?></h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb-items'); ?>
    <li class="breadcrumb-item"><i class="icon-home mr-1"></i></li>
    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.orders.index')); ?>"><?php echo e(__('Orders')); ?></a></li>
    <li class="breadcrumb-item active"><?php echo e(__('Create')); ?></li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12 mt-4">
            <a class = "btn btn-info float-right" href = "<?php echo e(route('admin.orders.index')); ?>">Back</a>
        </div>
        <div class="col-12 mt-4">
            <div class="card">
                
                <div class="card-content">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-12">
                                <form action="<?php echo e(route('order.submit')); ?>" method="post" id="form">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-row">
                                        <div class="form-group col-md-6">
                                            <label for="inputEmail4">Brand Name *</label>
                                            <select value="<?php echo e(old('brand_name')); ?>" class="form-control brand-select" name="brand_name">
                                                <option value="">Select Brand</option>
                                                <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($user->has_brand($brand->id) || $user->role_id == 1): ?>
                                                        <option value="<?php echo e($brand->id); ?>"
                                                            <?php echo e(old('brand_name') == $brand->id ? 'selected' : ''); ?>

                                                            data-img="<?php echo e(asset($brand->logo)); ?>">
                                                            <?php echo e($brand->name); ?>

                                                        </option>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <?php $__errorArgs = ['brand_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="form-group col-md-6 logo-section" style="display:none">
                                            <label for="inputPassword4">Brand Logo</label>
                                            <img src="" id="brand_logo" class="d-block">
                                        </div>
                                    </div>
                                    <div class="form-row">
                                        <div class="form-group col-md-4">
                                            <label for="inputEmail4">Payment Type</label>
                                            <select value="<?php echo e(old('payment_types')); ?>" class="form-control" name="payment_type"
                                                id="sale_status" onchange ="select_payment_type(this.value)">
                                                <option value="" selected="" disabled="">Please choose an option</option>
                                                <option value="1" <?php echo e(old('payment_type') == '1' ? 'selected' : ''); ?>>New Payment</option>
                                                <option value="2" <?php echo e(old('payment_type') == '2' ? 'selected' : ''); ?>>Up-Sale Payment
                                                </option>
                                            </select>
                                            <?php $__errorArgs = ['payment_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="form-group col-md-6" id="order_id_container" style="display:none">
                                            <label for="inputPassword4">Order ID *</label>
                                            <input type="text" name="order_id" id="order_id" class="form-control" style="display:none">
                                        </div>
                                        
                                        <div class="form-group col-md-4">
                                            <label for="inputEmail4">Amount *</label>
                                            <input type="number" value="<?php echo e(old('sale_amount')); ?>" class="form-control" name="sale_amount"
                                                id="sale_amount" min="1">
                                            <?php $__errorArgs = ['sale_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="form-group col-md-4">
                                            <label for="inputPassword4">Currency *</label>
                                            <select value="<?php echo e(old('sale_currency')); ?>" class="form-control currency" name="sale_currency">
                                            </select>
                                            <?php $__errorArgs = ['sale_currency'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>

                                    <div class="form-row d-none">
                                        <div class="form-group col-md-12">
                                            <label for="inputEmail4">Description *</label>
                                            <textarea name="description" class="form-control" cols="60" rows="3" id="editor">Custom Package</textarea>
                                        </div>
                                    </div>

                                    <div class="form-row merchants">
                                        <?php $__errorArgs = ['merchants'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="form-row packages border p-3 mb-3">
                                        <?php $__errorArgs = ['packages'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="form-row">
                                        <div class="form-group col-md-6">
                                            <label for="inputEmail4">Sales person email *</label>
                                            <input type="email" value="<?php echo e(old('sales_email')); ?>" class="form-control" name="sales_email"
                                                id="sales_email">
                                            <?php $__errorArgs = ['sales_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="form-group col-md-6">
                                            <label>Customer email *</label>
                                            <input type="email" value="<?php echo e(old('customer_email')); ?>" class="form-control"
                                                name="customer_email" id="customer_email">
                                            <?php $__errorArgs = ['customer_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="form-group col-md-4 d-none">
                                            <label>Link Expiry Date *</label>
                                            <input type="date" value="<?php echo e(old('expiry_date')); ?>" class="form-control" name="expiry_date"
                                                id="expiry_date" min="<?php echo date('Y-m-d'); ?>">
                                            <?php $__errorArgs = ['expiry_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>

                                    <div class="form-row">
                                        <div class="form-group col-md-12">
                                            <button type="submit" class="btn btn-primary">Submit</button>
                                        </div>
                                    </div>

                                    <!-- Form End -->
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function() {
            // $(document).on('change', '.brand-select', function() {
            //     let logo_path = $(this).find(':selected').attr('data-img');
            //     let brand_id = $(this).val();
            //     if (logo_path != '' && logo_path != undefined) {
            //         $('#brand_logo').attr('src', logo_path);
            //         $('.logo-section').show();
            //     } else {
            //         $('#brand_logo').attr('src', '');
            //         $('.logo-section').hide();
            //     }
            //     if (brand_id != '') {
            //         console.log("Inside the if condition");
            //         $.ajax({
            //             url: "<?php echo e(route('brand.merchant.packages')); ?>",
            //             type: "POST",
            //             data: {
            //                 '_token': "<?php echo e(csrf_token()); ?>",
            //                 brand_id: brand_id
            //             },
            //             success: function(res) {
            //                 $('.merchants').html(res.merchants)
            //                 $('.packages').html(res.packages)
            //                 $('.currency').html(res.currency)
            //             },
            //             error: function(err) {}
            //         })

            //     } else {
            //         $('.merchants').html('')
            //         $('.packages').html('')
            //         $('.currency').html('')
            //     }
            // });
        });

        $(document).ready(function() {
            function fetchBrandDetails(brand_id) {
                let logo_path = $('.brand-select').find(':selected').attr('data-img');
                if (logo_path != '' && logo_path != undefined) {
                    $('#brand_logo').attr('src', logo_path);
                    $('.logo-section').show();
                } else {
                    $('#brand_logo').attr('src', '');
                    $('.logo-section').hide();
                }
                if (brand_id != '') {
                    $.ajax({
                        url: "<?php echo e(route('brand.merchant.packages')); ?>",
                        type: "POST",
                        data: {
                            '_token': "<?php echo e(csrf_token()); ?>",
                            brand_id: brand_id
                        },
                        success: function(res) {
                            $('.merchants').html(res.merchants);
                            $('.packages').html(res.packages);
                            $('.currency').html(res.currency);
                        },
                        error: function(err) {
                            console.log(err);
                            
                            // if(err.status === 422){
                            //     let errors = err.response
                            // }
                        }
                    });
                } else {
                    $('.merchants').html('');
                    $('.packages').html('');
                    $('.currency').html('');
                }
            }

            $(document).on('change', '.brand-select', function() {
                let brand_id = $(this).val();
                fetchBrandDetails(brand_id);
            });

            if ($('.brand-select').val() != '') {
                fetchBrandDetails($('.brand-select').val());
            }
        });

        $(document).ready(function() {
            $('#editor').summernote();
        });

        $('#form').submit(function() {

            // // Get the Login Name value and trim it
            var editor = $.trim($('#editor').val());
            console.log(editor);

            // Check if empty of not
            if (editor === '') {
                // alert('description field is empty.');
                return false;
            }
        });


        $(document).ready(function() {
            $('#form').validate({
                rules: {
                    brand_name: {
                        required: true
                    },
                    payment_type: {
                        required: true
                    },
                    sales_email: {
                        required: true,
                        email: true
                    },
                    customer_email: {
                        required: true,
                        email: true
                    },
                    expiry_date: {
                        required: true,
                        date: true
                    },
                    sale_amount: {
                        required: true,
                        number: true,
                        min: 1
                    },
                    sale_currency: {
                        required: true,
                    },
                    payment_gateway: {
                        required: true,
                    },
                    'packages[]' :{
                        required: true
                    }
                },
                messages: {
                    brand_name: {
                        required: "Please select a brand."
                    },
                    payment_type: {
                        required: "Please select the payment type"
                    },
                    sales_email: {
                        required: "Salesperson email is required.",
                        email: "Please enter a valid email address."
                    },
                    customer_email: {
                        required: "Customer email is required.",
                        email: "Please enter a valid email address."
                    },
                    expiry_date: {
                        required: "Link expiry date is required.",
                        date: "Please enter a valid date."
                    },
                    sale_amount: {
                        required: "Amount is required.",
                        number: "Please enter a valid number.",
                        min: "Amount must be greater than zero."
                    },
                    sale_currency: {
                        required: "Currency is required"
                    },
                    payment_gateway: {
                        required: "Please select the payment type"
                    },
                    'packages[]' :{
                        required: "You must check at least 1 box"
                    }
                },
                errorPlacement: function(error, element) {
                    if (element.is('select')) {
                        error.appendTo(element.parents('.form-group'));
                    }
                    if(element.is(":radio")){
                        error.appendTo(element.parents('.merchants')); 
                    }
                    else {
                        error.addClass('text-danger');
                        error.append('<span class="required text-danger">*</span>');
                        error.insertAfter(element);
                    }
                },
                success: function(label, element) {
                    if ($(element).is('select')) {
                        label.remove();
                    }
                }
            });
            $('select[name="brand_name"]').on('change', function() {
                var $this = $(this);
                if ($this.val() !== "") {
                    $this.parents('.form-group').find('label.error').remove();
                }
            });
            $('select[name="payment_type"]').on('change', function() {
                var $this = $(this);
                if ($this.val() !== "") {
                    $this.parents('.form-group').find('label.error').remove();
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/webdzkym/public_html/all-in-flo/payment/resources/views/admin/orders/create_order.blade.php ENDPATH**/ ?>