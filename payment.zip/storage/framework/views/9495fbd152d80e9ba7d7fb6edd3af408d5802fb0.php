
<?php $__env->startSection('title', 'Brands'); ?>

<?php $__env->startSection('css'); ?>
<style>
    #package-form .error{
        color: red;
    }

</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb-title'); ?>
    <h3><?php echo e(__('Brand Create')); ?></h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb-items'); ?>
    <li class="breadcrumb-item"><i class="icon-home mr-1"></i></li>
    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.brands.index')); ?>"><?php echo e(__('Brands')); ?></a></li>
    <li class="breadcrumb-item active"><?php echo e(__('Create')); ?></li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12 mt-4">
            <a class = "btn btn-info float-right" href = "<?php echo e(route('admin.brands.index')); ?>">Back</a>
        </div>
        <div class="col-12 mt-4">
            <div class="card">
                
                <div class="card-content">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-12">
                                <form action = "<?php echo e(route('admin.brands.store')); ?>" method = "POST" id = "package-form"
                                    enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-row">
                                        <div class="form-group col-md-4">
                                            <label for="inputEmail4">Name</label>
                                            <input type="text" class="form-control rounded" name = "name"
                                                id="inputEmail4" placeholder="Name" value = "<?php echo e(old('name')); ?>">
                                                
                                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback error" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    
                                    <div class="form-row">
                                        <div class="form-group col-md-4">
                                            <label for="phonenumber">Contact Number</label>
                                            <input type="text" class="form-control rounded" name = "phonenumber"
                                                id="phonenumber" placeholder="Contact Number" value = "<?php echo e(old('phonenumber')); ?>">
                                                
                                            <?php $__errorArgs = ['phonenumber'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback error" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    
                                    <div class="form-row">
                                        <div class="form-group col-md-4">
                                            <label for="email_address">Email Address</label>
                                            <input type="email" class="form-control rounded" name = "email_address"
                                                id="email_address" placeholder="Email Address" value = "<?php echo e(old('email_address')); ?>">
                                                
                                            <?php $__errorArgs = ['email_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback error" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    
                                    
                                    <div class="form-row">
                                        <div class="form-group col-md-12">
                                            <label for="inputEmail4">Description</label>
                                            <textarea class = "form-control" name = "description" id="description"><?php echo e(old('description')); ?></textarea>
                                            <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback error" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    
                                    <div class="form-row">
                                        <div class="form-group col-md-4">
                                            <label for="inputEmail4">Brand Currency</label>
                                            <select class="form-control select2" name = "currencies[]" id="inputEmail4"
                                                multiple>
                                                
                                                <?php $__currentLoopData = $currencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $currency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value = "<?php echo e($currency->code); ?>"
                                                        <?php echo e(is_array(old('currencies')) && in_array($currency->code, old('currencies')) ? 'selected' : ''); ?>   
                                                    >
                                                        <?php echo e($currency->country . ' (' . $currency->code . ')'); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <?php $__errorArgs = ['currencies'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback error" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="form-group col-md-4">
                                            <label for="link">Link</label>
                                            <input type="url" class="form-control rounded" name = "link"
                                                id="link" placeholder="Link" value ="<?php echo e(old('link')); ?>">
                                            <?php $__errorArgs = ['link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback error" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                            <div class="form-group col-md-4">
                                                <label for="logo">Logo</label>
                                                <input type="file" class="form-control rounded " name = "logo" id="logo">
                                                <?php $__errorArgs = ['logo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback error" role="alert">
                                                        <strong><?php echo e($message); ?></strong>
                                                    </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                    <div class="form-row">
                                        <input type="submit" value = "Save" class = "btn btn-primary">
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function() {
            // Initialize Select2 for multiple selects
            $('.select2').select2({
                theme: 'bootstrap4'  // AdminLTE's Bootstrap4 theme for Select2
            });
        });
        $(document).ready(function() {
            $('#package-form').validate({
                rules: {
                    name: 'required',
                    description: 'required',
                    currencies: 'required',
                    link: {
                        required: true,
                    },
                    logo: {
                        required: true,
                        extension: "jpg|jpeg|png|bmp"
                    },
                    // merchants: 'required'
                },
                errorPlacement : function(error, element){
                    if(element.is('select')){
                        error.appendTo(element.parents('.form-group'));
                    }
                    error.insertAfter(element);
                    if (!element.next('span.required').length) {
                        $('<span class="required text-danger">*</span>').insertBefore(element);
                    }
                },
                success: function(label, element) {
                    $(element).find("span.required").remove();
                }
            });
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/allinflo/public_html/portal.allinflo.com/resources/views/admin/brands/create.blade.php ENDPATH**/ ?>