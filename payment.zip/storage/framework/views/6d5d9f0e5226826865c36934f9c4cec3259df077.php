<div class="col-md-12">
    <h4>
        Select Package
    </h4>
</div>
<?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-md-4">
        <input type="checkbox" id="pack<?php echo e($package->id); ?>" name="packages[]" value="<?php echo e($package->id); ?>">
        <label for="pack<?php echo e($package->id); ?>"><?php echo e($package->package_name); ?></label>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH /home/u498385541/domains/markvaulting.org/public_html/portal/resources/views/ajax/packages.blade.php ENDPATH**/ ?>