
<?php $__env->startSection('title', 'Users'); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb-title'); ?>
    <h3><?php echo e(__('Users')); ?></h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb-items'); ?>
    <li class="breadcrumb-item active"><?php echo e(__('Users')); ?></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12 mt-3">
            <div class="card">
                <div class="card-header  justify-content-between align-items-center">
                    <h4 class="card-title">Users</h4>
                    <a class = "btn btn-info float-right" href = "<?php echo e(route('users.create')); ?>"><i
                            class = "icon-plus"></i> Create</a>
                    

                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table id="example" class="display table dataTable table-striped table-bordered">
                            <thead>
                                <tr>
                                    <th>ID#</th>
                                    <th>First Name</th>
                                    <th>Last Name</th>
                                    <th>Email</th>
                                    <th>Phone Number</th>
                                    <th>Address</th>
                                    <th>City</th>
                                    <th>State</th>
                                    <th>Zip Code</th>
                                    <th>User Role</th>
                                    <th>Country</th>
                                    <th>Action</th>
                                    <th>Orders</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <?php echo e($user->id); ?>

                                        </td>
                                        <td><?php echo e($user->firstname); ?></td>
                                        <td><?php echo e($user->lastname); ?></td>
                                        <td><?php echo e($user->email); ?></td>
                                        <td><?php echo e($user->billing_phonenumber); ?></td>
                                        <td><?php echo e($user->billing_address); ?></td>
                                        <td><?php echo e($user->city); ?></td>
                                        <td><?php echo e($user->state); ?></td>
                                        <td><?php echo e($user->postalcode); ?></td>
                                        <td><?php echo e($user->role_id == '1' ? 'Agent' : 'Client'); ?></td>
                                        <td><?php echo e($user->country); ?></td>
                                        <td>
                                            <a 
                                                href="<?php echo e(route('users.edit', ['id' => $user->id])); ?>"
                                            >
                                                <i class="icon-pencil"></i>
                                            </a>
                                            <a 
                                              class = "delete_confirmation"
                                              href="<?php echo e(route('users.destroy', ['id' => $user->id])); ?>"
                                            >
                                                <i class="icon-trash"></i>
                                            </a>
                                        </td>
                                        <td>
                                            <a href="<?php echo e(route('admin.customer.orders', ['email' => $user->email])); ?>" class="btn btn-info">
                                                Orders
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>

                            <tfoot>
                                <th>ID#</th>
                                <th>First Name</th>
                                <th>Last Name</th>
                                <th>Email</th>
                                <th>Phone Number</th>
                                <th>Address</th>
                                <th>City</th>
                                <th>State</th>
                                <th>Zip Code</th>
                                <th>User Role</th>
                                <th>Country</th>
                                <th>Action</th>
                                <th>Orders</th>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function() {

            $(".check-all").click(function() {
                $("input[type=checkbox]").prop("checked", $(this).prop("checked"));
            });

            $("input[type=checkbox]").click(function() {
                if (!$(this).prop("checked")) {
                    $(".check-all").prop("checked", false);
                }
            });

            $(document).on('change', '#update-status', function() {

                if ($(this).val() != '') {
                    let status = $(this).val();
                    var ids = [];
                    $.each($(".check:checked"), function() {
                        ids.push($(this).val());
                    });

                    if (ids.length > 0) {
                        let bool = confirm(
                            'Are you sure you want to update status of selected inquiries as ' + status)
                        if (bool) {
                            $.ajax({
                                url: "",
                                type: "POST",
                                data: {
                                    status: status,
                                    ids: ids,
                                    '_token': "<?php echo e(csrf_token()); ?>"
                                },
                                success: function(data) {
                                    $("input[type=checkbox]").prop("checked", false)
                                    window.location.reload()

                                },
                                error: function(error) {
                                    alert('Inquiries updating failed')
                                }
                            })
                        }
                    }
                } else {
                    alert('Please select atleast one inquiry')
                }
            })

            $(document).on('click', '.inquiry-detail', function() {
                var id = $(this).data('id')

                $.ajax({
                    url: route,
                    type: 'GET',
                    data: {
                        id: id
                    },
                    success: function(data) {
                        alert(work)
                    }
                })
            })

            $(document).on('click', '.destroy', function(e) {

                e.preventDefault();

                let url = $(this).attr('href');

                let bool = confirm('Are you sure you want to delete this User');
                if (bool) {
                    window.location.href = url;
                }
            })
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/webdzkym/public_html/all-in-flo/payment/resources/views/admin/users/index.blade.php ENDPATH**/ ?>