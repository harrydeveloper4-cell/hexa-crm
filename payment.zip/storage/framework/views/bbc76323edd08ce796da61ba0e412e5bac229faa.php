<link rel="shortcut icon" href="<?php echo e(asset('admin/dist/images/favicon.ico')); ?>" />
<meta name="viewport" content="width=device-width,initial-scale=1">
<?php /**PATH D:\xampp\htdocs\dtek_payment_terminal\resources\views/admin/layout/meta.blade.php ENDPATH**/ ?>