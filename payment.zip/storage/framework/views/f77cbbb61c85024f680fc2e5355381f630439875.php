
<?php $__env->startSection('title', 'Orders'); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb-title'); ?>
    <h3> Order# <?php echo e($order->order_number); ?></h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb-items'); ?>
    <li class="breadcrumb-item"><i class="icon-home mr-1"></i></li>
    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.orders.index')); ?>"><?php echo e(__('Orders')); ?></a></li>
    <li class="breadcrumb-item active"> Order# <?php echo e($order->order_number); ?></li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-6 mt-3">
            <div class="row">
                <div class="col-12 mt-3">
                    <div class="card">
                        <div class="card-header  justify-content-between align-items-center">
                            <h4 class="card-title">Details</h4>
                        </div>
                        <div class="card-body">
                            <dl class="row mb-0 redial-line-height-2_5">
                                <dt class="col-sm-5">Order Number:</dt>
                                <dd class="col-sm-7">#<?php echo e($order->order_number); ?></dd>

                                <dt class="col-sm-5">Placed On:</dt>
                                <dd class="col-sm-7"><?php echo e(date('d/m/Y H:i', strtotime($order->created_at))); ?></dd>

                                <dt class="col-sm-5">Brand Name:`   
                                <dd class="col-sm-7"><?php echo e($order->brand_details->name); ?></dd>

                                <dt class="col-sm-5">Sales Person</dt>
                                <dd class="col-sm-7"><?php echo e($order->sales_email); ?></dd>

                                <dt class="col-sm-5">Customer</dt>
                                <dd class="col-sm-7"><?php echo e($order->customer_email); ?></dd>

                                <dt class="col-sm-5">Sales Amount:</dt>
                                <dd class="col-sm-7"><?php echo e($order->sale_amount . ' ' . $order->sale_currency); ?></dd>

                                <dt class="col-sm-5">Paid Amount:</dt>
                                <dd class="col-sm-7">
                                    <?php echo e($order->order_payment_transactions()->sum('paid_amount') . ' ' . $order->sale_currency); ?></dd>

                                <dt class="col-sm-5">Order Status:</dt>
                                <dd class="col-sm-7">
                                    <?php if($order->status == 'pending'): ?>
                                        <span class = "badge badge-warning">Pending</span>
                                    <?php elseif($order->status == 'processing'): ?>
                                        <span class = "badge badge-info">Processing</span>
                                    <?php elseif($order->status == 'completed'): ?>
                                        <span class = "badge badge-primary">Completed</span>
                                    <?php elseif($order->status == 'discarded'): ?>
                                        <span class = "badge badge-secondary">Discarded</span>
                                    <?php elseif($order->status == 'refunded'): ?>
                                        <span class = "badge badge-primary">Refunded</span>
                                    <?php endif; ?>
                                </dd>

                                <dt class="col-sm-5">Payment Link:</dt>
                                <dd class="col-sm-7">
                                    <?php if(isset($order->payment_status) && $order->payment_status == 'unpaid'): ?>
                                        <?php if(isset($order->payment_link) && $order->payment_link != null): ?>
                                            <?php if(\Carbon\Carbon::parse($order->expires_at)->toDateString() < now()->toDateString()): ?>
                                                <span href="javascript:void(0)" class="badge badge-danger"
                                                    style="color: #fff;">
                                                    Link Expired
                                                </span>
                                            <?php else: ?>
                                                <?php
                                                    $now = \Carbon\Carbon::now();
                                                    $expiresAt = \Carbon\Carbon::parse($order->expires_at);
                                                    $diffInMinutes = $expiresAt->diffInMinutes($now);
                                                    $hours = intdiv($diffInMinutes, 60);
                                                    $minutes = $diffInMinutes % 60;
                                                ?>
                                                <a href="javascript:void(0)"
                                                    class="copyLink me-2 badge badge-warning" data-toggle="tooltip"
                                                    data-placement="top" title=""
                                                    data-original-title="Expires in <?php echo e($hours); ?> hour(s) and <?php echo e($minutes); ?> minute(s)"
                                                    style="color: #fff;" data-platform_name="link copy"
                                                    data-payment_link="<?php echo e($order->payment_link); ?>">
                                                    Copy link <i class="icon-docs"></i>
                                                </a>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <span class="badge badge-danger">Payment link unavailable</span>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <span class="badge badge-success">Paid</span>
                                    <?php endif; ?>
                                </dd>
                            </dl>
                        </div>
                    </div>
                </div>
                <?php
                    $billing = $order->order_payment_transactions()->latest()->first();
                ?>
                <div class="col-12 mt-3">
                    <div class="card">
                        <div class="card-header  justify-content-between align-items-center">
                            <h4 class="card-title">Billing Address</h4>
                        </div>
                        <div class="card-body">
                            <dl class="row mb-0 redial-line-height-2_5">
                                <dt class="col-sm-5">First Name:</dt>
                                <dd class="col-sm-7"><?php echo e($billing->firstname ?? '-'); ?></dd>
        
                                <dt class="col-sm-5">Last Name:</dt>
                                <dd class="col-sm-7"><?php echo e($billing->lastname ?? '-'); ?></dd>
        
                                <dt class="col-sm-5">Email:</dt>
                                <dd class="col-sm-7"><?php echo e($billing->email ?? '-'); ?></dd>
        
                                <dt class="col-sm-5">Address:</dt>
                                <dd class="col-sm-7"><?php echo e($billing->billing_address ?? '-'); ?></dd>
        
                                <dt class="col-sm-5">City:</dt>
                                <dd class="col-sm-7"><?php echo e($billing->city ?? '-'); ?></dd>
        
                                <dt class="col-sm-5">State</dt>
                                <dd class="col-sm-7"><?php echo e($billing->state ?? '-'); ?></dd>
        
                                <dt class="col-sm-5">ZIP/Post Code</dt>
                                <dd class="col-sm-7"><?php echo e($billing->postalcode ?? '-'); ?></dd>
        
                                <dt class="col-sm-5">Country:</dt>
                                <dd class="col-sm-7"><?php echo e($billing->getCountry->name ?? '-'); ?></dd>
        
                                <dt class="col-sm-5">Phone Number:</dt>
                                <dd class="col-sm-7"><?php echo e($billing->billing_phonenumber ?? '-'); ?></dd>
                            </dl>
                        </div>
                    </div>
        
        
                </div>
            </div>
        </div>
        <div class="col-6 mt-3">
            <div class="row">
                <div class="col-12 mt-3">
                    <div class="card">
                        <div class="card-header  justify-content-between align-items-center">
                            <h4 class="card-title">Order Packages</h4>
                        </div>
                        <div class="card-body">
                            <dl class="row mb-0 redial-line-height-2_5">
                                <dt class="col-sm-5">Package ID </dt>
                                <dt class="col-sm-7">Package Name</dt>
                                <?php $__currentLoopData = $order->packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <dd class="col-sm-5"><?php echo e($package->id); ?> </dd>
                                    <dd class="col-sm-7"><?php echo e($package->package_name); ?></dd>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </dl>
                        </div>
                    </div>
                </div>
                <div class="col-12 mt-3">
                    <div class="card">
                        <div class="card-header  justify-content-between align-items-center">
                            <h4 class="card-title">Payment Details</h4>
                        </div>
                        <div class="card-body">
                            <dl class="row mb-0 redial-line-height-2_5">
        
                                <dt class="col-sm-5">Payment Method:</dt>
                                <dd class="col-sm-7"><?php echo e($order->payment_gateway); ?></dd>
        
                                <dt class="col-sm-5">Payment Transaction ID:</dt>
                                <dd class="col-sm-7">
                                    <?php echo e(!is_null($order->order_payment_transactions->first()) ? $order->order_payment_transactions->first()->payment_id : '-'); ?>

                                </dd>
        
                                <dt class="col-sm-5">Payer ID:</dt>
                                <dd class="col-sm-7">
                                    <?php echo e(!is_null($order->order_payment_transactions->first()) ? $order->order_payment_transactions->first()->payer_id : '-'); ?>

                                </dd>
        
                                <dt class="col-sm-5">Transaction Date:</dt>
                                <dd class="col-sm-7">
                                    <?php echo e(!is_null($order->order_payment_transactions->first()) ? date('d/m/Y H:i', strtotime($order->order_payment_transactions->first()->created_at)) : '-'); ?>

                                </dd>
        
                                <?php if(!is_null($order->order_payment_transactions->first()) && !is_null($order->card_details)): ?>
                                    <dd class="col-sm-12 text-center">
                                        <button class="btn btn-primary view-card" data-view="0">View Card Detail</button>
                                    </dd>
                                <?php endif; ?>
        
                                <dl class="row mb-0 ml-1 redial-line-height-2_5 hide-card">
        
        
                                    <?php if(!is_null($order->order_payment_transactions->first()) && !is_null($order->card_details)): ?>
                                        <dt class="col-sm-5">Merchant:</dt>
                                        <dd class="col-sm-7">
                                            <?php echo e(isset($order->card_details->merchant) ? ucwords($order->card_details->merchant) : 'Not Define'); ?>

                                        </dd>
        
                                        <dt class="col-sm-5">Name on Card:</dt>
                                        <dd class="col-sm-7"><?php echo e($order->card_details->owner); ?></dd>
        
                                        <dt class="col-sm-5">Card Number:</dt>
                                        <dd class="col-sm-7"><?php echo e($order->card_details->cardNumber); ?></dd>
        
                                        <dt class="col-sm-5">CVV Number:</dt>
                                        <dd class="col-sm-7"><?php echo e($order->card_details->cvv); ?></dd>
        
                                        <dt class="col-sm-5">Expiry MM / YY:</dt>
                                        <dd class="col-sm-7"><?php echo e($order->card_details->expiration_month); ?> /
                                            <?php echo e($order->card_details->expiration_year); ?></dd>
                                    <?php endif; ?>
                                </dl>
                            </dl>
                        </div>
                    </div>
                </div>
                <div class="col-12 mt-3">
                    <div class="card">
                        <div class="card-header  justify-content-between align-items-center">
                            <h4 class="card-title">Documents</h4>
                        </div>
                        <div class="card-body">
                            <dl class="row mb-0 redial-line-height-2_5">
                                <dt class="col-sm-5">PDF </dt>
                                <?php if(isset($order->pdf_agreement)): ?>
                                    <a class="btn btn-success" href = "<?php echo e(asset($order->pdf_agreement)); ?>" download="">Download</a>
                                <?php else: ?>
                                    <dd class="col-sm-7"><?php echo e($billing->city ?? '-'); ?></dd>
                                <?php endif; ?>
                            </dl>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function() {
            $(".hide-card").hide()
        })

        $(".view-card").click(function() {
            if ($(this).data("view") == "0") {
                $(this).text("Hide Card Detail")
                $(this).data("view", "1")
                $(".hide-card").show()
            } else {
                $(this).text("View Card Detail")
                $(this).data("view", "0")
                $(".hide-card").hide()
            }
        })
        
        $(document).on('click', '.copyLink', function() {
            navigator.clipboard.writeText($(this).data('payment_link')).then(() => {
                toastr.success('Copied to clipboard!');
            }).catch(() => {
                toastr.error('Failed to copy to clipboard');
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\payment\resources\views/admin/orders/show.blade.php ENDPATH**/ ?>