<!-- START: Template CSS-->
<link rel="stylesheet" href="<?php echo e(asset('admin/dist/vendors/bootstrap/css/bootstrap.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('admin/dist/vendors/jquery-ui/jquery-ui.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('admin/dist/vendors/jquery-ui/jquery-ui.theme.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('admin/dist/vendors/simple-line-icons/css/simple-line-icons.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('admin/dist/vendors/flags-icon/css/flag-icon.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('admin/dist/vendors/toastr/toastr.min.css')); ?>">

<link rel="stylesheet" href="<?php echo e(asset('admin/dist/vendors/datatable/css/dataTables.bootstrap4.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('admin/dist/vendors/datatable/buttons/css/buttons.bootstrap4.min.css')); ?>">

<link rel="stylesheet" href="<?php echo e(asset('admin/dist/vendors/sweetalert/sweetalert.css')); ?>">

<link rel="stylesheet" href="<?php echo e(asset('admin/dist/vendors/select2/css/select2.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('admin/dist/vendors/select2/css/select2-bootstrap.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('admin/dist/vendors/bootstrap4-toggle/css/bootstrap4-toggle.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('admin/dist/vendors/summernote/summernote-bs4.css')); ?>">
<?php echo $__env->yieldContent('css'); ?>

<!-- END Template CSS-->

<!-- START: Custom CSS-->
<link rel="stylesheet" href="<?php echo e(asset('admin/dist/css/main.css')); ?>">
<!-- END: Custom CSS--><?php /**PATH /home/allinflo/public_html/portal.allinflo.com/resources/views/admin/layout/css.blade.php ENDPATH**/ ?>