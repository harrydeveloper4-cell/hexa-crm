<!-- START: Footer-->
    <footer class="site-footer">
        <?php echo e(date('Y')); ?> © <?php echo e(env('APP_NAME')); ?>

    </footer>
<!-- END: Footer-->
<?php /**PATH /home/u498385541/domains/markvaulting.org/public_html/portal/resources/views/admin/layout/footer.blade.php ENDPATH**/ ?>