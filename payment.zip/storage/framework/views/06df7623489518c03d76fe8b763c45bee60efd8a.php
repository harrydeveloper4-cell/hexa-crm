<!-- START: Footer-->
    <footer class="site-footer">
        <?php echo e(date('Y')); ?> © <?php echo e(env('APP_NAME')); ?>

    </footer>
<!-- END: Footer-->
<?php /**PATH D:\xampp\htdocs\square_terminal\resources\views/admin/layout/footer.blade.php ENDPATH**/ ?>