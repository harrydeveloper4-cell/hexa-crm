
<?php $__env->startSection('title', 'Users'); ?>

<?php $__env->startSection('css'); ?>
<style>
    #create_user .error{
        color: red;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb-title'); ?>
    <h3><?php echo e(__('Create')); ?></h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb-items'); ?>
    <li class="breadcrumb-item"><a href="<?php echo e(route('users')); ?>"><?php echo e(__('Users')); ?></a></li>
    <li class="breadcrumb-item active"><?php echo e(__('Create')); ?></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12 mt-4">
            <div class="card">
                <div class="card-header">
                    <h6 class="card-title">User Create</h6>
                    <a class = "btn btn-info float-right" href = "<?php echo e(route('users')); ?>">Back</a>
                </div>
                <div class="card-content">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-12">
                                <form action = "<?php echo e(route('users.store')); ?>" method = "POST" id = "create_user">
                                    <?php echo csrf_field(); ?>
                                    <div class="row">
                                        <div class="col-md-12 col-lg-12 col-xl-12">
                                            <label>User Type</label>
                                            <select class="form-control rounded" id = "role_id" name = "role_id">
                                                <option value = "">Select User Type</option>
                                                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value = "<?php echo e($role->id); ?>"><?php echo e($role->role); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="col-md-6 col-lg-6 col-xl-6">
                                            <label>First Name</label>
                                            <input class="form-control rounded" type="text" name="firstname"
                                                value="<?php echo e(old('firstname')); ?>" placeholder="Thomas D">
                                            <?php $__errorArgs = ['firstname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class = "error"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="col-md-6 col-lg-6 col-xl-6">
                                            <label>Last Name</label>
                                            <input class="form-control rounded" type="text" name="lastname"
                                                value="<?php echo e(old('lastname')); ?>" placeholder="Hardison">
                                            <?php $__errorArgs = ['lastname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class = "error"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="col-md-6 col-lg-6 col-xl-6">
                                            <label>Email</label>
                                            <input class="form-control rounded" type="email" name="email"
                                                value="<?php echo e(old('email')); ?>" placeholder="thomasdhardison@lorem.com">
                                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class = "error"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="col-md-6 col-lg-6 col-xl-6">
                                            <label>Contact Number</label>
                                            <input class="form-control rounded" type="number" name="billing_phonenumber"
                                                value="<?php echo e(old('billing_phonenumber')); ?>" placeholder="123-656-789 (0)">
                                            <?php $__errorArgs = ['billing_phonenumber'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class = "error"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="col-md-12 col-lg-12 col-xl-12">
                                            <label>Address</label>
                                            <input class="form-control rounded" type="text" name="billing_address"
                                                value="<?php echo e(old('billing_address')); ?>" placeholder="12345 Lane Street">
                                            <?php $__errorArgs = ['billing_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class = "error"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="col-md-12 col-lg-6 col-xl-6">
                                            <label>Country</label>
                                            <select id="country" name="country" class="form-control rounded">
                                                <?php $__currentLoopData = get_countries(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($country); ?>"><?php echo e($country); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class = "error"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="col-md-6 col-lg-6 col-xl-6">
                                            <label>State</label>
                                            <input class="form-control rounded" type="text" name="state"
                                                value="<?php echo e(old('state')); ?>" placeholder="State">
                                            <?php $__errorArgs = ['state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class = "error"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="col-md-6 col-lg-6 col-xl-6">
                                            <label>City</label>
                                            <input class="form-control rounded" type="text" name="city"
                                                value="<?php echo e(old('city')); ?>" placeholder="City">
                                            <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class = "error"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="col-md-6 col-lg-6 col-xl-6">
                                            <label>Zip Code</label>
                                            <input class="form-control rounded" type="text" name="postalcode"
                                                value="<?php echo e(old('postalcode')); ?>" placeholder="12345678">
                                            <?php $__errorArgs = ['postalcode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class = "error"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <span id = "card-details"></span>
                                    <span id = "user_permission">
                                        <?php if($permissions): ?>
                                            <div class = "row">
                                                <div class="col-md-12 col-lg-12 col-xl-12">
                                                    <label for="permissions_id">User Permissions</label>
                                                    <select id="permissions_id" multiple name="permissions_id[]"
                                                        class="form-control rounded">
                                                        <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($permission->id); ?>">
                                                                <?php echo e($permission->name); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                    <?php $__errorArgs = [''];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                            <hr>
                                        <?php endif; ?>
                                    </span>
                                    <span id = "user_brand">
                                        <?php if($brands): ?>
                                            <div class = "row">
                                                <div class="col-md-12 col-lg-12 col-xl-12">
                                                    <label for="brand_id">User Brands</label>
                                                    <select id="brand_id" multiple name="brand_id[]"
                                                        class="form-control rounded">
                                                        <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($brand->id); ?>">
                                                                <?php echo e($brand->name); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                            </div>
                                            <hr>
                                        <?php endif; ?>
                                    </span>
                                    <div class = "row">
                                        <div class="col-md-12 col-lg-12 col-xl-12">
                                            <button class = "btn btn-primary" type="submit">
                                                Save
                                            </button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php
        $fields = view('admin.users.card-details')->render();
    ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js"></script>
    <script>
        $(document).ready(function() {
            $("#user_permission").hide()
            $("#user_brand").hide()
        })

        let fields = <?php echo json_encode($fields); ?>;
        $(document).ready(function(){
            $('#create_user').validate({
                rules: {
                    role_id: 'required',
                    firstname: 'required',
                    lastname: 'required',
                    email: 'required',
                    billing_phonenumber: 'required',
                    billing_address: 'required',
                    state: 'required',
                    city: 'required',
                    postalcode: 'required',
                    country: 'required',
                },
                messages:{
                    firstname : {
                        required: "This Feild is Required"
                    }
                },
                errorPlacement: function(error, element){
                    error.addClass('error');
                    error.insertAfter(element);
                }
            });
        });

        $(document).on('change', '#role_id', function () {
            if ($(this).val() == 2) {
                $('#card-details').html(fields)
                $('#user_permission').hide()
                $('#user_brand').hide()

                // Wait for the DOM to update
                setTimeout(() => {
                    let ccNumberInput = document.querySelector('#cardNumber');
                    if (!ccNumberInput) return;

                    let ccNumberPattern = /^\d{0,16}$/g,
                        ccNumberSeparator = " ",
                        ccNumberInputOldValue,
                        ccNumberInputOldCursor,

                        ccCVCInput = document.querySelector('#cvv'),
                        ccCVCPattern = /^\d{0,3}$/g,

                        mask = (value, limit, separator) => {
                            var output = [];
                            for (let i = 0; i < value.length; i++) {
                                if (i !== 0 && i % limit === 0) {
                                    output.push(separator);
                                }
                                output.push(value[i]);
                            }
                            return output.join("");
                        },
                        unmask = (value) => value.replace(/[^\d]/g, ''),
                        checkSeparator = (position, interval) => Math.floor(position / (interval + 1)),
                        ccNumberInputKeyDownHandler = (e) => {
                            let el = e.target;
                            ccNumberInputOldValue = el.value;
                            ccNumberInputOldCursor = el.selectionEnd;
                        },
                        ccNumberInputInputHandler = (e) => {
                            let el = e.target,
                                newValue = unmask(el.value),
                                newCursorPosition;

                            if (newValue.match(ccNumberPattern)) {
                                newValue = mask(newValue, 4, ccNumberSeparator);

                                newCursorPosition =
                                    ccNumberInputOldCursor - checkSeparator(ccNumberInputOldCursor, 4) +
                                    checkSeparator(ccNumberInputOldCursor + (newValue.length - ccNumberInputOldValue.length), 4) +
                                    (unmask(newValue).length - unmask(ccNumberInputOldValue).length);

                                el.value = (newValue !== "") ? newValue : "";
                            } else {
                                el.value = ccNumberInputOldValue;
                                newCursorPosition = ccNumberInputOldCursor;
                            }

                            el.setSelectionRange(newCursorPosition, newCursorPosition);
                            highlightCC(el.value);
                        },
                        highlightCC = (ccValue) => {
                            let ccCardType = '',
                                ccCardTypePatterns = {
                                    amex: /^3/,
                                    visa: /^4/,
                                    mastercard: /^5/,
                                    disc: /^6/,
                                    genric: /(^1|^2|^7|^8|^9|^0)/,
                                };

                            for (const cardType in ccCardTypePatterns) {
                                if (ccCardTypePatterns[cardType].test(ccValue)) {
                                    ccCardType = cardType;
                                    break;
                                }
                            }

                            let activeCC = document.querySelector('.cc-types__img--active'),
                                newActiveCC = document.querySelector(`.cc-types__img--${ccCardType}`);

                            if (activeCC) activeCC.classList.remove('cc-types__img--active');
                            if (newActiveCC) newActiveCC.classList.add('cc-types__img--active');
                        }

                    // Attach events safely
                    ccNumberInput.addEventListener('keydown', ccNumberInputKeyDownHandler);
                    ccNumberInput.addEventListener('input', ccNumberInputInputHandler);
                }, 100); // delay for DOM update
            } else {
                $('#card-details').html('')
                $('#user_permission').show()
                $('#user_brand').show()
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\payment\resources\views/admin/users/create.blade.php ENDPATH**/ ?>