<script type="text/javascript" src="https://js.stripe.com/v2/"></script>
<?php echo $__env->yieldContent('scripts'); ?>
<script>
    $(document).on('keyup paste', '.validate', function() {
        let bool = true;
        values = Array.from(document.querySelectorAll('.validate'))
            .map(input => input.value)
        for (var i = 0; i < values.length; i++) {
            if (values[i] == "") {
                bool = false;
                break;
            }
        }
        console.log(bool)
        if (bool) {
            $('#payment-methods').show();
            $('.pay-message').css('color', 'darkgrey');
        } else {
            $('#payment-methods').hide();
            $('.pay-message').css('color', 'red');

        }

    })

    $(document).ready(function($) {
        $(".card-cvc").mask("999");
        $(".card-number").mask("9999 9999 9999 9999");
        $("#phonenumber").mask("+999999999999");
    });


    ;
    (function(window, $) {
        "use strict";

        var defaultConfig = {
            type: '',
            autoDismiss: false,
            container: '#toasts',
            autoDismissDelay: 4000,
            transitionDuration: 500
        };

        $.toast = function(config) {
            var size = arguments.length;
            var isString = typeof(config) === 'string';

            if (isString && size === 1) {
                config = {
                    message: config
                };
            }

            if (isString && size === 2) {
                config = {
                    message: arguments[1],
                    type: arguments[0]
                };
            }

            return new toast(config);
        };

        var toast = function(config) {
            config = $.extend({}, defaultConfig, config);
            // show "x" or not
            var close = config.autoDismiss ? '' : '&times;';

            // toast template
            var toast = $([
                '<div class="toast ' + config.type + '">',
                '<p>' + config.message + '</p>',
                '<div class="close">' + close + '</div>',
                '</div>'
            ].join(''));

            // handle dismiss
            toast.find('.close').on('click', function() {
                var toast = $(this).parent();

                toast.addClass('hide');

                setTimeout(function() {
                    toast.remove();
                }, config.transitionDuration);
            });

            // append toast to toasts container
            $(config.container).append(toast);

            // transition in
            setTimeout(function() {
                toast.addClass('show');
            }, config.transitionDuration);

            // if auto-dismiss, start counting
            if (config.autoDismiss) {
                setTimeout(function() {
                    toast.find('.close').click();
                }, config.autoDismissDelay);
            }

            return this;
        };

    })(window, jQuery);

    /* ---- start demo code ---- */

    var count = 1;
    var types = ['default', 'error', 'warning', 'info'];

    $('button').click(function() {
        var data = this.dataset;

        switch (data.type) {
            case 'types':
                $.toast(data.kind, 'This is a ' + data.kind + ' toast.');
                break;
            case 'html':
                $.toast(
                    '<div class="custom-toast"><img src="https://dysfunc.github.io/animat.io/images/ron_burgundy.png"><p>You stay classy San Deigo</p></div>'
                    );
                break;

            case 'auto':
                $.toast({
                    autoDismiss: true,
                    message: 'This is my auto-dismiss toast message'
                });

                break;

            default:
        }
    });
</script>

<?php if(old('card_holder_name') != '' &&
        old('card_number') != '' &&
        old('cvv_number') != '' &&
        old('exp_month') != '' &&
        old('exp_year') != ''): ?>
    <script>
        $(document).ready(function() {
            $('#payment-methods').show();
        })
    </script>
<?php endif; ?>

<?php if(Session::has('error')): ?>
    <script>
        $.toast("<?php echo e(Session::get('error')); ?>");
    </script>
<?php endif; ?><?php /**PATH D:\xampp-8\htdocs\terminal\resources\views/payment_terminals/layout/script.blade.php ENDPATH**/ ?>