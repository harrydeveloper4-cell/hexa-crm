<!DOCTYPE html>
<html lang="en">
<!-- START: Head-->

<!-- Mirrored from html.designstream.co.in/pick/html/page-login.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 21 Apr 2021 19:47:32 GMT -->

<head>
    <meta charset="UTF-8">
    <title>Admin Login</title>
    <link rel="shortcut icon" href="<?php echo e(asset('admin/dist/images/favicon.ico')); ?>" />
    <meta name="viewport" content="width=device-width,initial-scale=1">

    <!-- START: Template CSS-->
    <link rel="stylesheet" href="<?php echo e(asset('admin/dist/vendors/bootstrap/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/dist/vendors/jquery-ui/jquery-ui.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/dist/vendors/jquery-ui/jquery-ui.theme.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/dist/vendors/simple-line-icons/css/simple-line-icons.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/dist/vendors/flags-icon/css/flag-icon.min.css')); ?>">

    <!-- END Template CSS-->

    <!-- START: Page CSS-->
    <link rel="stylesheet" href="<?php echo e(asset('admin/dist/vendors/social-button/bootstrap-social.css')); ?>" />
    <!-- END: Page CSS-->

    <!-- START: Custom CSS-->
    <link rel="stylesheet" href="<?php echo e(asset('admin/dist/css/main.css')); ?>">
    <!-- END: Custom CSS-->
</head>
<!-- END Head-->

<!-- START: Body-->

<body id="main-container" class="default">
    <!-- START: Main Content-->
    <div class="container">
        <div class="row vh-100 justify-content-between align-items-center">
            <div class="col-12">
                <?php if(Session::has('error')): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <strong>Invalid Login</strong> <?php echo e(Session::get('error')); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                    </div>
                <?php endif; ?>
                <form action="<?php echo e(route('admin.login.process')); ?>" method = "POST"
                    class="row row-eq-height lockscreen  mt-5 mb-5">
                    <?php echo csrf_field(); ?>
                    <div class="lock-image col-12 col-sm-5"></div>
                    <div class="login-form col-12 col-sm-7">
                        <div class="form-group mb-3">
                            <label for="emailaddress">Email address</label>
                            <input class="form-control <?php $__errorArgs = ['emailaddress'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="email" value = "<?php echo e(old('email')); ?>" name = "email"
                                id="emailaddress" required="" placeholder="Enter your email">
                            <?php $__errorArgs = ['emailaddress'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group mb-3">
                            <label for="password">Password</label>
                            <input class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="password" name = "password" required="" id="password"
                                placeholder="Enter your password">
                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>


                        <div class="form-group mb-0">
                            <button class="btn btn-primary" type="submit"> Log In </button>
                        </div>

                        <div class="mt-2"></div>
                    </div>
                </form>
            </div>

        </div>
    </div>
    <!-- END: Content-->

    <!-- START: Template JS-->
    <script src="<?php echo e(asset('admin/dist/vendors/jquery/jquery-3.3.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/dist/vendors/jquery-ui/jquery-ui.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/dist/vendors/moment/moment.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/dist/vendors/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/dist/vendors/slimscroll/jquery.slimscroll.min.js')); ?>"></script>

    <!-- END: Template JS-->
</body>
<!-- END: Body-->

</html>
<?php /**PATH C:\xampp\htdocs\payment\resources\views/admin/login.blade.php ENDPATH**/ ?>