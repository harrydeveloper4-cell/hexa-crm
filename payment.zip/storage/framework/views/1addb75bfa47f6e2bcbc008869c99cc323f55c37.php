    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="<?php echo e(asset('style.css')); ?>" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" />
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" />

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="<?php echo e(asset('script.js')); ?>"></script>
    <link rel="stylesheet" href="<?php echo e(asset('admin/dist/vendors/toastr/toastr.min.css')); ?>">
    <?php echo $__env->yieldContent('meta'); ?><?php /**PATH D:\xampp\htdocs\dtek_payment_terminal\resources\views/payment_terminals/layout/meta.blade.php ENDPATH**/ ?>