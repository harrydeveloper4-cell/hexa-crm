
<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row vh-100 justify-content-between align-items-center">
            <div class="col-12">
                <div class="lockscreen  mt-5 mb-5">
                    <div class="jumbotron mb-0 text-center theme-background rounded">
                        <h1 class="display-3 font-weight-bold"> 404</h1>
                        <h5><i class="ion ion-alert pr-2"></i>Oops! Something went wrong</h5>
                        <p>The page you are looking for is not found, please try after some time or go back to home</p>
                        <a href="<?php echo e(route('dashboard')); ?>" class="btn btn-primary">Go To Home</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\square_terminal\resources\views/errors/404.blade.php ENDPATH**/ ?>