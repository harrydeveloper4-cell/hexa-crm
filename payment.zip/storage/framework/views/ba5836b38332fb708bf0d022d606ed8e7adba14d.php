
<?php $__env->startSection('title', 'Merchants'); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb-title'); ?>
    <h3><?php echo e(__('Merchants Edit')); ?></h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb-items'); ?>
    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.brands.index')); ?>"><?php echo e(__('Brands')); ?></a></li>
    <li class="breadcrumb-item active"><?php echo e(__('Merchants Edit')); ?></li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12 mt-4">
            <div class="card">
                <div class="card-header">
                    <h6 class="card-title">Merchant Edit</h6>
                    <a class = "btn btn-info float-right" href = "<?php echo e(route('admin.brands.index')); ?>">Back</a>
                </div>
                <div class="card-content">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-12">
                                <form action="<?php echo e(route('merchants.update.all')); ?>" method="POST" id="package-form">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" class="form-control rounded" name="brand"
                                        value="<?php echo e($brand); ?>">

                                        <?php if(count($brand_merchants) > 0): ?>
                                        <?php $__currentLoopData = $brand_merchants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $merchant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="form-row">
                                                <div class="form-group col-md-10">
                                                    <label for="inputEmail4">Merchant</label>
                                                    <select class="form-control rounded merchant-select"
                                                        name = "old_merchant[<?php echo e($merchant->id); ?>]">
                                                        <option value = "">Select Merchant</option>
                                                        <?php $__currentLoopData = $merchants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $merch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value = "<?php echo e($merch->id); ?>"
                                                                <?php echo e($merch->id == $merchant->merchant_id ? 'selected' : ''); ?>>
                                                                <?php echo e($merch->merchant); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                                <div class="form-group col-md-2">
                                                    <button type = "button" class = "btn btn-sm btn-danger delete-row"
                                                        data-href = "<?php echo e(route('delete.brand.merchant', ['id' => $merchant->id])); ?>"
                                                        value = "<?php echo e($merchant->id); ?>"><i class = "icon-trash"></i></button>
                                                    <input type="checkbox" value = "<?php echo e($merchant->id); ?>"
                                                        class = "change_status"
                                                        <?php echo e($merchant->status == 'active' ? 'checked' : ''); ?>

                                                        data-toggle="toggle" data-on="Active" data-off="Inactive"
                                                        data-href = "<?php echo e(route('merchant.status.change', ['id' => $merchant->id])); ?>">
                                                </div>
                                                <?php

                                                    $config_keys = json_decode(
                                                        get_merchant_keys($brand, $merchant->merchant_id),
                                                    );
                                                ?>
                                                <?php if($merchant->merchant_id == 1): ?>
                                                    <div class="form-group col-md-6 rm">
                                                        <label for="inputEmail4">Client Id</label>
                                                        <input type="text" class="form-control rounded"
                                                            name="config_key[<?php echo e($merchant->merchant_id); ?>][client_id]"
                                                            placeholder="Client Id"
                                                            value="<?php echo e($config_keys->client_id ?? ''); ?>">
                                                    </div>
                                                    <div class="form-group col-md-6 rm">
                                                        <label for="inputEmail4">Secret Key</label>
                                                        <input type="text" class="form-control rounded"
                                                            name="config_key[<?php echo e($merchant->merchant_id); ?>][secret_key]"
                                                            placeholder="Secret Key"
                                                            value="<?php echo e($config_keys->secret_key ?? ''); ?>">
                                                    </div>
                                                <?php elseif($merchant->merchant_id == 2): ?>
                                                    <div class="form-group col-md-6 rm">
                                                        <label for="inputEmail4">Stripe Key</label>
                                                        <input type="text" class="form-control rounded"
                                                            name="config_key[<?php echo e($merchant->merchant_id); ?>][stripe_key]"
                                                            placeholder="Stripe Key"
                                                            value="<?php echo e($config_keys->stripe_key ?? ''); ?>">
                                                    </div>
                                                    <div class="form-group col-md-6 rm">
                                                        <label for="inputEmail4">Secret Key</label>
                                                        <input type="text" class="form-control rounded"
                                                            name="config_key[<?php echo e($merchant->merchant_id); ?>][stripe_secret_key]"
                                                            placeholder="Secret Key"
                                                            value="<?php echo e($config_keys->stripe_secret_key ?? ''); ?>">
                                                    </div>
                                                <?php elseif($merchant->merchant_id == 3): ?>
                                                    <div class="form-group col-md-4 rm">
                                                        <label for="inputEmail4">App Id</label>
                                                        <input type="text" class="form-control rounded"
                                                            name="config_key[<?php echo e($merchant->merchant_id); ?>][app_id]"
                                                            placeholder="App Id"
                                                            value="<?php echo e($config_keys->app_id ?? ''); ?>">
                                                    </div>
                                                    <div class="form-group col-md-4">
                                                        <label for="inputEmail4">Access Token</label>
                                                        <input type="text" class="form-control rounded"
                                                            name="config_key[<?php echo e($merchant->merchant_id); ?>][access_token]"
                                                            placeholder="Access Token"
                                                            value="<?php echo e($config_keys->access_token ?? ''); ?>">
                                                    </div>
                                                    <div class="form-group col-md-4 rm">
                                                        <label for="inputEmail4">Location Id</label>
                                                        <input type="text" class="form-control rounded"
                                                            name="config_key[<?php echo e($merchant->merchant_id); ?>][location_id]"
                                                            placeholder="Location Id"
                                                            value="<?php echo e($config_keys->location_id ?? ''); ?>">
                                                    </div>
                                                <?php elseif($merchant->merchant_id == 4): ?>
                                                    <div class="form-group col-md-6 rm">
                                                        <label for="inputEmail4">Merchant Login Id</label>
                                                        <input type="text" class="form-control rounded"
                                                            name="config_key[<?php echo e($merchant->merchant_id); ?>][merchant_login_id]"
                                                            placeholder="Merchant Login Id"
                                                            value="<?php echo e($config_keys->merchant_login_id ?? ''); ?>">
                                                    </div>
                                                    <div class="form-group col-md-6 rm">
                                                        <label for="inputEmail4">Merchant Transaction Key</label>
                                                        <input type="text" class="form-control rounded"
                                                            name="config_key[<?php echo e($merchant->merchant_id); ?>][merchant_transaction_key]"
                                                            placeholder="Merchant Transaction Key"
                                                            value="<?php echo e($config_keys->merchant_transaction_key ?? ''); ?>">
                                                    </div>
                                                <?php elseif($merchant->merchant_id == 5): ?>
                                                    <div class="form-group col-md-6 rm">
                                                        <label for="inputEmail4">Access Key</label>
                                                        <input type="text" class="form-control rounded"
                                                            name="config_key[<?php echo e($merchant->merchant_id); ?>][access_key]"
                                                            placeholder="Access Key"
                                                            value="<?php echo e($config_keys->access_key ?? ''); ?>">
                                                    </div>
                                                    <div class="form-group col-md-6 rm">
                                                        <label for="inputEmail4">Secret Key</label>
                                                        <input type="text" class="form-control rounded"
                                                            name="config_key[<?php echo e($merchant->merchant_id); ?>][secret_key]"
                                                            placeholder="Secret Key"
                                                            value="<?php echo e($config_keys->secret_key ?? ''); ?>">
                                                    </div>
                                                <?php endif; ?>


                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>

                                    <div class="form-row">
                                        <div class="form-group col-md-12">
                                            <button type="button" class="btn btn-sm btn-primary add-row"><i
                                                    class="icon-plus"></i></button>
                                        </div>
                                    </div>
                                    <div id="append-row">
                                        <?php if(isset($merchants) && count($merchants) == 0): ?>
                                            <div class="form-row">
                                                <div class="form-group col-md-10">
                                                    <label for="inputEmail4">Merchant</label>

                                                    <select class="form-control rounded merchant-select" name = "merchant[]">
                                                        <option value = "">Select Merchant</option>
                                                        <?php $__currentLoopData = $merchants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $merchant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value = "<?php echo e($merchant->id); ?>"><?php echo e($merchant->merchant); ?>

                                                            </option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                                <div class="form-group col-md-2">
                                                    <label for="inputEmail4"></label>
                                                    <button type = "button" class = "btn btn-sm btn-primary add-row"><i
                                                            class = "icon-plus"></i></button>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                        <?php $__errorArgs = ['merchant.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="text-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>


                                    <div class="form-row">
                                        <input type="submit" value="Save" class="btn btn-primary">
                                    </div>
                                </form>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function() {
            $('#merchant-form').validate({
                rules: {
                    brand: 'required'
                }
            })


        })
    </script>
    <script type="text/javascript">
        // add row
        let merchant_field = '';
        merchant_field += '<select class="form-control rounded merchant-select" name = "merchant[]">';
        merchant_field += '<option value = "">Select Merchant</option>'
        <?php $__currentLoopData = $merchants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $merchant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            merchant_field += '<option value = "<?php echo e($merchant->id); ?>"><?php echo e($merchant->merchant); ?></option>';
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        merchant_field += '</select>';

        $(document).on('click', '.add-row', function() {
            var html =
                '<div class="form-row"> <div class="form-group col-md-10"><label for="inputEmail4">Merchant</label> ' +
                merchant_field +
                '</div><div class="form-group col-md-2"> <label for="inputEmail4"></label> <button type="button" class="btn btn-sm btn-primary add-row"><i class="icon-plus"></i></button> <button type="button" class="btn btn-sm btn-danger remove-row" value=""><i class="icon-minus"></i></button> </div></div>';
            $('#append-row').append(html);
        });
        // remove row
        $(document).on('click', '.remove-row', function() {
            $(this).closest('.form-row').remove();
        });
        $(document).on('click', '.delete-row', function(e) {
            e.preventDefault();
            let element = $(this);
            let url = $(this).data('href');

            swal({
                title: "<?php echo e(__('Are you sure?')); ?>",
                text: "<?php echo e(__('Once deleted, you will not be able to recover this!')); ?>",
                icon: "warning",
                buttons: true,
                dangerMode: true,
            }).then((willDelete) => {
                if (willDelete) {
                    $.ajax({
                        url: url,
                        type: 'GET',
                        success: function(data) {
                            element.closest('.form-row').remove();
                            swal("<?php echo e(__('Deleted successfully!')); ?>", {
                                icon: "success",
                                timer: 2000,
                            });
                        },
                        error: function(err) {
                            swal("<?php echo e(__('Merchant could not be removed')); ?>", {
                                icon: "error",
                                timer: 2000,
                            });
                        }
                    });
                } else {
                    swal("<?php echo e(__('Your data is safe!')); ?>", {
                        icon: "info",
                        timer: 2000,
                    });
                }
            });
        });
        $(document).on('change', '.change_status', function() {
            let element = $(this);
            let status = '';
            let url = element.data('href')
            if (element.is(':checked')) {
                status = 'active';
            } else {
                status = 'inactive';
            }
            $.ajax({
                url: url,
                type: 'GET',
                data: {
                    status: status
                },
                success: function(data) {

                },
                error: function(err) {
                    alert('Merchant status could not changed');
                }
            })
        })
        $(document).on('change', '.merchant-select', function() {
            let merchant = $(this).val();
            $(this).parent().siblings(".rm").remove();
            if (merchant == 1) {
                $(this).closest('.form-row').append(
                    '<div class="form-group col-md-6 rm"> <label for="inputEmail4">Client Id</label> <input type="text" class="form-control rounded" name="config_key[' +
                    merchant +
                    '][client_id]" placeholder="Client Id" value="" > </div><div class="form-group col-md-6 rm"> <label for="inputEmail4">Secret Key</label> <input type="text" class="form-control rounded" name="config_key[' +
                    merchant + '][secret_key]" placeholder="Secret Key" value="" > </div>')
            } else if (merchant == 2) {
                $(this).closest('.form-row').append(
                    '<div class="form-group col-md-6 rm"> <label for="inputEmail4">Stripe Key</label> <input type="text" class="form-control rounded" name="config_key[' +
                    merchant +
                    '][stripe_key]" placeholder="Stripe Key" value="" > </div><div class="form-group col-md-6 rm"> <label for="inputEmail4">Secret Key</label> <input type="text" class="form-control rounded" name="config_key[' +
                    merchant + '][stripe_secret_key]" placeholder="Secret Key" value="" > </div>')
            } else if (merchant == 3) {
                $(this).closest('.form-row').append(
                    '<div class="form-group col-md-4 rm"> <label for="inputEmail4">App Id</label> <input type="text" class="form-control rounded" name="config_key[' +
                    merchant +
                    '][app_id]" placeholder="App Id" value="" > </div><div class="form-group col-md-4"> <label for="inputEmail4">Access Token</label> <input type="text" class="form-control rounded" name="config_key[' +
                    merchant +
                    '][access_token]" placeholder="Access Token" value="" > </div><div class="form-group col-md-4 rm"> <label for="inputEmail4">Location Id</label> <input type="text" class="form-control rounded" name="config_key[' +
                    merchant + '][location_id]" placeholder="Location Id" value="" > </div>')
            } else if (merchant == 4) {
                $(this).closest('.form-row').append(
                    ' <div class="form-group col-md-6 rm"> <label for="inputEmail4">Merchant Login Id</label> <input type="text" class="form-control rounded" name="config_key[' +
                    merchant +
                    '][merchant_login_id]" placeholder="Merchant Login Id" value="" > </div><div class="form-group col-md-6 rm"> <label for="inputEmail4">Merchant Transaction Key</label> <input type="text" class="form-control rounded" name="config_key[' +
                    merchant +
                    '][merchant_transaction_key]" placeholder="Merchant Transaction Key" value="" > </div>')
            } else if (merchant == 5) {
                $(this).closest('.form-row').append(
                    '<div class="form-group col-md-6 rm"> <label for="inputEmail4">Access Key</label> <input type="text" class="form-control rounded" name="config_key[' +
                    merchant +
                    '][access_key]" placeholder="Access Key" value="" > </div><div class="form-group col-md-6 rm"> <label for="inputEmail4">Secret Key</label> <input type="text" class="form-control rounded" name="config_key[' +
                    merchant + '][secret_key]" placeholder="Secret Key" value="" > </div>')
            } else {
                $(this).parent().siblings(".form-group").remove();
            }
        });
        $(".select").select2();
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp-8\htdocs\terminal\resources\views/admin/brand-merchants/all_edit.blade.php ENDPATH**/ ?>