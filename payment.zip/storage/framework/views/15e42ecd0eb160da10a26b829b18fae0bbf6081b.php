<?php $__currentLoopData = $merchants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $merchant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="form-group col-md-3">
        <input id="radio<?php echo e($merchant->id); ?>" type="radio" name="payment_gateway" value="<?php echo e($merchant->id); ?>"  <?php echo e(old('payment_gateway') == $merchant->id ? 'checked' : ''); ?> >
        <?php if($merchant->id == 1): ?>
            <label for="radio<?php echo e($merchant->id); ?>"><img src="<?php echo e(asset('images/paypal.png')); ?>"></label>
        <?php elseif($merchant->id == 2): ?>
            <label for="radio<?php echo e($merchant->id); ?>"><img src="<?php echo e(asset('images/stripe.png')); ?>"></label>
        <?php elseif($merchant->id == 3): ?>
            <label for="radio<?php echo e($merchant->id); ?>"><img src="<?php echo e(asset('images/square1.png')); ?>"></label>
        <?php elseif($merchant->id == 4): ?>
            <label for="radio<?php echo e($merchant->id); ?>"><img src="<?php echo e(asset('images/authorize1.png')); ?>"></label>
        <?php elseif($merchant->id == 5): ?>
            <label for="radio<?php echo e($merchant->id); ?>"><img src="<?php echo e(asset('images/rapyd.png')); ?>"></label>
        <?php endif; ?>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH D:\xampp\htdocs\square_terminal\resources\views/ajax/merchants.blade.php ENDPATH**/ ?>