<?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($transaction->id); ?></td>
        <td><?php echo e($transaction->orders->order_number); ?></td>
        <td><?php echo e($transaction->orders->sale_amount . ' ' . $transaction->orders->sale_currency); ?>

        </td>
        <td><?php echo e($transaction->orders->payment_gateway); ?> </td>
        <td><?php echo e(date('d/m/Y H:i', strtotime($transaction->created_at))); ?></td>

        <td>
            <a
                href = "<?php echo e(route('admin.orders.show', ['id' => $transaction->order_id])); ?>"><i
                    class = "icon-eye"></i></a>
            <?php if($transaction->orders->payment_gateway == 'Stripe' || $transaction->orders->payment_gateway == 'Authorize.net'): ?>
                <a class = "payment-reoccur" href = "javascript::void(0)"
                    data-brand = "<?php echo e($transaction->orders->brand_name); ?>"
                    data-email = "<?php echo e($transaction->email); ?>"
                    data-ordernumber = "<?php echo e($transaction->orders->order_number); ?>"
                    data-order = "<?php echo e($transaction->order_id); ?>"
                    data-merchant = "<?php echo e(strtolower($transaction->orders->payment_gateway)); ?>"
                    data-currency = "<?php echo e($transaction->orders->sale_currency); ?>"
                    data-toggle="modal" data-target="#exampleModalCenter"><i
                    class = "icon-refresh"></i></a>
            <?php endif; ?>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH D:\xampp-8\htdocs\terminal\resources\views/admin/transactions/records.blade.php ENDPATH**/ ?>