<!-- START: Main Menu-->
<?php
    $user = App\Models\Adminiy::find(Auth::guard('adminiy')->user()->id);
?>
<div class="sidebar">
    <div class="site-width">
        <!-- START: Menu-->
        <ul id="side-menu" class="sidebar-menu">
            <li class="dropdown"><a href="<?php echo e(route('dashboard')); ?>"><i class="icon-home mr-1"></i> Dashboard</a>
                <ul>
                    <li><a href="<?php echo e(route('dashboard')); ?>"><i class="icon-speedometer"></i> Dashboard</a></li>
                </ul>
            </li>
            <?php if($user->has_permission(4) || $user->role_id == 1): ?>
                <li class="dropdown"><a href="#"><i class="icon-tag mr-1"></i> Brand
                        Management</a>
                    <ul>
                        <li><a href="<?php echo e(route('admin.brands.index')); ?>"><i class="icon-briefcase"></i>All
                                Brands</a></li>
                        
                    </ul>
                </li>
            <?php endif; ?>
            <?php if($user->has_permission(7) || $user->role_id == 1): ?>
                
            <?php endif; ?>
            <li class="dropdown"><a href="#"><i class="icon-basket mr-1"></i> Order Management</a>

                <ul>
                    <?php if($user->has_permission(1) || $user->role_id == 1): ?>
                        <li><a href="<?php echo e(route('payment.create_order')); ?>"><i class="icon-plus"></i>Create
                                Order</a></li>
                    <?php endif; ?>
                    <?php if($user->has_permission(2) || $user->role_id == 1): ?>
                        <li><a href="<?php echo e(route('admin.orders.index')); ?>"><i class="icon-list"></i>Orders</a>
                        </li>
                    <?php endif; ?>
                    <?php if($user->has_permission(3) || $user->role_id == 1): ?>
                        <li><a href="<?php echo e(route('admin.transactions.index')); ?>"><i
                                    class="icon-credit-card"></i>Transactions</a></li>
                    <?php endif; ?>
                    <?php if($user->has_permission(6) || $user->role_id == 1): ?>
                        <li><a href="<?php echo e(route('admin.payments-recuring.index')); ?>"><i class="icon-refresh"></i>Payment
                                Recurring</a></li>
                    <?php endif; ?>
                </ul>

            </li>
            <?php if($user->has_permission(5) || $user->role_id == 1): ?>
                <li class="dropdown"><a href="#"><i class="icon-people mr-1"></i> User
                        Management</a>
                    <ul>
                        <li><a href="<?php echo e(route('users')); ?>"><i class="icon-user"></i>Users</a></li>
                    </ul>
                </li>
            <?php endif; ?>
            
            
        </ul>
        <!-- END: Menu-->

    </div>
</div>
<!-- END: Main Menu-->
<?php /**PATH D:\xampp-8\htdocs\terminal\resources\views/admin/layout/sidebar.blade.php ENDPATH**/ ?>