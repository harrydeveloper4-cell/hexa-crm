<!-- START: Footer-->
    <footer class="site-footer">
        <?php echo e(date('Y')); ?> © <?php echo e(env('APP_NAME')); ?>

    </footer>
<!-- END: Footer-->
<?php /**PATH /home/webdzkym/public_html/all-in-flo/payment/resources/views/admin/layout/footer.blade.php ENDPATH**/ ?>