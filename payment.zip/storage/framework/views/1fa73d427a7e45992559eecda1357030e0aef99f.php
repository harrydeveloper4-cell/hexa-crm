
<?php $__env->startSection('title', 'Square'); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <form id="payment-form">
        <div id="card-container"></div>
        <button id="card-button" class = "btn btn-primary d-block h8" type="button">PAY <span
                class="fas fa-dollar-sign ms-2"></span><?php echo e(number_format($order->sale_amount, 2)); ?><span
                class="ms-3 fas fa-arrow-right"></span></button>
    </form>
    <div id="payment-status-container"></div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>

    <?php if(env('SquareUP_ENVIRONMENT') == 'sandbox'): ?>
        
        <script src="https://sandbox.web.squarecdn.com/v1/square.js"></script>
    <?php elseif(env('SquareUP_ENVIRONMENT') == 'production'): ?>
        <script type="text/javascript" src="https://web.squarecdn.com/v1/square.js"></script>
    <?php endif; ?>
    <?php
        $config_keys = json_decode(get_merchant_keys($order->brand_name, $order->merchant_id));
    ?>
    <script>
        var sale_amount = "<?php echo e($order->sale_amount); ?>";
        var order_id = "<?php echo e($order->id); ?>";
        var access_token = "<?php echo e($config_keys->access_token); ?>";
        var csrf_token = "<?php echo e(csrf_token()); ?>";
        var square_route = "<?php echo e(route('square.checkout')); ?>";

        const appId = "<?php echo e($config_keys->app_id); ?>";
        const locationId = "<?php echo e($config_keys->location_id); ?>";

        // console.log('appID', appId);
        // console.log('locationId', locationId);

        async function initializeCard(payments) {
            console.log('iii');
            const card = await payments.card();
            await card.attach('#card-container');
            return card;
        }

        async function createPayment(token) {
            const body = JSON.stringify({
                locationId,
                sourceId: token,
                access_token: access_token,
                order_id: order_id,
                '_token': csrf_token,
                amount: sale_amount
            });

            const paymentResponse = await fetch(square_route, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body,
            });

            if (paymentResponse.ok) {
                return paymentResponse.json();
            }

            const errorBody = await paymentResponse.text();
            throw new Error(errorBody);
        }

        async function tokenize(paymentMethod) {
            const tokenResult = await paymentMethod.tokenize();
            console.log('Tokenization result:', tokenResult);
            if (tokenResult.status === 'OK') {
                return tokenResult.token;
            } else {
                let errorMessage = `Tokenization failed with status: ${tokenResult.status}`;
                if (tokenResult.errors) {
                    errorMessage += ` and errors: ${JSON.stringify(
        tokenResult.errors
        )}`;
                }

                throw new Error(errorMessage);
            }
        }

        // status is either SUCCESS or FAILURE;
        function displayPaymentResults(status) {
            const statusContainer = document.getElementById(
                'payment-status-container'
            );
            if (status === 'SUCCESS') {
                statusContainer.classList.remove('is-failure');
                statusContainer.classList.add('is-success');
            } else {
                statusContainer.classList.remove('is-success');
                statusContainer.classList.add('is-failure');
            }

            statusContainer.style.visibility = 'visible';
        }

        document.addEventListener('DOMContentLoaded', async function() {
            let payments;
            try {
                if (!window.Square) {
                    throw new Error('Square.js failed to load. Please ensure your site is served over HTTPS.');
                }

                payments = window.Square.payments(appId, locationId);
            } catch (error) {
                console.error("Error initializing Square payments:", error.message);
                const statusContainer = document.getElementById('payment-status-container');
                statusContainer.innerText = 'Unable to initialize payments. Please contact support.';
                statusContainer.style.visibility = 'visible';
                return;
            }

            let card;
            try {
                card = await initializeCard(payments);
            } catch (error) {
                console.error('Error initializing card:', error);
                return;
            }

            // Checkpoint 2.
            async function handlePaymentMethodSubmission(event, paymentMethod) {
                event.preventDefault();

                try {
                    // disable the submit button as we await tokenization and make a payment request.
                    cardButton.disabled = true;
                    const token = await tokenize(paymentMethod);
                    const paymentResults = await createPayment(token);
                    console.log(paymentResults);
                    displayPaymentResults('SUCCESS');
                    $('#payment_method').val('square')
                    $('#payment_id').val(paymentResults.payment.id)
                    $('#payer_id').val(paymentResults.payment.card_details.card.bin)
                    $('#paid_amount').val(paymentResults.payment.approved_money.amount)
                    $('#last_digit').val(paymentResults.payment.card_details.card.last_4)
                    $('#response').val(JSON.stringify(paymentResults.payment))
                    $('#form').submit()
                    //toastr.success('Payment has been processed successfully..!');

                } catch (e) {
                    cardButton.disabled = false;
                    displayPaymentResults('FAILURE');
                    console.error(e.message);
                }
            }

            const cardButton = document.getElementById('card-button');
            cardButton.addEventListener('click', async function(event) {
                await handlePaymentMethodSubmission(event, card);
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('payment_terminals.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp-8\htdocs\terminal\resources\views/payment_terminals/square.blade.php ENDPATH**/ ?>