    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="<?php echo e(asset('style.css')); ?>" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" />
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" />

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="<?php echo e(asset('script.js')); ?>"></script>
    <link rel="stylesheet" href="<?php echo e(asset('admin/dist/vendors/toastr/toastr.min.css')); ?>">
    
    
    
    
    <meta name="viewport" content="width=device-width, initial-scale=1"/>
    <meta name="description" content="<?php echo $__env->yieldContent('desc'); ?>">
    <meta name="author" content="<?php echo $__env->yieldContent('title'); ?>">
    <meta property="og:title" content="Payment | <?php echo $__env->yieldContent('title'); ?>">
    <meta property="og:image:secure_url" content="<?php echo $__env->yieldContent('img'); ?>">
    
    <meta property="og:image:url" content="<?php echo $__env->yieldContent('url'); ?>" /> 
    <meta property="og:image:type" content="image/png" /> 
    <meta property="og:image:width" content="400" /> 
    <meta property="og:image:height" content="300" />

    <link href="<?php echo $__env->yieldContent('img'); ?>" rel="icon">
    
    <meta property="og:site_name" content="Payment | <?php echo $__env->yieldContent('title'); ?>" />
    <meta property="og:description" content="<?php echo $__env->yieldContent('desc'); ?>">
     <link rel="apple-touch-icon" href="<?php echo $__env->yieldContent('img'); ?>">
    <link rel="icon" href="<?php echo $__env->yieldContent('img'); ?>">
   
    <?php echo $__env->yieldContent('meta'); ?><?php /**PATH C:\xampp\htdocs\payment\resources\views/payment_terminals/layout/meta.blade.php ENDPATH**/ ?>