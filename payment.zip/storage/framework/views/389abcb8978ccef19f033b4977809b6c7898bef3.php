<link rel="shortcut icon" href="<?php echo e(asset('admin/dist/images/favicon.ico')); ?>" />
<meta name="viewport" content="width=device-width,initial-scale=1">
<?php /**PATH /home/u498385541/domains/markvaulting.org/public_html/portal/resources/views/admin/layout/meta.blade.php ENDPATH**/ ?>