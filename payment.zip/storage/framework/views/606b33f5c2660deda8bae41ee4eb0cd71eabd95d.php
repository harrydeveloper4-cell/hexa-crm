
<?php $__env->startSection('title', 'Orders'); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb-title'); ?>
    <h3><?php echo e(__('Orders')); ?></h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb-items'); ?>
    <li class="breadcrumb-item active"><?php echo e(__('Orders')); ?></li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12 mt-3">
            <div class="card">
                <div class="card-header  justify-content-between align-items-center">
                    <h4 class="card-title">Orders</h4>
                    <a class = "btn btn-info float-right" href = "<?php echo e(route('payment.create_order')); ?>" target = "_blank"><i
                            class = "icon-plus"></i> Create</a>
                    

                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table id="example" class="display table dataTable table-striped table-bordered">
                            <thead>
                                <tr>
                                    
                                    <th>ID</th>
                                    <th>Brand Name</th>
                                    <th>Amount</th>
                                    <th>Sales Person</th>
                                    <th>Payment Method</th>
                                    <th>Payment Link</th>
                                    
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(isset($orders)): ?> 
                                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            
                                            
                                            <td>#<?php echo e($order->order_number); ?></td>
                                            <td><?php echo e($order->brand_details->name); ?></td>
                                            <td><?php echo e($order->sale_amount . ' ' . $order->sale_currency); ?> </td>
                                            <td><?php echo e($order->sales_email); ?></td>
                                            <td><?php echo e($order->payment_gateway); ?></td>
                                            <td>
                                                <?php if(isset($order->payment_status) && $order->payment_status == 'unpaid'): ?>
                                                    <?php if(isset($order->payment_link) && $order->payment_link != null): ?>
                                                        <?php if(isset($order->expires_at) && $order->expires_at < now()): ?>
                                                            <span href="javascript:void(0)" class="badge badge-danger"
                                                                style="color: #fff;">
                                                                Link Expired
                                                            </span>
                                                            <a href="javascript:void(0)"
                                                                class="badge badge-primary createNewLink" data-toggle="modal"
                                                                data-target="#exampleModalCenter" data-id="<?php echo e($order->id); ?>">
                                                                New Link
                                                            </a>
                                                        <?php else: ?>
                                                            <?php
                                                                $now = \Carbon\Carbon::now();
                                                                $expiresAt = \Carbon\Carbon::parse($order->expires_at);
                                                                $diffInMinutes = $expiresAt->diffInMinutes($now);
                                                                $hours = intdiv($diffInMinutes, 60);
                                                                $minutes = $diffInMinutes % 60;
                                                            ?>
                                                            <a href="javascript:void(0)"
                                                                class="copyLink me-2 badge badge-warning" data-toggle="tooltip"
                                                                data-placement="top" title=""
                                                                data-original-title="Expires in <?php echo e($hours); ?> hour(s) and <?php echo e($minutes); ?> minute(s)"
                                                                style="color: #fff;" data-platform_name="link copy"
                                                                data-payment_link="<?php echo e($order->payment_link); ?>">
                                                                Copy link <i class="icon-docs"></i>
                                                            </a>
                                                        <?php endif; ?>
                                                    <?php else: ?>
                                                        <span class="badge badge-danger">Payment link unavailable</span>
                                                    <?php endif; ?>
                                                <?php else: ?>
                                                    <span class="badge badge-success">Paid</span>
                                                <?php endif; ?>
                                            </td>
                                            
                                            <td>
                                                <div class="dropdown">

                                                    <?php if($order->status == 'pending'): ?>
                                                        <?php
                                                            $status = 'Pending';
                                                            $color = 'btn-warning';
                                                        ?>
                                                    <?php elseif($order->status == 'processing'): ?>
                                                        <?php
                                                            $status = 'Processing';
                                                            $color = 'btn-info';
                                                        ?>
                                                    <?php elseif($order->status == 'completed'): ?>
                                                        <?php
                                                            $status = 'Completed';
                                                            $color = 'btn-primary';
                                                        ?>
                                                    <?php elseif($order->status == 'discarded'): ?>
                                                        <?php
                                                            $status = 'Discarded';
                                                            $color = 'btn-secondary';
                                                        ?>
                                                    <?php elseif($order->status == 'refunded'): ?>
                                                        <?php
                                                            $status = 'Refunded';
                                                            $color = 'btn-danger';
                                                        ?>
                                                    <?php endif; ?>

                                                    <button class="btn <?php echo e($color ?? ''); ?> dropdown-toggle" type="button"
                                                        id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true"
                                                        aria-expanded="false">
                                                        <?php echo e($status ?? ''); ?>

                                                    </button>
                                                    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                                        <a class="dropdown-item"
                                                            href="<?php echo e(route('admin.orders.status', ['id' => $order->id, 'status' => 'pending'])); ?>">Pending</a>
                                                        <a class="dropdown-item"
                                                            href="<?php echo e(route('admin.orders.status', ['id' => $order->id, 'status' => 'processing'])); ?>">Processing</a>
                                                        <a class="dropdown-item"
                                                            href="<?php echo e(route('admin.orders.status', ['id' => $order->id, 'status' => 'completed'])); ?>">Completed</a>
                                                        <a class="dropdown-item"
                                                            href="<?php echo e(route('admin.orders.status', ['id' => $order->id, 'status' => 'discarded'])); ?>">Discarded</a>
                                                        <a class="dropdown-item"
                                                            href="<?php echo e(route('admin.orders.status', ['id' => $order->id, 'status' => 'refunded'])); ?>">Refunded</a>
                                                    </div>
                                                </div>


                                            </td>
                                            <td>
                                                <a href = "<?php echo e(route('admin.orders.show', ['id' => $order->id])); ?>"><i
                                                        class = "icon-eye"></i></a>
                                                <?php if($order->payment_status == 'unpaid'): ?>
                                                    <a href = "<?php echo e(route('admin.orders.edit', ['id' => $order->id])); ?>"><i
                                                            class = "icon-pencil"></i></a>
                                                <?php endif; ?>
                                                <a class = "delete_confirmation"
                                                    href = "<?php echo e(route('admin.orders.destroy', ['id' => $order->id])); ?>"><i
                                                        class = "icon-trash"></i></a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            <tfoot>
                                
                                <th>ID</th>
                                <th>Brand Name</th>
                                <th>Amount</th>
                                <th>Sales Person</th>
                                <th>Payment Method</th>
                                <th>Payment Link</th>
                                
                                <th>Status</th>
                                <th>Action</th>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>

        </div>
    </div>
    <?php if(isset($order)): ?>
        <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle1"
            style="display: none;" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLongTitle1">Create New Link</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form action="<?php echo e(route('orders.request_payment_link', ['id' => $order->id])); ?>" method="post"
                            id = "form">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="form-group col-md-12">
                                <label>Link Expiry Date *</label>
                                <input type="date" class="form-control" name="expiry_date" id="expiry_date"
                                    min="<?php echo date('Y-m-d'); ?>">
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                <button type="submit" class="btn btn-primary">Submit</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function() {
            $('.createNewLink').click(function() {
                var orderId = $(this).data('id');
                var actionUrl = "<?php echo e(route('orders.request_payment_link', ['id' => ':id'])); ?>";
                actionUrl = actionUrl.replace(':id', orderId);
                $('#form').attr('action', actionUrl);
            });
        });
    </script>
    <script>
        $(document).on('click', '.copyLink', function() {
            navigator.clipboard.writeText($(this).data('payment_link')).then(() => {
                toastr.success('Copied to clipboard!');
            }).catch(() => {
                toastr.error('Failed to copy to clipboard');
            });
        });
        // $(document).ready(function() {

        //     $(".check-all").click(function() {
        //         $("input[type=checkbox]").prop("checked", $(this).prop("checked"));
        //     });

        //     $("input[type=checkbox]").click(function() {
        //         if (!$(this).prop("checked")) {
        //             $(".check-all").prop("checked", false);
        //         }
        //     });

        //     $(document).on('change', '#update-status', function() {

        //         if ($(this).val() != '') {
        //             let status = $(this).val();
        //             var ids = [];
        //             $.each($(".check:checked"), function() {
        //                 ids.push($(this).val());
        //             });

        //             if (ids.length > 0) {
        //                 let bool = confirm(
        //                     'Are you sure you want to update status of selected inquiries as ' + status)

        //                 if (bool) {
        //                     $.ajax({
        //                         url: "",
        //                         type: "POST",
        //                         data: {
        //                             status: status,
        //                             ids: ids,
        //                             '_token': "<?php echo e(csrf_token()); ?>"
        //                         },
        //                         success: function(data) {
        //                             $("input[type=checkbox]").prop("checked", false)
        //                             window.location.reload()

        //                         },
        //                         error: function(error) {
        //                             alert('Inquiries updating failed')
        //                         }
        //                     })
        //                 }
        //             }
        //         } else {
        //             alert('Please select atleast one inquiry')
        //         }
        //     })

        //     $(document).on('click', '.inquiry-detail', function() {
        //         var id = $(this).data('id')

        //         $.ajax({
        //             url: route,
        //             type: 'GET',
        //             data: {
        //                 id: id
        //             },
        //             success: function(data) {
        //                 alert(work)
        //             }
        //         })
        //     })

        //     $(document).on('click', '.destroy', function(e) {

        //         e.preventDefault();

        //         let url = $(this).attr('href');

        //         let bool = confirm('Are you sure you want to delete this Order');
        //         if (bool) {
        //             window.location.href = url;
        //         }
        //     })
        // })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\square_terminal\resources\views/admin/orders/index.blade.php ENDPATH**/ ?>