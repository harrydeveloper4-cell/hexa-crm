
<?php $__env->startSection('title', 'Users'); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb-title'); ?>
    <h3><?php echo e(isset($user->firstname) ? ucfirst($user->firstname) : 'User'); ?> <?php echo e(isset($user->lastname) ? ucfirst($user->lastname) : ''); ?></h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb-items'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12 col-md-6 mt-3">
            <div class="card">
                <div class="card-header  justify-content-between align-items-center">                               
                    <h4 class="card-title">Personel Details</h4> 
                </div>
                <div class="card-body">
                    <dl class="row mb-0 redial-line-height-2_5">
                        <dt class="col-sm-5">First Name:</dt>
                        <dd class="col-sm-7"><?php echo e($user->firstname ?? ''); ?></dd>

                        <dt class="col-sm-5">Last Name:</dt>
                        <dd class="col-sm-7"><?php echo e($user->lastname ?? ''); ?></dd>

                        <dt class="col-sm-5">Billing Address:</dt>
                        <dd class="col-sm-7"><?php echo e($user->billing_address ?? ''); ?></dd>

                        <dt class="col-sm-5">Country:</dt>
                        <dd class="col-sm-7"><?php echo e($user->country ?? ''); ?></dd>

                        <dt class="col-sm-5">State:</dt>
                        <dd class="col-sm-7"><?php echo e($user->state ?? ''); ?></dd>

                        <dt class="col-sm-5">City:</dt>
                        <dd class="col-sm-7"><?php echo e($user->city ?? ''); ?></dd>

                        <dt class="col-sm-5">Postal Code:</dt>
                        <dd class="col-sm-7"><?php echo e($user->postalcode ?? ''); ?></dd>

                        <dt class="col-sm-5">Billing Phone Number:</dt>
                        <dd class="col-sm-7"><?php echo e($user->billing_phonenumber ?? ''); ?></dd>

                        <dt class="col-sm-5">Role:</dt>
                        <dd class="col-sm-7"><span class="badge badge-primary text-white"><?php echo e($role->role ?? ''); ?></span></dd> 
                    </dl>
                </div>
            </div>
        </div>
        <div class="col-12 col-md-6 mt-3">
            <div class="card">
                <div class="card-header  justify-content-between align-items-center">                               
                    <h4 class="card-title">Card Details</h4> 
                </div>
                <div class="card-body">
                    <dl class="row mb-0 redial-line-height-2_5">
                        <dt class="col-sm-5">Owner :</dt>
                        <dd class="col-sm-7"><?php echo e($user_card->owner ?? ''); ?></dd>
                        
                        <dt class="col-sm-5">Card Number :</dt>
                        <dd class="col-sm-7"><?php echo e($user_card->cardNumber ?? ''); ?></dd>

                        <dt class="col-sm-5">CVV :</dt>
                        <dd class="col-sm-7"><?php echo e($user_card->cvv ?? ''); ?></dd>

                        <dt class="col-sm-5">Expiration Month :</dt>
                        <dd class="col-sm-7"><?php echo e($user_card->expiration_month ?? ''); ?></dd>

                        <dt class="col-sm-5">Expiration Year :</dt>
                        <dd class="col-sm-7"><?php echo e($user_card->expiration_year ?? ''); ?></dd>

                        <dt class="col-sm-5">Email :</dt>
                        <dd class="col-sm-7"><?php echo e($user_card->customer_email ?? ''); ?></dd>

                        <dt class="col-sm-5">Merchant :</dt>
                        <dd class="col-sm-7"><?php echo e($user_card->merchant ?? ''); ?></dd>
                    </dl>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u498385541/domains/markvaulting.org/public_html/portal/resources/views/admin/users/show.blade.php ENDPATH**/ ?>