
<?php $__env->startSection('title', 'Orders'); ?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb-title'); ?>
    <h3><?php echo e(__('Brand Edit')); ?></h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb-items'); ?>
    <li class="breadcrumb-item"><i class="icon-home mr-1"></i></li>
    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.orders.index')); ?>"><?php echo e(__('Orders')); ?></a></li>
    <li class="breadcrumb-item active"><?php echo e(__('Edit')); ?></li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12 mt-4">
            <a class = "btn btn-info float-right" href = "<?php echo e(route('admin.orders.index')); ?>">Back</a>
        </div>
        <div class="col-12 mt-4">
            <div class="card">
                <div class="card-header">
                    <h6 class="card-title"><?php echo e('Order# ' . $order->order_number); ?></h6>
                    <?php if(!is_null($order->payment_link)): ?>
                        <a class = "btn btn-warning btn-s float-right mx-3" style="color: #fff;"
                            href = "<?php echo e($order->payment_link); ?>" target = "_blank">Payment Link</a>
                    <?php endif; ?>
                </div>
                <div class="card-content">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-12">
                                <form action = "<?php echo e(route('admin.orders.update', ['id' => $order->id])); ?>" method = "POST"
                                    id = "order-form" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-row">
                                        <div class="form-group col-md-6">
                                            <label for="inputEmail4">Payment Type</label>
                                            <select class="form-control" name="payment_type" id="sale_status" required=""
                                                onchange = "select_payment_type(this.value)">
                                                <option value="" selected="" disabled="">Please choose an option
                                                </option>
                                                <option value="1" <?php echo e($order->payment_type == '1' ? 'selected' : ''); ?>>
                                                    New
                                                    Payment</option>
                                                <option value="2" <?php echo e($order->payment_type == '2' ? 'selected' : ''); ?>>
                                                    Up-Sale Payment</option>
                                            </select>
                                        </div>
                                        <div class="form-group col-md-6" id = "order_id_container">
                                            <label for="inputPassword4">Order ID *</label>
                                            <input type="text" name="order_id" id="order_id" class = "form-control"
                                                value = "<?php echo e($order->order_number); ?>" readonly>
                                        </div>
                                    </div>


                                    <div class="form-row">
                                        <div class="form-group col-md-6">
                                            <label for="inputEmail4">Amount *</label>
                                            <input type="number" class="form-control" name="sale_amount" id="sale_amount"
                                                required="" min="1" value = "<?php echo e($order->sale_amount ?? ''); ?>">
                                        </div>
                                        <div class="form-group col-md-6">
                                            <label for="inputPassword4">Currency *</label>
                                            <select class="form-control" name="sale_currency">
                                                <option value="USD"
                                                    <?php echo e($order->sale_currency == 'USD' ? 'selected' : ''); ?>>
                                                    USD</option>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="form-row">
                                        <div class="form-group col-md-12">
                                            <label for="inputEmail4">Description *</label>
                                            <textarea name="description" class="form-control" cols="60" rows="3"><?php echo e($order->description ?? ''); ?></textarea>
                                        </div>
                                    </div>

                                    <div class="form-row">
                                        <div class="form-group col-md-6">
                                            <input type = "hidden" name = "brand_name" value = "<?php echo e($order->brand_name); ?>">
                                            <label for="inputEmail4">Brand Name *</label>
                                            <select class="form-control brand-select" name = "brand_name" required disabled>
                                                <option value = "">Select Brand</option>
                                                <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value = "<?php echo e($brand->id); ?>"
                                                        <?php echo e($order->brand_name == $brand->id ? 'selected' : ''); ?>

                                                        data-img = "<?php echo e(asset($brand->logo)); ?>">
                                                        <?php echo e($brand->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="form-group col-md-6 logo-section">
                                            <label for="inputPassword4">Brand Logo</label>
                                            <img src="<?php echo e(asset($brand->logo)); ?>" width="100"
                                                id="brand_logo" class = "d-block">
                                        </div>
                                    </div>

                                    <div class="form-row packages border p-3 mb-3">
                                        <div class="col-md-12">
                                            <h4>
                                                Select Package
                                            </h4>
                                        </div>
                                        <?php
                                            $order_packages = $order->order_packages->pluck('package_id')->toArray();
                                        ?>

                                        <?php $__currentLoopData = $brand_packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="col-md-4">
                                                <input type="checkbox" id="pack<?php echo e($package->id); ?>" name="packages[]"
                                                    value="<?php echo e($package->id); ?>"
                                                    <?php echo e(in_array($package->id, $order_packages) ? 'checked' : ''); ?>>
                                                <label for="pack<?php echo e($package->id); ?>"><?php echo e($package->package_name); ?></label>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </div>

                                    <div class="form-row">
                                        <div class="form-group col-md-6">
                                            <label for="inputEmail4">Sales person email *</label>
                                            <input type="email" class="form-control" name="sales_email" id="sales_email"
                                                required="" value = "<?php echo e($order->sales_email); ?>" readonly>
                                        </div>
                                        <div class="form-group col-md-6">
                                            <label>Customer email *</label>
                                            <input type="email" class="form-control" name="customer_email"
                                                id="customer_email" required=""
                                                value = "<?php echo e($order->customer_email); ?>" readonly>
                                        </div>
                                    </div>

                                    <div class="form-row">
                                        <div class="form-group col-md-12">
                                            <button type="submit" class = "btn btn-primary">Submit</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function() {
            $('#order-form').validate({
                rules: {
                    name: 'required',
                    description: 'required',
                    logo: {
                        required: true,
                        extension: "jpg|jpeg|png|bmp"
                    },
                    link: 'required',
                    merchants: 'required'
                }
            })
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u498385541/domains/markvaulting.org/public_html/portal/resources/views/admin/orders/edit.blade.php ENDPATH**/ ?>