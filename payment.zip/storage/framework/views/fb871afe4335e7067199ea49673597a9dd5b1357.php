
<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row vh-100 justify-content-between align-items-center">
            <div class="col-12">
                <div class="lockscreen mt-5 mb-5">
                    <div class="jumbotron mb-0 text-center theme-background rounded">
                        <h1 class="display-3 font-weight-bold">500</h1>
                        <h5><i class="ion ion-alert pr-2"></i>Oops! Link Expired</h5>
                        <p>The link you used is no longer valid. If you believe this is an error, please contact support.</p>
                        <a href="<?php echo e(route('orders.request_payment_link', ['id' => $order->id])); ?>" class="btn btn-primary">Request Another Link</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\square_terminal\resources\views/errors/500.blade.php ENDPATH**/ ?>