<!-- START: Footer-->
    <footer class="site-footer">
        <?php echo e(date('Y')); ?> © <?php echo e(env('APP_NAME')); ?>

    </footer>
<!-- END: Footer-->
<?php /**PATH D:\xampp-8\htdocs\terminal\resources\views/admin/layout/footer.blade.php ENDPATH**/ ?>