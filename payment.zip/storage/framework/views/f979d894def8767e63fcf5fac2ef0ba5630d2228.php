<?php
    $currencies = json_decode($brand->currency);
?>

<?php $__currentLoopData = $currencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $currency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <option value="<?php echo e($currency); ?>"> <?php echo e($currency); ?></option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH D:\xampp\htdocs\dtek_payment_terminal\resources\views/ajax/currency.blade.php ENDPATH**/ ?>