
<?php $__env->startSection('title', 'Brands'); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb-title'); ?>
    <h3><?php echo e(__('Brands')); ?></h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb-items'); ?>
    <li class="breadcrumb-item"><i class="icon-home mr-1"></i></li>
    <li class="breadcrumb-item active"><?php echo e(__('Brands')); ?></li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12 mt-3">
            <div class="card">
                <div class="card-header  justify-content-between align-items-center">
                    <h4 class="card-title">Brands</h4>
                    <a class = "btn btn-info float-right" href = "<?php echo e(route('admin.brands.create')); ?>"><i
                            class = "icon-plus"></i> Create</a>
                    
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table id="example" class="display table dataTable table-striped table-bordered">
                            <thead>
                                <tr>
                                    
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>Logo</th>
                                    <th>Link</th>
                                    <th>Status</th>
                                    <th>Packages</th>
                                    <th>Merchants</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        
                                        <td><?php echo e($brand->id); ?></td>
                                        <td><?php echo e($brand->name); ?></td>
                                        <td><img src = "<?php echo e(asset($brand->logo)); ?>" class = "w-50"></td>
                                        <td><a href = "<?php echo e($brand->link); ?>" target = "_blank"><?php echo e($brand->link); ?></a></td>
                                        <td>
                                            <?php if($brand->status == 'active'): ?>
                                                <span class = "badge badge-primary">Active</span>
                                            <?php else: ?>
                                                <span class = "badge badge-warning">Inactive</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <a class="btn btn-info"
                                                href="<?php echo e(route('brand.packages.edit')); ?>?brand=<?php echo e($brand->id); ?>">Packages</a>
                                        </td>
                                        <td>
                                            <a class="btn btn-info"
                                                href="<?php echo e(route('brand.merchants.edit')); ?>?brand=<?php echo e($brand->id); ?>">Merchants</a>
                                        </td>
                                        <td>
                                            <a href = "<?php echo e(route('admin.brands.edit', ['id' => $brand->id])); ?>"><i
                                                    class = "icon-pencil"></i></a>
                                            <a class = "delete_confirmation"
                                                href = "<?php echo e(route('admin.brands.destroy', ['id' => $brand->id])); ?>"><i
                                                    class = "icon-trash"></i></a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                </div>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u498385541/domains/markvaulting.org/public_html/portal/resources/views/admin/brands/index.blade.php ENDPATH**/ ?>