<link rel="shortcut icon" href="<?php echo e(asset('admin/dist/images/favicon.ico')); ?>" />
<meta name="viewport" content="width=device-width,initial-scale=1">
<?php /**PATH D:\xampp-8\htdocs\terminal\resources\views/admin/layout/meta.blade.php ENDPATH**/ ?>