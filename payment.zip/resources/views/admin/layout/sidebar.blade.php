<!-- START: Main Menu-->
@php
    $user = App\Models\Adminiy::find(Auth::guard('adminiy')->user()->id);
@endphp
<div class="sidebar">
    <div class="site-width">
        <!-- START: Menu-->
        <ul id="side-menu" class="sidebar-menu">
            <li class="dropdown"><a href="{{ route('dashboard') }}"><i class="icon-home mr-1"></i> Dashboard</a>
                <ul>
                    <li><a href="{{ route('dashboard') }}"><i class="icon-speedometer"></i> Dashboard</a></li>
                </ul>
            </li>
            @if ($user->has_permission(4) || $user->role_id == 1)
                <li class="dropdown"><a href="#"><i class="icon-tag mr-1"></i> Brand
                        Management</a>
                    <ul>
                        <li><a href="{{ route('admin.brands.index') }}"><i class="icon-briefcase"></i>All
                                Brands</a></li>
                        {{-- <li><a href=""><i class="icon-support"></i>Unpaid Inquiry</a></li>
                            <li><a href=""><i class="icon-support"></i>Contact Inquiry</a></li> --}}
                    </ul>
                </li>
            @endif
            @if ($user->has_permission(7) || $user->role_id == 1)
                {{-- <li class="dropdown"><a href="#"><i class="icon-organization mr-1"></i> Package Management</a>
                    <ul>
                        <li><a href="{{ route('packages') }}"><i class="icon-envelope"></i>Packages</a></li>
                    </ul>
                </li> --}}
            @endif
            <li class="dropdown"><a href="#"><i class="icon-basket mr-1"></i> Order Management</a>

                <ul>
                    @if ($user->has_permission(1) || $user->role_id == 1)
                        <li><a href="{{ route('payment.create_order') }}"><i class="icon-plus"></i>Create
                                Order</a></li>
                    @endif
                    @if ($user->has_permission(2) || $user->role_id == 1)
                        <li><a href="{{ route('admin.orders.index') }}"><i class="icon-list"></i>Orders</a>
                        </li>
                    @endif
                    @if ($user->has_permission(3) || $user->role_id == 1)
                        <li><a href="{{ route('admin.transactions.index') }}"><i
                                    class="icon-credit-card"></i>Transactions</a></li>
                    @endif
                    @if ($user->has_permission(6) || $user->role_id == 1)
                        <li><a href="{{ route('admin.payments-recuring.index') }}"><i class="icon-refresh"></i>Payment
                                Recurring</a></li>
                    @endif
                </ul>

            </li>
            @if ($user->has_permission(5) || $user->role_id == 1)
                <li class="dropdown"><a href="#"><i class="icon-people mr-1"></i> User
                        Management</a>
                    <ul>
                        <li><a href="{{ route('users') }}"><i class="icon-user"></i>Users</a></li>
                        @if($user->id == 1)
                        <li><a href="{{ route('admins.list') }}"><i class="icon-user"></i>Admins</a></li>
                        @endif
                    </ul>
                </li>
            @endif
            {{--
                <li class="dropdown"><a href="#"><i class="icon-organization mr-1"></i> Settings</a>
                    
                    <ul>
                        <li><a href="{{ route('settings') }}"><i class="icon-gears"></i>Packages</a></li>
                    </ul>
                </li>
                --}}
            {{--
                <li class="dropdown"><a href="#"><i class="icon-layers mr-1"></i> Web Apps</a>                  
                    <ul>
                        <li><a href="app-calendar.html"><i class="icon-calendar"></i> Calendar</a></li>
                        <li><a href="app-chat.html"><i class="icon-speech"></i> Chats</a></li>
                        <li><a href="app-to-do.html"><i class="icon-support"></i> Todo</a></li> 
                        <li><a href="app-mail.html"><i class="icon-envelope"></i>Mailapp</a></li>
                        <li><a href="app-filemanager.html"><i class="icon-folder"></i> File Manager</a></li>
                        <li><a href="app-contactlist.html"><i class="icon-people"></i> Contact List</a></li>
                        <li><a href="app-taskboard.html"><i class="icon-event"></i> Task Board</a></li>
                        <li><a href="app-notes.html"><i class="icon-tag"></i> Notes</a></li> 
                        <li><a href="app-invoicelist.html"><i class="icon-book-open"></i> Invoices</a></li>
                    </ul>                   
                </li>
                --}}
        </ul>
        <!-- END: Menu-->

    </div>
</div>
<!-- END: Main Menu-->
