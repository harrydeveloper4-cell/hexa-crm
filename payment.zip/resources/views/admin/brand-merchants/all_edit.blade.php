@extends('admin.layout.master')
@section('title', 'Merchants')

@section('css')
@endsection

@section('breadcrumb-title')
    <h3>{{ __('Merchants Edit') }} ({{ ucfirst($brand->name) }})</h3>
@endsection

@section('breadcrumb-items')
    <li class="breadcrumb-item"><i class="icon-home mr-1"></i></li>
    <li class="breadcrumb-item"><a href="{{ route('admin.brands.index') }}">{{ __('Brands') }}</a></li>
    <li class="breadcrumb-item active">{{ __( ' Merchants Edit') }}</li>
@endsection
@section('content')
    <div class="row">
        <div class="col-12 mt-4">
            <a class = "btn btn-info float-right" href = "{{ route('admin.brands.index') }}">Back</a>
        </div>
        <div class="col-12 mt-4">
            <div class="card">
                {{-- <div class="card-header">
                    <h6 class="card-title">Edit</h6>
                </div> --}}
                <div class="card-content">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-12">
                                <form action="{{ route('merchants.update.all') }}" method="POST" id="package-form">
                                    @csrf
                                    <input type="hidden" class="form-control rounded" name="brand"
                                        value="{{ $brand->id }}">

                                        @if (count($brand_merchants) > 0)
                                        @foreach ($brand_merchants as $merchant)
                                            <div class="form-row border p-3 m-3">
                                                <div class="form-group col-md-10">
                                                    <label for="inputEmail4">Merchant</label>
                                                    <select class="form-control rounded merchant-select"
                                                        name = "old_merchant[{{ $merchant->id }}]">
                                                        <option value = "" disabled>Select Merchant</option>
                                                        @foreach ($merchants as $key => $merch)
                                                            <option value = "{{ $merch->id }}"
                                                                {{ $merch->id == $merchant->merchant_id ? 'selected' : '' }}>
                                                                {{ $merch->merchant }}</option>
                                                        @endforeach
                                                    </select>

                                                    <div class="top-hide"> <input type="text" placeholder="Enter custom name of the merchant" class="form-control" name="title[]" value="{{$merchant->title}}" required=""> </div>
                                                </div>
                                                <div class="form-group col-md-2">
                                                    <button type = "button" class = "btn btn-sm btn-danger delete-row"
                                                        data-href = "{{ route('delete.brand.merchant', ['id' => $merchant->id]) }}"
                                                        value = "{{ $merchant->id }}"><i class = "icon-trash"></i></button>
                                                    <input type="checkbox" value = "{{ $merchant->id }}"
                                                        class = "change_status"
                                                        {{ $merchant->status == 'active' ? 'checked' : '' }}
                                                        data-toggle="toggle" data-on="Active" data-off="Inactive"
                                                        data-href = "{{ route('merchant.status.change', ['id' => $merchant->id]) }}">
                                                </div>
                                                @php

                                                    $config_keys = json_decode(
                                                        get_merchant_keys($brand->id, $merchant->merchant_id),
                                                    );
                                                @endphp
                                                @if ($merchant->merchant_id == 1) {{-- Paypal --}}
                                                    <div class="form-group col-md-6 rm">
                                                        <label for="inputEmail4">Client Id</label>
                                                        <input type="text" class="form-control rounded"
                                                            name="config_key[{{ $merchant->merchant_id }}][client_id]"
                                                            placeholder="Client Id"
                                                            value="{{ $config_keys->client_id ?? '' }}">
                                                    </div>
                                                    <div class="form-group col-md-6 rm">
                                                        <label for="inputEmail4">Secret Key</label>
                                                        <input type="text" class="form-control rounded"
                                                            name="config_key[{{ $merchant->merchant_id }}][secret_key]"
                                                            placeholder="Secret Key"
                                                            value="{{ $config_keys->secret_key ?? '' }}">
                                                    </div>
                                                @elseif($merchant->merchant_id == 2) {{-- Stripe --}}
                                                    <div class="form-group col-md-6 rm">
                                                        <label for="inputEmail4">Stripe Key</label>
                                                        <input type="text" class="form-control rounded"
                                                            name="config_key[{{ $merchant->merchant_id }}][stripe_key]"
                                                            placeholder="Stripe Key"
                                                            value="{{ $config_keys->stripe_key ?? '' }}">
                                                    </div>
                                                    <div class="form-group col-md-6 rm">
                                                        <label for="inputEmail4">Secret Key</label>
                                                        <input type="text" class="form-control rounded"
                                                            name="config_key[{{ $merchant->merchant_id }}][stripe_secret_key]"
                                                            placeholder="Secret Key"
                                                            value="{{ $config_keys->stripe_secret_key ?? '' }}">
                                                    </div>
                                                @elseif($merchant->merchant_id == 3) {{-- Square --}}
                                                    <div class="form-group col-md-4 rm">
                                                        <label for="inputEmail4">App Id</label>
                                                        <input type="text" class="form-control rounded"
                                                            name="config_key[{{ $merchant->merchant_id }}][app_id]"
                                                            placeholder="App Id"
                                                            value="{{ $config_keys->app_id ?? '' }}">
                                                    </div>
                                                    <div class="form-group col-md-4">
                                                        <label for="inputEmail4">Access Token</label>
                                                        <input type="text" class="form-control rounded"
                                                            name="config_key[{{ $merchant->merchant_id }}][access_token]"
                                                            placeholder="Access Token"
                                                            value="{{ $config_keys->access_token ?? '' }}">
                                                    </div>
                                                    <div class="form-group col-md-4 rm">
                                                        <label for="inputEmail4">Location Id</label>
                                                        <input type="text" class="form-control rounded"
                                                            name="config_key[{{ $merchant->merchant_id }}][location_id]"
                                                            placeholder="Location Id"
                                                            value="{{ $config_keys->location_id ?? '' }}">
                                                    </div>
                                                @elseif($merchant->merchant_id == 4) {{-- Authorize.Net --}}
                                                    <div class="form-group col-md-6 rm">
                                                        <label for="inputEmail4">Merchant Login Id</label>
                                                        <input type="text" class="form-control rounded"
                                                            name="config_key[{{ $merchant->merchant_id }}][merchant_login_id]"
                                                            placeholder="Merchant Login Id"
                                                            value="{{ $config_keys->merchant_login_id ?? '' }}">
                                                    </div>
                                                    <div class="form-group col-md-6 rm">
                                                        <label for="inputEmail4">Merchant Transaction Key</label>
                                                        <input type="text" class="form-control rounded"
                                                            name="config_key[{{ $merchant->merchant_id }}][merchant_transaction_key]"
                                                            placeholder="Merchant Transaction Key"
                                                            value="{{ $config_keys->merchant_transaction_key ?? '' }}">
                                                    </div>
                                                    @elseif($merchant->merchant_id == 5) {{-- Rapyd.Net --}}
                                                        <div class="form-group col-md-6 rm">
                                                            <label for="inputEmail4">Access Key</label>
                                                            <input type="text" class="form-control rounded"
                                                                name="config_key[{{ $merchant->merchant_id }}][access_key]"
                                                                placeholder="Access Key"
                                                                value="{{ $config_keys->access_key ?? '' }}">
                                                        </div>
                                                        <div class="form-group col-md-6 rm">
                                                            <label for="inputEmail4">Secret Key</label>
                                                            <input type="text" class="form-control rounded"
                                                                name="config_key[{{ $merchant->merchant_id }}][secret_key]"
                                                                placeholder="Secret Key"
                                                                value="{{ $config_keys->secret_key ?? '' }}">
                                                        </div>
                                                    @elseif($merchant->merchant_id == 6) {{-- Chase --}}
                                                        <div class="form-group col-md-6 rm">
                                                            <label for="inputEmail4">Client ID</label>
                                                            <input type="text" class="form-control rounded"
                                                                name="config_key[{{ $merchant->merchant_id }}][client_id]"
                                                                placeholder="Client ID"
                                                                value="{{ $config_keys->client_id ?? '' }}">
                                                        </div>
                                                        <div class="form-group col-md-6 rm">
                                                            <label for="inputEmail4">Client Secret</label>
                                                            <input type="text" class="form-control rounded"
                                                                name="config_key[{{ $merchant->merchant_id }}][client_secret]"
                                                                placeholder="Client Secret"
                                                                value="{{ $config_keys->client_secret ?? '' }}">
                                                        </div>
                                                    @endif


                                            </div>
                                        @endforeach
                                    @endif

                                    <div class="form-row m-3">
                                        <div class="form-group col-md-12">
                                            <button type="button" class="btn btn-sm btn-primary add-row"><i
                                                    class="icon-plus"></i></button>
                                        </div>
                                    </div>

                                    <div class="form-row m-3">
                                        <input type="submit" value="Save" class="btn btn-primary">
                                    </div>
                                </form>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('scripts')
<style>
    .top-hide {
        padding-top: 20px;
    }
</style>
    <script>
        $(document).ready(function() {
            $('#merchant-form').validate({
                rules: {
                    brand: 'required'
                }
            })


        })
    </script>
    <script type="text/javascript">
    
    $(document).ready(function() {
        // Function to refresh available options across all dropdowns
        function refreshMarchentOptions() {
            const selectedPlayers = [];

            // Collect all selected values
            $('.merchant-select').each(function() {
                const selectedValues = $(this).val();
                if (selectedValues) {
                    selectedPlayers.push(...selectedValues);
                }
            });

            // Update options in all dropdowns
            $('.merchant-select').each(function() {
                const $dropdown = $(this);
                const currentSelection = $dropdown.val() || [];

                // Reset dropdown options
                $dropdown.find('option').each(function() {
                    const $option = $(this);
                    const marchentId = $option.val();
                    
                    // Disable options already selected in other dropdowns
                    // if (selectedPlayers.includes(marchentId) && !currentSelection.includes(marchentId)) {
                    //     $option.prop('disabled', true);
                    // } else {
                    //     $option.prop('disabled', false);
                    // }
                });

                // Refresh Select2 rendering
                $dropdown.trigger('change.select2');
            });
        }
        
        function select2() {
            $(".merchant-select").select2();
            firstOptionDisabled();
        }
        function firstOptionDisabled() {
            setTimeout(function(){
                $('.merchant-select option[value=""]').prop('disabled', true);
            }, 200);
        }
        // add row
        let merchant_field = '';
        merchant_field += '<select class="form-control rounded merchant-select" name = "merchant[]">';
        merchant_field += '<option value = "" disabled selected>Select Merchant</option>'
        @foreach ($merchants as $key => $merchant)
            merchant_field += '<option value = "{{ $merchant->id }}">{{ $merchant->merchant }}</option>';
        @endforeach
        merchant_field += '</select>';

        $(document).on('click', '.add-row', function() {
            var html =
                '<div class="form-row border p-3 m-3"> <div class="form-group col-md-10"><label for="inputEmail4">Merchant</label> ' +
                merchant_field +  '<div class="top-hide"> <input type="text" placeholder="Enter custom name of the merchant" class="form-control" name="title[]" required /> </div>' +
                '</div><div class="form-group col-md-2"> <label for="inputEmail4"></label> <button type="button" class="btn btn-sm btn-danger remove-row" value=""><i class="icon-minus"></i></button> </div></div>';
            // $('#form-row').prepend(html);
            $(this).closest('.form-row').before(html);
            select2();
            refreshMarchentOptions();
        });
        // remove row
        $(document).on('click', '.remove-row', function() {
            $(this).closest('.form-row').remove();
            refreshMarchentOptions();
            firstOptionDisabled();
        });
        $(document).on('click', '.delete-row', function(e) {
            e.preventDefault();
            let element = $(this);
            let url = $(this).data('href');

            swal({
                title: "{{ __('Are you sure?') }}",
                text: "{{ __('Once deleted, you will not be able to recover this!') }}",
                icon: "warning",
                buttons: true,
                dangerMode: true,
            }).then((willDelete) => {
                if (willDelete) {
                    $.ajax({
                        url: url,
                        type: 'GET',
                        success: function(data) {
                            element.closest('.form-row').remove();
                            swal("{{ __('Deleted successfully!') }}", {
                                icon: "success",
                                timer: 2000,
                            });
                        },
                        error: function(err) {
                            swal("{{ __('Merchant could not be removed') }}", {
                                icon: "error",
                                timer: 2000,
                            });
                        }
                    });
                } else {
                    swal("{{ __('Your data is safe!') }}", {
                        icon: "info",
                        timer: 2000,
                    });
                }
            });
            refreshMarchentOptions();
            firstOptionDisabled();
        });
        $(document).on('change', '.change_status', function() {
            let element = $(this);
            let status = '';
            let url = element.data('href')
            if (element.is(':checked')) {
                status = 'active';
            } else {
                status = 'inactive';
            }
            $.ajax({
                url: url,
                type: 'GET',
                data: {
                    status: status
                },
                success: function(data) {

                },
                error: function(err) {
                    alert('Merchant status could not changed');
                }
            })
        })
        $(document).on('change', '.merchant-select', function() {
            let merchant = $(this).val();
            $(this).parent().siblings(".rm").remove();
            if (merchant == 1) {
                $(this).closest('.form-row').append(
                    '<div class="form-group col-md-6 rm"> <label for="inputEmail4">Client Id</label> <input type="text" class="form-control rounded" name="config_key[' +
                    merchant +
                    '][client_id]" placeholder="Client Id" value="" > </div><div class="form-group col-md-6 rm"> <label for="inputEmail4">Secret Key</label> <input type="text" class="form-control rounded" name="config_key[' +
                    merchant + '][secret_key]" placeholder="Secret Key" value="" > </div>')
            } else if (merchant == 2) {
                $(this).closest('.form-row').append(
                    '<div class="form-group col-md-6 rm"> <label for="inputEmail4">Stripe Key</label> <input type="text" class="form-control rounded" name="config_key[' +
                    merchant +
                    '][stripe_key]" placeholder="Stripe Key" value="" > </div><div class="form-group col-md-6 rm"> <label for="inputEmail4">Secret Key</label> <input type="text" class="form-control rounded" name="config_key[' +
                    merchant + '][stripe_secret_key]" placeholder="Secret Key" value="" > </div>')
            } else if (merchant == 3) {
                $(this).closest('.form-row').append(
                    '<div class="form-group col-md-4 rm"> <label for="inputEmail4">App Id</label> <input type="text" class="form-control rounded" name="config_key[' +
                    merchant +
                    '][app_id]" placeholder="App Id" value="" > </div><div class="form-group col-md-4 rm"> <label for="inputEmail4">Access Token</label> <input type="text" class="form-control rounded" name="config_key[' +
                    merchant +
                    '][access_token]" placeholder="Access Token" value="" > </div><div class="form-group col-md-4 rm"> <label for="inputEmail4">Location Id</label> <input type="text" class="form-control rounded" name="config_key[' +
                    merchant + '][location_id]" placeholder="Location Id" value="" > </div>')
            } else if (merchant == 4) {
                $(this).closest('.form-row').append(
                    ' <div class="form-group col-md-6 rm"> <label for="inputEmail4">Merchant Login Id</label> <input type="text" class="form-control rounded" name="config_key[' +
                    merchant +
                    '][merchant_login_id]" placeholder="Merchant Login Id" value="" > </div><div class="form-group col-md-6 rm"> <label for="inputEmail4">Merchant Transaction Key</label> <input type="text" class="form-control rounded" name="config_key[' +
                    merchant +
                    '][merchant_transaction_key]" placeholder="Merchant Transaction Key" value="" > </div>')
            } else if (merchant == 5) {
                $(this).closest('.form-row').append(
                    '<div class="form-group col-md-6 rm"> <label for="inputEmail4">Access Key</label> <input type="text" class="form-control rounded" name="config_key[' +
                    merchant +
                    '][access_key]" placeholder="Access Key" value="" > </div><div class="form-group col-md-6 rm"> <label for="inputEmail4">Secret Key</label> <input type="text" class="form-control rounded" name="config_key[' +
                    merchant + '][secret_key]" placeholder="Secret Key" value="" > </div>')
            } else if (merchant == 6) {
                $(this).closest('.form-row').append(
                    '<div class="form-group col-md-6 rm"> <label for="inputEmail4">Client ID</label> <input type="text" class="form-control rounded" name="config_key[' +
                    merchant +
                    '][client_id]" placeholder="Client ID" value="" > </div><div class="form-group col-md-6 rm"> <label for="inputEmail4">Client Secret</label> <input type="text" class="form-control rounded" name="config_key[' +
                    merchant + '][client_secret]" placeholder="Client Secret" value="" > </div>')
            } else {
                $(this).parent().siblings(".form-group").remove();
            }
            refreshMarchentOptions();
        });
        
        // Attach event listener to update options when selection changes
        // $('.merchant-select').on('change', refreshMarchentOptions);
        // Load on page
        refreshMarchentOptions();
        select2();
    })
    </script>
@endsection
