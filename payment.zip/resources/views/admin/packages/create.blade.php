@extends('admin.layout.master')
@section('title', 'Packages')

@section('css')
@endsection

@section('breadcrumb-title')
    <h3>{{ __('Create') }}</h3>
@endsection

@section('breadcrumb-items')
    <li class="breadcrumb-item"><a href="{{ route('packages') }}">{{ __('Packages') }}</a></li>
    <li class="breadcrumb-item active">{{ __('Create') }}</li>
@endsection

@section('content')
    <div class="row">
        <div class="col-12 mt-4">
            <div class="card">
                <div class="card-header">
                    <h6 class="card-title">Package Create</h6>
                    <a class = "btn btn-info btn-xs float-right" href = "{{ route('packages') }}">Back</a>
                </div>
                <div class="card-content">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-12">
                                <form action = "{{ route('packages.store') }}" method = "POST" id = "package-form">
                                    @csrf
                                    <div class="form-row">
                                        <div class="form-group col-md-12">
                                            <label for="inputEmail4">Brand</label>
                                            <select class="form-control rounded" name = "brand">
                                                <option value = "">Select Brand</option>
                                                @foreach ($brands as $brand)
                                                    <option value = "{{ $brand->id }}">{{ $brand->name }}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>
                                    <div id = "append-row">
                                        <div class="form-row">
                                            <div class="form-group col-md-10">
                                                <label for="inputEmail4">Package Name</label>
                                                <input type="text" class="form-control rounded" name = "package_name[]"
                                                    id="inputEmail4" placeholder="Package Name" value = "">
                                            </div>
                                            <div class="form-group col-md-4" style = "display:none">
                                                <label for="inputEmail4">Price</label>
                                                <input type="text" class="form-control rounded" name = "package_price[]"
                                                    id="inputEmail4" placeholder="Package Price" value = "">
                                            </div>

                                            <div class="form-group col-md-2">
                                                <label for="inputEmail4"></label>
                                                <button type = "button" class = "btn btn-sm btn-primary add-row"><i
                                                        class = "icon-plus"></i></button>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="form-row">
                                        <input type="submit" value = "Save" class = "btn btn-primary">
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
@section('scripts')
    <script>
        $(document).ready(function() {
            $('#package-form').validate({
                rules: {
                    brand: 'required',
                    'package_name[]': 'required'

                }
            })


        })
    </script>

    <script type="text/javascript">
        // add row
        $(document).on('click', '.add-row', function() {
            var html =
                '<div class="form-row"> <div class="form-group col-md-10"> <label for="inputEmail4">Package Name</label> <input type="text" class="form-control rounded" name="package_name[]" id="inputEmail4" placeholder="Package Name" value="" > </div><div class="form-group col-md-4" style="display:none"> <label for="inputEmail4">Price</label> <input type="text" class="form-control rounded" name="package_price[]" id="inputEmail4" placeholder="Package Price" value="" > </div><div class="form-group col-md-2"> <label for="inputEmail4"></label> <button type="button" class="btn btn-sm btn-primary add-row"><i class="icon-plus"></i></button> <button type="button" class="btn btn-sm btn-danger remove-row" value=""><i class="icon-minus"></i></button> </div>';
            $('#append-row').append(html);
        });

        // remove row
        $(document).on('click', '.remove-row', function() {
            $(this).closest('.form-row').remove();
        });
    </script>
@endsection
