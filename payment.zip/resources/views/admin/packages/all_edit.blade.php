@extends('admin.layout.master')
@section('title', 'Packages')

@section('css')
@endsection

@section('breadcrumb-title')
    <h3>{{ __('Packages Edit') }}</h3>
@endsection

@section('breadcrumb-items')
    <li class="breadcrumb-item"><a href="{{ route('admin.brands.index') }}">{{ __('Brands') }}</a></li>
    <li class="breadcrumb-item active">{{ __('Packages Edit') }}</li>
@endsection
@section('content')
    <div class="row">
        <div class="col-12 mt-4">
            <div class="card">
                <div class="card-header">
                    <h6 class="card-title">Package Edit</h6>
                    <a class = "btn btn-info float-right" href = "{{ route('admin.brands.index') }}">Back</a>
                </div>
                <div class="card-content">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-12">
                                <form action="{{ route('packages.update.all') }}" method="POST" id="package-form">
                                    @csrf
                                    <input type="hidden" class="form-control rounded" name="brand"
                                        value="{{ $brand }}">

                                    @foreach ($packages as $package)
                                        <div class="form-row">
                                            <div class="form-group col-md-10">
                                                <label for="inputEmail4">Package Name</label>
                                                <input type="text" class="form-control rounded"
                                                    name="old_package_name[{{ $package->id }}]" id="inputEmail4"
                                                    placeholder="Package Name" value="{{ $package->package_name ?? '' }}">
                                                <!-- Display validation error for old_package_name -->
                                                @error("old_package_name.{{ $package->id }}")
                                                    <div class="text-danger">{{ $message }}</div>
                                                @enderror
                                            </div>
                                            <div class="form-group col-md-4" style="display:none">
                                                <label for="inputEmail4">Price</label>
                                                <input type="text" class="form-control rounded"
                                                    name="old_package_price[]" id="inputEmail4" placeholder="Package Price"
                                                    value="">
                                            </div>

                                            <div class="form-group col-md-2">
                                                <button type="button"
                                                    data-href="{{ route('delete.brand.package', ['id' => $package->id]) }}"
                                                    class="btn btn-sm btn-danger delete-row" value="{{ $package->id }}"><i
                                                        class="icon-trash"></i></button>
                                                <input type="checkbox" value="{{ $package->id }}" class="change_status"
                                                    {{ $package->status == 'active' ? 'checked' : '' }}
                                                    data-toggle="toggle" data-on="Active" data-off="Inactive"
                                                    data-href="{{ route('package.status.change', ['id' => $package->id]) }}">
                                            </div>
                                        </div>
                                    @endforeach

                                    <div class="form-row">
                                        <div class="form-group col-md-12">
                                            <button type="button" class="btn btn-sm btn-primary add-row"><i
                                                    class="icon-plus"></i></button>
                                        </div>
                                    </div>
                                    <div id="append-row">
                                        @if (isset($packages) && count($packages) == 0)
                                            <div class="form-row">
                                                <div class="form-group col-md-10">
                                                    <label for="inputEmail4">Package Name</label>
                                                    <input type="text" class="form-control rounded" name="package_name[]"
                                                        id="inputEmail4" placeholder="Package Name" value="">
                                                    <!-- Display validation error for package_name -->
                                                </div>
                                                <div class="form-group col-md-4" style="display:none">
                                                    <label for="inputEmail4">Price</label>
                                                    <input type="text" class="form-control rounded"
                                                        name="package_price[]" id="inputEmail4" placeholder="Package Price"
                                                        value="">
                                                </div>
                                                <div class="form-group col-md-2">
                                                    <label for="inputEmail4"></label>
                                                    <button type="button" class="btn btn-sm btn-danger remove-row"
                                                        value=""><i class="icon-minus"></i></button>
                                                </div>
                                            </div>
                                        @endif
                                        @error('package_name.*')
                                            <div class="text-danger">{{ $message }}</div>
                                        @enderror
                                    </div>

                                    <div class="form-row">
                                        <input type="submit" value="Save" class="btn btn-primary">
                                    </div>
                                </form>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
@section('scripts')
    <script>
        $(document).ready(function() {
            $('#package-form').validate({
                rules: {
                    brand: 'required'
                }
            })


        })
    </script>
    <script type="text/javascript">
        // add row
        $(document).on('click', '.add-row', function() {
            var html =
                '<div class="form-row"> <div class="form-group col-md-10"> <label for="inputEmail4">Package Name</label> <input type="text" class="form-control rounded" name="package_name[]" id="inputEmail4" placeholder="Package Name" value="" > </div><div class="form-group col-md-4" style="display:none"> <label for="inputEmail4">Price</label> <input type="text" class="form-control rounded" name="package_price[]" id="inputEmail4" placeholder="Package Price" value="" > </div><div class="form-group col-md-2"> <label for="inputEmail4"></label><button type="button" class="btn btn-sm btn-danger remove-row" value=""><i class="icon-minus"></i></button> </div>';
            $('#append-row').append(html);
        });

        // remove row
        $(document).on('click', '.remove-row', function() {
            $(this).closest('.form-row').remove();
        });


        $(document).on('click', '.delete-row', function(e) {
            e.preventDefault();
            let element = $(this);
            let url = $(this).data('href');

            swal({
                title: "{{ __('Are you sure?') }}",
                text: "{{ __('Once deleted, you will not be able to recover this!') }}",
                icon: "warning",
                buttons: true,
                dangerMode: true,
            }).then((willDelete) => {
                if (willDelete) {
                    $.ajax({
                        url: url,
                        type: 'GET',
                        success: function(data) {
                            element.closest('.form-row').remove();
                            toastr.success('{{ __('Package has been deleted') }}');
                        },
                        error: function(err) {
                            toastr.error('{{ __('Package has not been deleted') }}');
                        }
                    });
                } else {
                    swal("{{ __('Your data is safe!') }}", {
                        icon: "info",
                        timer: 2000,
                    });
                }
            });
        });

        $(document).on('change', '.change_status', function() {

            let element = $(this);
            let status = '';
            let url = element.data('href')
            if (element.is(':checked')) {
                status = 'active';
            } else {
                status = 'inactive';
            }
            $.ajax({
                url: url,
                type: 'GET',
                data: {
                    status: status
                },
                success: function(data) {
                    console.log(data);
                    toastr.success('Status has been changed to ' + status);
                },
                error: function(err) {
                    toastr.error('Status has not been changed');
                }
            })
        })
    </script>
@endsection
