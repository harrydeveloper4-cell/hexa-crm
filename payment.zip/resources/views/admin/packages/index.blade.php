@extends('admin.layout.master')
@section('title', 'Packages')

@section('css')
@endsection

@section('breadcrumb-title')
    <h3>{{ __('Packages') }}</h3>
@endsection

@section('breadcrumb-items')
    <li class="breadcrumb-item active">{{ __('Packages') }}</li>
@endsection

@section('content')
    <div class="row">
        <div class="col-12 mt-3">
            <div class="card">
                <div class="card-header  justify-content-between align-items-center">
                    <a class = "btn btn-info btn-xs float-right" href = "{{ route('packages.create') }}"><i
                            class = "icon-plus"></i> Create</a>
                    <span class = "float-left">
                        <form action="{{ route('brand.packages.edit') }}?brand={{ $brand->id }}" method = "GET">
                            <div class="form-row">
                                <div class="form-group col-md-6">
                                    <select class = "form-control" name = "brand" required>
                                        <option value = "">Select Brand</option>
                                        @foreach ($brands as $brand)
                                            <option value = "{{ $brand->id }}">{{ $brand->name }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="form-group col-md-6">
                                    <input type = "submit" value = "Edit All Packages" class = "btn btn-primary">
                                </div>
                            </div>
                        </form>
                    </span>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table id="example" class="display table dataTable table-striped table-bordered">
                            <thead>
                                <tr>
                                    <th><input type = "checkbox" class = "check-all"></th>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <!-- <th>Price</th> -->
                                    <th>Brand Name</th>
                                    <th>Brand Logo</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($packages as $key => $package)
                                    <tr>
                                        <td><input type = "checkbox" class = "check" value = "{{ $package->id }}">
                                        </td>
                                        <td>{{ $package->id }}</td>
                                        <td>{{ $package->package_name }}</td>
                                        <td><a
                                                href = "{{ $package->brand->link ?? '' }}">{{ $package->brand->name ?? '' }}</a>
                                        </td>
                                        <!-- <td>{{-- $package->price --}}</td> -->
                                        <td>
                                            <a href = "{{ $package->brand->link ?? '' }}">
                                                <img src = "{{ asset($package->brand->logo ?? '') }}"
                                                    class = "img img-thumbnail" width = "100px" height = "100px">
                                            </a>
                                        </td>
                                        <td>
                                            @if ($package->status == 'active')
                                                <span class = "badge badge-primary">Active</span>
                                            @else
                                                <span class = "badge badge-warning">Inactive</span>
                                            @endif
                                        </td>
                                        <td>
                                            <a href = "{{ route('packages.edit', ['id' => $package->id]) }}"><i
                                                    class = "icon-pencil"></i></a>
                                            <a class = "delete_confirmation"
                                                href = "{{ route('packages.destroy', ['id' => $package->id]) }}"><i
                                                    class = "icon-trash"></i></a>
                                        </td>
                                    </tr>
                                @endforeach
                        </table>
                    </div>
                </div>
            </div>

        </div>
    </div>
@endsection

@section('scripts')
    <script>
        $(document).ready(function() {

            $(".check-all").click(function() {
                $("input[type=checkbox]").prop("checked", $(this).prop("checked"));
            });

            $("input[type=checkbox]").click(function() {
                if (!$(this).prop("checked")) {
                    $(".check-all").prop("checked", false);
                }
            });

            $(document).on('change', '#update-status', function() {

                if ($(this).val() != '') {
                    let status = $(this).val();
                    var ids = [];
                    $.each($(".check:checked"), function() {
                        ids.push($(this).val());
                    });

                    if (ids.length > 0) {
                        let bool = confirm(
                            'Are you sure you want to update status of selected Packages as ' + status)

                        if (bool) {
                            $.ajax({
                                url: "",
                                type: "POST",
                                data: {
                                    status: status,
                                    ids: ids,
                                    '_token': "{{ csrf_token() }}"
                                },
                                success: function(data) {
                                    $("input[type=checkbox]").prop("checked", false)
                                    window.location.reload()

                                },
                                error: function(error) {
                                    alert('Packages updating failed')
                                }
                            })
                        }
                    }
                } else {
                    alert('Please select atleast one inquiry')
                }
            })

            $(document).on('click', '.destroy', function(e) {
                e.preventDefault();
                let url = $(this).attr('href');
                let bool = confirm('Are you sure you want to delete this package');
                if (bool) {
                    window.location.href = url;
                }
            })
        })
    </script>
@endsection
